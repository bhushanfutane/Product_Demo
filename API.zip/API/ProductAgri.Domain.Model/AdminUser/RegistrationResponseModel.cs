﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductAgri.Domain.Model
{
    public class RegistrationResponseModel
    {
        public int UserId { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string MobileNumber { get; set; }
        public string Token { get; set; }
        public string ReferCode { get; set; }
        public DateTime ValidTill { get; set; }
        public int RoleId { get; set; }
        public string Role { get; set; }
        public string ProfilePath { get; set; }

        public string RefreshToken { get; set; }
        public DateTime Refresh_ValidTill { get; set; }
    }

    public class AuthTokenModel
    {
        public string Token { get; set; }
        public DateTime ValidTill { get; set; }
    }
}
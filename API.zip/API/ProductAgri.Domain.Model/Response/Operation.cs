﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductAgri.Domain.Model
{
    public enum Operation
    {
        Add = 1,
        Update = 2,
        Delete = 3
    }
}
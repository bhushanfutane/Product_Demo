﻿using ProductAgri.Domain.Model;
using ProductAgri.Domain.Model.Response;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;

namespace ProductAgri.Domain
{
    public class ResponseModel : IResponseModel
    {
        private readonly IHttpContextAccessor httpContext;
        private readonly IHostingEnvironment hostingEnvironment;

        public ResponseModel()
        {
        }

        public ResponseModel(IHttpContextAccessor httpContext,
                             IHostingEnvironment hostingEnvironment)
        {
            this.httpContext = httpContext;
            this.hostingEnvironment = hostingEnvironment;
        }

        public HttpStatusCode Status { get; set; }
        public string StatusMessage { get; set; }
        public object Data { get; set; }

        public ResponseModel CreateBadRequestResponse(HttpStatusCode status = HttpStatusCode.BadRequest,
            string statusMessage = "Bad Request",
            object Data = null)
        {
            return new ResponseModel()
            {
                Status = status,
                StatusMessage = statusMessage,
                Data = Data
            };
        }

        public ResponseModel CreateInternalServerErrorResponse(HttpStatusCode status = HttpStatusCode.InternalServerError,
            string statusMessage = "Internal Server Error",
            object Data = null)
        {
            return new ResponseModel()
            {
                Status = status,
                StatusMessage = statusMessage,
                Data = Data
            };
        }

        public ResponseModel CreateNotFoundResponse(HttpStatusCode status, string statusMessage = "Empty", object Data = null)
        {
            return new ResponseModel()
            {
                Status = status,
                StatusMessage = statusMessage,
                Data = Data
            };
        }

        public ResponseModel CreateValidationErrorResponse(HttpStatusCode status,
            string statusMessage = "Bad Request",
            object Data = null)
        {
            return new ResponseModel()
            {
                Status = status,
                StatusMessage = statusMessage,
                Data = Data
            };
        }

        public ResponseModel CreateResponse(HttpStatusCode status,
            string statusMessage = "Success",
            object Data = null)
        {
            return new ResponseModel()
            {
                Status = status,
                StatusMessage = statusMessage,
                Data = Data
            };
        }

        public ResponseModel CreateUnauthorizeResponse(HttpStatusCode status, string statusMessage = "Unauthorize", object Data = null)
        {
            return new ResponseModel()
            {
                Status = status,
                StatusMessage = statusMessage,
                Data = Data
            };
        }

        public UserInfo GetCurrentUser()//(int userProfileId)
        {
            try
            {
                UserInfo userInfo = new UserInfo();
                var claims = httpContext.HttpContext.User.Claims.ToList();
                DateTime date = DateTime.UtcNow.AddMinutes(30);
                userInfo.Authorize = httpContext.HttpContext.User.Identity.IsAuthenticated;
                if (userInfo.Authorize)
                {
                    var v = claims.FirstOrDefault(a => a.Type == ClaimTypes.Expired);
                    userInfo.Email = claims.First(a => a.Type == ClaimTypes.Email).Value;
                    userInfo.MobileNo = claims.First(a => a.Type == ClaimTypes.Role).Value;
                    userInfo.RoleId = (Actor)Convert.ToInt32(claims.First(a => a.Type == ClaimTypes.Actor).Value);
                    userInfo.FullName = claims.First(a => a.Type == ClaimTypes.Name).Value;
                    userInfo.UserId = Convert.ToInt32(claims.First(a => a.Type == ClaimTypes.UserData).Value);
                    userInfo.LoginFrom = Convert.ToInt32(claims.First(a => a.Type == ClaimTypes.GivenName).Value);
                    userInfo.AdminRoleId = Convert.ToInt32(claims.First(a => a.Type == ClaimTypes.Sid).Value);
                    //userInfo.ExpiryTime = Convert.ToDateTime((claims.FirstOrDefault(a => a.Type == ClaimTypes.Expired)==null)?
                    //    date.ToString()
                    //    : (claims.First(a => a.Type == ClaimTypes.Expired).Value));
                    userInfo.Authorize = true;//  Convert.ToInt32(claims.First(a => a.Type == ClaimTypes.Role).Value);
                }
                return userInfo;
            }
            catch (System.Exception)
            {
                throw;
            }
        }

        public async Task<bool> LogToFile(string Action, string Username = "", string Role = "")
        {
            try
            {
                string folder = "Loggings";
                if (string.IsNullOrWhiteSpace(hostingEnvironment.WebRootPath))
                {
                    hostingEnvironment.WebRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot");
                }
                var webRoot = hostingEnvironment.WebRootPath;

                if (String.IsNullOrEmpty(Username))
                {
                    var userInfo = GetCurrentUser();
                    if (userInfo.Authorize)
                    {
                        Role = ((Actor)userInfo.RoleId).ToString();
                        Username = userInfo.FullName;
                    }
                }
                var str = $"[{DateTime.UtcNow.AddHours(5).AddMinutes(30)}] : [{Role}] : [{Username}] : [{Action}]";

                var path = $"\\{folder}\\{DateTime.Today.ToShortDateString()}.txt";
                if (!System.IO.Directory.Exists(webRoot + $"\\{folder}"))
                {
                    System.IO.Directory.CreateDirectory(webRoot + $"\\{folder}");
                }
                var filePath = webRoot + path;
                using (StreamWriter writer = System.IO.File.AppendText(filePath))
                {
                    await writer.WriteLineAsync(str);
                }
                return await Task.FromResult(true);
            }
            catch (System.Exception)
            {
                return await Task.FromResult(true);
            }
        }
    }
}
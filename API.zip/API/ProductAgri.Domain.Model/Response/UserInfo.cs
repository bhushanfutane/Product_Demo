﻿using System;
using System.Collections.Generic;
using System.Text;
using ProductAgri.Domain.Model;

namespace ProductAgri.Domain.Model
{
    public class UserInfo
    {
        public int UserId { get; set; }
        public string Email { get; set; }
        public string MobileNo { get; set; }
        public string FullName { get; set; }
        public Actor RoleId { get; set; }
        public int AdminRoleId { get; set; }
        public bool Authorize { get; set; }
        public int LoginFrom { get; set; }
        public DateTime ExpiryTime { get; set; }
    }
}
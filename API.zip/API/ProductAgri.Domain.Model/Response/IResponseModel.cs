using System.Net;
using System.Threading.Tasks;

namespace ProductAgri.Domain.Model.Response
{
    public interface IResponseModel
    {
        ResponseModel CreateResponse(HttpStatusCode status,
        string statusMessage = "Success",
           object Data = null);

        ResponseModel CreateBadRequestResponse(HttpStatusCode status,
            string statusMessagee = "Bad Request",
            object Data = null);

        ResponseModel CreateInternalServerErrorResponse(HttpStatusCode status,
            string statusMessagee = "Internal Server Error",
            object Data = null);

        ResponseModel CreateNotFoundResponse(HttpStatusCode status = HttpStatusCode.NotFound,
            string statusMessagee = "Empty",
            object Data = null);

        ResponseModel CreateValidationErrorResponse(HttpStatusCode status,
            string statusMessagee = "Bad Request",
            object Data = null);

        ResponseModel CreateUnauthorizeResponse(HttpStatusCode status,
            string statusMessage = "Unauthorize",
            object Data = null);

        UserInfo GetCurrentUser();// (int userProfileId);

                                  // Task<bool> LogToFile(string Action, string Username = "", string Role = "");
    }
}
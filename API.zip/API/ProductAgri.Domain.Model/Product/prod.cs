﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductAgri.Domain.Model
{
    public class Prod
    {
        public int Id { get; set; }
        public string NameEng { get; set; }
        public string NameMar { get; set; }
        public string NameHin { get; set; }
        public decimal Price { get; set; }
        public bool Active { get; set; }
        public string ImageUrl { get; set; }
        public string ImageBase64 { get; set; }
        public string Discription { get; set; }
        public string DiscriptionHn { get; set; }
        public string DiscriptionMr { get; set; }
        public decimal Mrp { get; set; }
        public int CategoryId { get; set; }
        public decimal Weight { get; set; }
        public int Qunatity { get; set; }
    }

    public class Product
    {
        public int Id { get; set; }
        public string NameEng { get; set; }
        public string NameMar { get; set; }
        public string NameHin { get; set; }
        public decimal Price { get; set; }
        public bool Active { get; set; }
        public string ImageUrl { get; set; }
        public string Discription { get; set; }
        public string DiscriptionHn { get; set; }
        public string DiscriptionMr { get; set; }
        public decimal Mrp { get; set; }
        public decimal Weight { get; set; }
        public int CategoryId { get; set; }
        public string CategoryEn { get; set; }
        public string CategoryHn { get; set; }
        public string CategoryMr { get; set; }
        public bool IsInCart { get; set; }
        public int Quantity { get; set; }
    }

    public class AddProd
    {
        public int Count { get; set; }
        public List<Prod> Product { get; set; }
    }

    public class Products
    {
        public int Count { get; set; }
        public List<Product> Product { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ProductAgri
{
    public partial class TblProduct
    {
        public TblProduct()
        {
        }

        public int Id { get; set; }
        public string NameEng { get; set; }
        public string NameMar { get; set; }
        public string NameHin { get; set; }
        public decimal? Price { get; set; }
        public bool Active { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string ImageUrl { get; set; }
        public string Discription { get; set; }
        public string DiscriptionHn { get; set; }
        public string DiscriptionMr { get; set; }
        public decimal? Mrp { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? UpdatedBy { get; set; }
        public decimal? Weight { get; set; }
        public int? CategoryId { get; set; }

        public virtual TblCategory Category { get; set; }
    }
}
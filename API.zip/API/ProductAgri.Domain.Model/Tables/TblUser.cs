﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ProductAgri
{
    public partial class TblUser
    {
        public TblUser()
        {
            TblUserAddresses = new HashSet<TblUserAddress>();
        }

        public int Id { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public bool? IsMobileVerified { get; set; }
        public string Password { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }
        public bool? IsActive { get; set; }

        public virtual ICollection<TblUserAddress> TblUserAddresses { get; set; }
    }
}
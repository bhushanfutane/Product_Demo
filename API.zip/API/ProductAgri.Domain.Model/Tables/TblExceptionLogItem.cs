﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ProductAgri
{
    public partial class TblExceptionLogItem
    {
        public int EventId { get; set; }
        public DateTime? LogDateTime { get; set; }
        public string Source { get; set; }
        public string Message { get; set; }
        public string QueryString { get; set; }
        public string TargetSite { get; set; }
        public string StackTrace { get; set; }
        public string ServerName { get; set; }
        public string RequestUrl { get; set; }
        public string UserAgent { get; set; }
        public string UserIp { get; set; }
        public string UserAuthentication { get; set; }
        public string UserName { get; set; }
    }
}
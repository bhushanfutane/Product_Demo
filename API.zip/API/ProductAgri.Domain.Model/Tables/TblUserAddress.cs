﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ProductAgri
{
    public partial class TblUserAddress
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string HouseNo { get; set; }
        public string AppartmentName { get; set; }
        public string StreetDetails { get; set; }
        public string Landmark { get; set; }
        public string AreaName { get; set; }
        public string Pincode { get; set; }
        public string Contact { get; set; }
        public int? AddressType { get; set; }
        public string City { get; set; }
        public string NiknameAddress { get; set; }
        public bool? Isdefault { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? UpdatedBy { get; set; }

        public virtual TblUser User { get; set; }
    }
}
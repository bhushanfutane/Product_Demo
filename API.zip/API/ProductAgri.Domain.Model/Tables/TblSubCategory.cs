﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ProductAgri
{
    public partial class TblSubCategory
    {
        public int Id { get; set; }
        public int? CategoryId { get; set; }
        public string NameEng { get; set; }
        public string NameMar { get; set; }
        public string NameHin { get; set; }
        public string ImagePath { get; set; }
        public bool? Active { get; set; }
        public string Discription { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? UpdatedBy { get; set; }

        public virtual TblCategory Category { get; set; }
    }
}
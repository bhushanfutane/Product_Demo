namespace ProductAgri.Domain.Model
{
    public class Settings
    {
        public string ConnectionString;
        public string Database;
    }
}
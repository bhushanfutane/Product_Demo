using System;
using System.Collections.Generic;

namespace ProductAgri
{
    public class UserAddressModel
    {
        public int Id { get; set; }
        public string HouseNo { get; set; }
        public string AppartmentName { get; set; }
        public string StreetDetails { get; set; }
        public string Landmark { get; set; }
        public string City { get; set; }
        public string AreaName { get; set; }
        public string Pincode { get; set; }
        public int AddressType { get; set; }
        public string NiknameAddress { get; set; }
        public bool Isdefault { get; set; }
        public string AreaCode { get; set; }
        public string Contact { get; set; }
    }

    //partial class TblUserAddress
    //{
    //    public override string ToString()
    //    {
    //        return this.StreetDetails + " " + this.AppartmentName + " " + this.HouseNo + " " + this.Landmark + " " + this.AreaName + " " + this.Pincode;
    //    }
    //}
}
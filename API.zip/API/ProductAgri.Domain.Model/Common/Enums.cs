namespace ProductAgri.Domain.Model
{
    public class Enums
    {
    }

    public enum VehiclePaymentStatus
    {
        Take = 1,
        Give = 2
    }

    public enum AdminRole
    {
        Admin = 1,
        Employee = 2,
        CustomerCareManager = 3,
        CustomerCare = 4,
        Accountant = 5
    }

    public enum Banner
    {
        Default = 1,
        Category = 2,
        Product = 3
    }

    public enum PaymentMode
    {
        Online = 1,
        Wallet = 2,
        COD = 3,
        Cash = 7,
        Cheque = 4,
        UPI = 5,
        Bank = 6
    }

    public enum TransactionDate
    {
        Default = 0,
        Today = 1,
        Lastweeek = 2,
        LastMonth = 3,
        TillDate = 4
    }

    public enum ExternalLoginMode
    {
        Google = 1,
    }

    public enum HelpAndSuportStatus
    {
        Pending = 0,
        Accept = 1,
        Reject = 2
    }

    public enum PaymentStatus
    {
        Initial = 0,
        Success = 1,
        Failed = 2,
        Pending = 3
    }

    public enum ComplaintStatus
    {
        Open = 0,
        InProcess = 1,
        Resolve = 2,
        Close = 3
    }

    public enum ComplaintType
    {
        BadQualityProduct = 1,
        WrongProduct = 2,
        Other = 3
    }

    public enum Actor
    {
        Admin = 1,
        User = 2,
        //GPartner = 3,
        //DeliveryBoy = 4
    }

    public enum ForgotPassword
    {
        SendOtp = 1,
        VerifyOtp = 2,
        ChangePassword = 3
    }

    // public enum NotificationType
    // {
    //     RefreshList = 0,
    //     // New Order Place
    //     NewOrderPlacedForGPartner = 1,
    //     NewOrderPlaceForAdmin = 2,

    //     // Accepted By GP
    //     OrderAcceptedForAdmin = 3,
    //     RefreshNewOrderListForGparner = 4,

    //     // Passed By GP
    //     OrderPassedByBPForAdmin = 5,

    //     // Order Completed by GP
    //     OrderCompleteForDP = 6,

    //     // Order Pass By DP
    //     OrderPassByDPForAdmin = 7,

    //     // Order Deliver To Customer
    //     OrderDeliveredForAdmin = 8

    // }

    public static class NotificationType
    {
        public static string RefreshList = "0";

        // New Order Place
        public static string NewOrderPlacedForGPartner = "1";

        public static string NewOrderPlaceForAdmin = "2";
        public static string NewOrderPlaceForUser = "9";

        // Accepted By GP
        public static string OrderAcceptedForAdmin = "3";

        public static string RefreshNewOrderListForGparner = "4";

        // Passed By GP
        public static string OrderPassedByBPForAdmin = "5";

        // Order Completed by GP
        public static string OrderCompleteForDP = "6";

        // Order Pass By DP
        public static string OrderPassByDPForAdmin = "7";

        // Order Deliver To Customer
        public static string OrderDeliveredForAdmin = "8";

        // Order PickedUp By DP
        public static string OrderPickedUpDPForGP = "10";

        public static string OrderPickedUpDPForDP = "11";

        // Order PickedUp By DP
        public static string OrderCancelForGP = "12";

        public static string OrderCancelForAdmin = "13";

        //Assign New Order For DeliveryBoy
        public static string AssignNewOrderForDP = "14";
    }

    public static class Language
    {
        public readonly static string English = "ENG";
        public readonly static string Marathi = "MAR";
        public readonly static string Hindi = "HIN";
    }

    public enum Rating
    {
        Product = 1,
        Grinding = 2,
        Delivery = 3
    }

    public enum ValidateUsername
    {
        Email = 1,
        Mobile = 2,
        Invalid = 3
    }

    public enum ProductType
    {
        Kitak_Nashak = 1,
        Tan_Nashak = 2,
        Tonik = 3,
    }

    public enum GrindingType
    {
        Fine = 1,
        Medium = 2,
        Course = 3
    }

    public enum FileType
    {
        Category = 1,
        SubCatgory = 2,
        Product = 3,
        Banner = 4,
        Gallery = 5,
        Testimonial = 6,
        Social = 7,
        Course = 8,
    }

    public enum DocumentTypes
    {
        ProfilePhoto = 1,
        AadharCard,
        PANCard,
        ShopAct,
        ShopPhoto,
        FssaiCertificate
    }

    public enum OrderStatus
    {
        Initial = 1,
        Pass = 2,
        Accept = 3,
        InProcess = 4,
        CompleteByGP = 5,
        PickedUp = 6,
        Delivered = 7,
        Cancel = 8,
        AcceptByOther = 9
    }

    public enum SmsType
    {
        System = 1,
        Order = 2
    }

    public enum RegisteredFrom
    {
        Web = 1,
        Android = 2
    }

    public enum SettingName
    {
        Otp,
        Token,
        SMSSettings,
        SMSs,
        Email,
        RazorPay,
        PushNotification,
        QtyBasedDiscount,
        ConvCharges,
        GST,
        Wallet,
        DeliveryBoyPayment,
        Order,
        GoogleKey,
        GoLive,
        DeliverSlot
    }

    public enum SearchListEnum
    {
        Product = 1,
        Grain = 2,
        GrainCategory = 3
    }

    public static class ActionPerformed
    {
        public static string User_Login = "Tried To Login";
        public static string User_Register = "Tried To Register";

        // Cart Controller
        public static string Cart_AddToCart = "Add To Cart";

        public static string Cart_BulkAddToCart = "Bulk Add To Cart";
        public static string Cart_List = "Get Cart List";
        public static string Cart_Count = "Get Cart Count";
        public static string Cart_Summart = "Get Cart Summary";
        public static string Cart_Remove = "Remove From Cart";
        public static string Cart_Clear = "Clear Whole Cart";
    }
}
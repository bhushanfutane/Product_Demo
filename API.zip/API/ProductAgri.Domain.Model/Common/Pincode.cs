﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductAgri.Domain.Model
{
    public class Pincode
    {
        public string officeName { get; set; }
        public string pincode { get; set; }
        public string taluk { get; set; }
        public string districtName { get; set; }
        public string stateName { get; set; }
    }
}
using System;
using System.Collections.Generic;
using System.Text;

namespace ProductAgri.Domain.Model
{
    public class MessageData
    {
        public string Number { get; set; }
        public string MessageId { get; set; }
    }

    public class RootObject
    {
        public string ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
        public string JobId { get; set; }
        public List<MessageData> MessageData { get; set; }
    }
}
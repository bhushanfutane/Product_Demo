using System.Collections.Generic;
using System.Linq;

namespace ProductAgri.Domain
{
    public static class ExtenstionMethods
    {
        public static IEnumerable<T> Paginate<T>(this IEnumerable<T> en, int pageSize, int page)
        {
            if (pageSize == 0 && page == 0)
            {
                return en;
            }
            return en.Skip((page - 1) * pageSize).Take(pageSize);
        }

        public static IQueryable<T> Paginate<T>(this IQueryable<T> en, int pageSize, int page)
        {
            if (pageSize == 0 && page == 0)
            {
                return en;
            }
            return en.Skip((page - 1) * pageSize).Take(pageSize);
        }
    }
}
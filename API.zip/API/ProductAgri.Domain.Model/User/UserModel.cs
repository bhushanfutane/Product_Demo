using Microsoft.AspNetCore.Http;
using ProductAgri.Domain.Model;
using System;
using System.Collections.Generic;

namespace ProductAgri
{
    public class AdminUsers
    {
        public int count { get; set; }
        public List<UserListforAdmin> Users { get; set; }
    }

    public partial class UserListforAdmin
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public string Mobile { get; set; }
        public bool? IsMobileVerified { get; set; }
        public string RegistationDate { get; set; }
        public string Profilepath { get; set; }
        public bool Active { get; set; }
        public string ReferCode { get; set; }
    }

    public class UserRegistration
    {
        public string FullName { get; set; }
        public string Mobile { get; set; }
        public string Password { get; set; }
        public string Otp { get; set; }
        public string ReferCode { get; set; }
    }

    public class UserLoginModel
    {
        public string Mobile { get; set; }
        public string Password { get; set; }
    }

    public class SetPassword
    {
        public string Mobile { get; set; }
        public string NewPassword { get; set; }
        public string Otp { get; set; }
    }

    public class VerifyLoginwithOtp
    {
        public string Mobile { get; set; }
        public string Otp { get; set; }
    }

    public class ChangePasswordModel
    {
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
    }

    public class profilepic
    {
        public IFormFile Profilepath { get; set; }
    }
}
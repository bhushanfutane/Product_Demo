﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductAgri.Domain.Model
{
    public class Category
    {
        public int Id { get; set; }
        public string NameEng { get; set; }
        public string NameMar { get; set; }
        public string NameHin { get; set; }
        public string ImagePath { get; set; }
        public string ImageBase64 { get; set; }
        public bool Active { get; set; }
    }

    public class SubCategory
    {
        public int Id { get; set; }
        public int CategoryId { get; set; }
        public string NameEng { get; set; }
        public string NameMar { get; set; }
        public string NameHin { get; set; }
        public string ImagePath { get; set; }
        public string ImageBase64 { get; set; }
        public bool Active { get; set; }
        public string Discription { get; set; }
    }

    public class Wallet
    {
        public int Id { get; set; }
        public int OrderId { get; set; }
        public decimal Amount { get; set; }
        public bool IsCredited { get; set; }
        public string Remark { get; set; }
        public string OrderNo { get; set; }
        public DateTime Date { get; set; }
    }
}
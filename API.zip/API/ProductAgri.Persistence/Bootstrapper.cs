﻿using Microsoft.Extensions.DependencyInjection;
using ProductAgri.Persistence.Contract;
using ProductAgri.Persistence.Repository;

namespace ProductAgri.Persistence
{
    public class Bootstrapper
    {
        public static void RegisterDependancies(IServiceCollection services)
        {
            services.AddScoped<IAdminUserRepository, AdminUserRepository>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<ILoggerRepository, LoggerRepository>();
            services.AddScoped<ICategoryRepository, CategoryRepository>();
            services.AddScoped<ISubCategoryRepository, SubCategoryRepository>();
            services.AddScoped<IProductRepository, ProductRepository>();
            services.AddScoped<IUserAddressRepository, UserAddressRepository>();
        }
    }
}
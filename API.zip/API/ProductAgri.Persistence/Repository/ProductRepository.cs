﻿using Microsoft.EntityFrameworkCore;
using ProductAgri.Domain;
using ProductAgri.Persistence.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAgri.Persistence.Repository
{
    public class ProductRepository : IProductRepository
    {
        private readonly AppDBContext context;

        public ProductRepository(AppDBContext context)
        {
            this.context = context;
        }

        public async Task<TblProduct> AddAsync(TblProduct product)
        {
            try
            {
                await context.TblProducts.AddAsync(product);

                await context.SaveChangesAsync();

                return product;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create grain", ex);
            }
        }

        public async Task<List<TblProduct>> GetAsync(int pageSize, int pageNumber)
        {
            try
            {
                return await context.TblProducts.OrderByDescending(a => a.Id).Paginate(pageSize, pageNumber).ToListAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create grain", ex);
            }
        }

        public async Task<List<TblProduct>> GetAsync(int pageSize, int pageNumber, bool IsActive = true)
        {
            try
            {
                return await context.TblProducts.Where(a => a.Active == IsActive).OrderByDescending(a => a.Id).Paginate(pageSize, pageNumber).ToListAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create grain", ex);
            }
        }

        public async Task<List<TblProduct>> GetAsync(List<int> Ids)
        {
            try
            {
                return await context.TblProducts.Where(a => Ids.Contains(a.Id)).OrderByDescending(a => a.Id).ToListAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create grain", ex);
            }
        }

        public async Task<TblProduct> GetAsync(int Id)
        {
            try
            {
                if (Id == 0)
                {
                    throw new CustomException("product Id Cannot Be 0");
                }
                return await context.TblProducts.Where(a => a.Id == Id).FirstOrDefaultAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create grain", ex);
            }
        }

        public async Task<TblProduct> GetAsync(string productName, int productId = 0)
        {
            try
            {
                if (productId == 0)
                {
                    return await context.TblProducts.Where(a => a.NameEng.Equals(productName) && a.Active).FirstOrDefaultAsync();
                }
                return await context.TblProducts.Where(a => a.NameEng.Equals(productName) && a.Id != productId && a.Active).FirstOrDefaultAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create grain", ex);
            }
        }

        public async Task<TblProduct> RemoveAsync(TblProduct product)
        {
            try
            {
                context.TblProducts.Remove(product);

                await context.SaveChangesAsync();

                return product;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create grain", ex);
            }
        }

        public async Task<TblProduct> UpdateAsync(TblProduct product)
        {
            try
            {
                context.TblProducts.Update(product);

                await context.SaveChangesAsync();

                return product;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create grain", ex);
            }
        }
    }
}
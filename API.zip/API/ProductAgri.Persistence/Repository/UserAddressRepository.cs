﻿using Microsoft.EntityFrameworkCore;
using ProductAgri.Domain;
using ProductAgri.Persistence.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAgri.Persistence.Repository
{
    public class UserAddressRepository : IUserAddressRepository
    {
        private readonly AppDBContext context;

        public UserAddressRepository(AppDBContext context)
        {
            this.context = context;
        }

        public async Task<TblUserAddress> Add(TblUserAddress userAddress)
        {
            try
            {
                await context.TblUserAddresses.AddAsync(userAddress);
                await context.SaveChangesAsync();
                return userAddress;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }

        public async Task<List<TblUserAddress>> GetAllAsync(int UserId)
        {
            try
            {
                return await context.TblUserAddresses.Where(a => a.UserId == UserId).ToListAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }

        public async Task<TblUserAddress> GetAsync(int Id)
        {
            try
            {
                return await context.TblUserAddresses.Where(a => a.Id == Id).FirstOrDefaultAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }

        public async Task<TblUserAddress> GetAsync(int UserId, bool Isdefault)
        {
            try
            {
                return await context.TblUserAddresses.Where(a => a.UserId == UserId && a.Isdefault == Isdefault).FirstOrDefaultAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }

        public async Task<TblUserAddress> Remove(TblUserAddress userAddress)
        {
            try
            {
                context.TblUserAddresses.Remove(userAddress);
                await context.SaveChangesAsync();
                return userAddress;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }

        public async Task<TblUserAddress> Update(TblUserAddress userAddress)
        {
            try
            {
                context.TblUserAddresses.Update(userAddress);
                await context.SaveChangesAsync();
                return userAddress;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }

        public async Task<List<TblUserAddress>> UpdateRangeAsync(List<TblUserAddress> userAddress)
        {
            try
            {
                context.TblUserAddresses.UpdateRange(userAddress);
                await context.SaveChangesAsync();
                return userAddress;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }
    }
}
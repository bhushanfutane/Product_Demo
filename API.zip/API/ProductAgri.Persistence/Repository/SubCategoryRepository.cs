﻿using Microsoft.EntityFrameworkCore;
using ProductAgri.Domain;
using ProductAgri.Persistence.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAgri.Persistence.Repository
{
    public class SubCategoryRepository : ISubCategoryRepository
    {
        private readonly AppDBContext context;

        public SubCategoryRepository(AppDBContext context)
        {
            this.context = context;
        }

        public async Task<TblSubCategory> AddAsync(TblSubCategory SubCategory)
        {
            try
            {
                await context.TblSubCategories.AddAsync(SubCategory);

                await context.SaveChangesAsync();

                return SubCategory;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create SubCategory", ex);
            }
        }

        public async Task<List<TblSubCategory>> GetAsync(int pageSize, int pageNumber)
        {
            try
            {
                return await context.TblSubCategories.OrderByDescending(a => a.Id).Paginate(pageSize, pageNumber).ToListAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create SubCategory", ex);
            }
        }

        public async Task<List<TblSubCategory>> GetAsync(int pageSize, int pageNumber, bool IsActive = true, int CategoryId = 0)
        {
            try
            {
                return await context.TblSubCategories.Where(a => a.Active == IsActive && a.CategoryId == (CategoryId == 0 ? a.CategoryId : CategoryId)).OrderByDescending(a => a.Id).Paginate(pageSize, pageNumber).ToListAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create SubCategory", ex);
            }
        }

        public async Task<TblSubCategory> GetAsync(int Id)
        {
            try
            {
                if (Id == 0)
                {
                    throw new CustomException("SubCategory Id Cannot Be 0");
                }
                return await context.TblSubCategories.Where(a => a.Id == Id).FirstOrDefaultAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create SubCategory", ex);
            }
        }

        public async Task<TblSubCategory> GetAsync(string Subcategory, int SubcategoryId = 0)
        {
            try
            {
                if (SubcategoryId == 0)
                {
                    return await context.TblSubCategories.Where(a => a.NameEng.Equals(Subcategory) && a.Active.Value).FirstOrDefaultAsync();
                }
                return await context.TblSubCategories.Where(a => a.NameEng.Equals(Subcategory) && a.Id != SubcategoryId && a.Active.Value).FirstOrDefaultAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create SubCategory", ex);
            }
        }

        public async Task<TblSubCategory> RemoveAsync(TblSubCategory SubCategory)
        {
            try
            {
                context.TblSubCategories.Remove(SubCategory);

                await context.SaveChangesAsync();

                return SubCategory;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create SubCategory", ex);
            }
        }

        public async Task<TblSubCategory> UpdateAsync(TblSubCategory SubCategory)
        {
            try
            {
                context.TblSubCategories.Update(SubCategory);

                await context.SaveChangesAsync();

                return SubCategory;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create SubCategory", ex);
            }
        }
    }
}
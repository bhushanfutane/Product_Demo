using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//using FlourPicker.Domain;
//using FlourPicker.Domain.Model;
//using FlourPicker.Persistence.Contract;
using Microsoft.EntityFrameworkCore;
using ProductAgri.Domain;
using ProductAgri.Domain.Model;
using ProductAgri.Persistence.Contract;

using ProductAgri.Domain;

namespace ProductAgri.Persistence.Repository
{
    public class AdminUserRepository : IAdminUserRepository
    {
        private readonly AppDBContext context;

        public AdminUserRepository(AppDBContext context)
        {
            this.context = context;
        }

        public async Task<TblAdminUser> AddAdminUser(TblAdminUser adminUser)
        {
            try
            {
                await context.TblAdminUsers.AddAsync(adminUser);
                await context.SaveChangesAsync();
                return adminUser;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }

        public async Task<TblAdminUser> GetAdminUserById(int AdminUserId)
        {
            try
            {
                return await context.TblAdminUsers.Where(a => a.Id == AdminUserId).FirstOrDefaultAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }

        public async Task<List<TblAdminUser>> GetAdminUser()
        {
            try
            {
                return await context.TblAdminUsers.Where(a => a.IsActive == true).OrderByDescending(a => a.Id)
                .ToListAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }

        public async Task<List<AdminUserRegistrationModel>> GetAllAdminUser()
        {
            try
            {
                return await context.TblAdminUsers.
                    Select(user =>
                    new AdminUserRegistrationModel
                    {
                        Id = user.Id,
                        FirstName = user.FirstName,
                        LastName = user.LastName,
                        UserName = user.UserName,
                        Email = user.Email,
                        IsActive = user.IsActive,
                        MobileNo = user.MobileNo,
                        //  RoleId = user.RoleId,
                        Address = user.Address,
                        RegistrationDate = user.RegistrationDate,
                    })
                    .OrderByDescending(a => a.Id)
                .ToListAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }

        public async Task<TblAdminUser> RemoveAdminUser(TblAdminUser adminUser)
        {
            try
            {
                adminUser.IsDelete = true;
                context.TblAdminUsers.Update(adminUser);
                await context.SaveChangesAsync();
                return adminUser;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }

        public async Task<TblAdminUser> UpdateAdminUser(TblAdminUser adminUser)
        {
            try
            {
                context.TblAdminUsers.Update(adminUser);
                await context.SaveChangesAsync();
                return adminUser;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }

        public async Task<TblAdminUser> GetAdminUserByForLogin(string username, string password, bool IsEmail)
        {
            try
            {
                if (IsEmail)
                {
                    return await context.TblAdminUsers.Where(a => a.Email.Equals(username) && a.Password.Equals(password) && a.IsActive.Value).FirstOrDefaultAsync();
                }
                else
                {
                    return await context.TblAdminUsers.Where(a => a.MobileNo.Equals(username) && a.Password.Equals(password) && a.IsActive.Value).FirstOrDefaultAsync();
                }
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }

        public async Task<TblAdminUser> GetAdminUserByForLogin(string username, bool IsEmail)
        {
            try
            {
                if (IsEmail)
                {
                    return await context.TblAdminUsers.Where(a => a.Email.Equals(username) && a.IsActive.Value).FirstOrDefaultAsync();
                }
                else
                {
                    return await context.TblAdminUsers.Where(a => a.MobileNo.Equals(username) && a.IsActive.Value).FirstOrDefaultAsync();
                }
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }

        public async Task<TblAdminUser> IsUserNameTaken(string userName, int UserId = 0)
        {
            try
            {
                if (UserId == 0)
                {
                    return await context.TblAdminUsers.Where(a => a.UserName.Equals(userName) && a.IsActive.Value).FirstOrDefaultAsync();
                }
                return await context.TblAdminUsers.Where(a => a.UserName.Equals(userName) && a.Id != UserId && a.IsActive.Value).FirstOrDefaultAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something went wrong while removing user...!", ex);
            }
        }
    }
}
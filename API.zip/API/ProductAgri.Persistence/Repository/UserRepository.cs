﻿using System;
using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using ProductAgri.Domain.Model;
using ProductAgri.Persistence.Contract;
using System.Threading.Tasks;
using ProductAgri.Domain;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;

namespace ProductAgri.Persistence
{
    public class UserRepository : IUserRepository
    {
        public readonly IConfiguration configuration;
        private readonly AppDBContext context;
        private readonly ILoggerRepository logRepository;
        private readonly IHttpContextAccessor httpContextAccessor;

        public UserRepository(IConfiguration _configuration, AppDBContext context, ILoggerRepository logRepository, IHttpContextAccessor _httpContextAccessor)
        {
            configuration = _configuration;
            this.context = context;
            this.logRepository = logRepository;
            httpContextAccessor = _httpContextAccessor;
        }

        public async Task<AdminUsers> GetAsyncSearch(string SearchStr, int PageNo, int PageSize)
        {
            try
            {
                AdminUsers adminUsers = new AdminUsers();
                List<UserListforAdmin> listforAdmins = new List<UserListforAdmin>();
                string baseurl = configuration.GetValue<string>("AttachmentsSettings:ImageUrl");
                string NoImage = configuration.GetValue<string>("AttachmentsSettings:UserDefault");

                var list = await context.TblUsers.Where(a => a.IsActive == true && (a.Mobile.Contains(SearchStr)))
                       .Select(a => new UserListforAdmin()
                       {
                           Id = a.Id,
                           FullName = a.FullName,
                           Mobile = a.Mobile,
                           IsMobileVerified = a.IsMobileVerified,
                           RegistationDate = a.CreatedDate.Value.AddHours(5).AddMinutes(30).ToShortDateString(),

                           Active = a.IsActive.Value
                       }).OrderByDescending(a => a.Id).ToListAsync();
                adminUsers.count = list.Count;
                adminUsers.Users = list.Paginate(PageSize, PageNo).ToList();
                return adminUsers;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                await logRepository.LogToDatabaseAsync(ex, httpContextAccessor);
                throw new CustomException("Something went wrong while fetching User...!", ex);
            }
        }

        public async Task<AdminUsers> GetAsync(int PageNo, int PageSize, bool IsActive = true)
        {
            try
            {
                AdminUsers adminUsers = new AdminUsers();
                List<UserListforAdmin> listforAdmins = new List<UserListforAdmin>();
                string baseurl = configuration.GetValue<string>("AttachmentsSettings:ImageUrl");
                string NoImage = configuration.GetValue<string>("AttachmentsSettings:UserDefault");

                var list = await context.TblUsers.Where(a => a.IsActive == IsActive)
                       .Select(a => new UserListforAdmin()
                       {
                           Id = a.Id,
                           FullName = a.FullName,
                           Mobile = a.Mobile,
                           IsMobileVerified = a.IsMobileVerified,
                           RegistationDate = a.CreatedDate.Value.AddHours(5).AddMinutes(30).ToShortDateString(),
                           Active = a.IsActive.Value,
                       }).OrderByDescending(a => a.Id).ToListAsync();
                adminUsers.count = list.Count;
                adminUsers.Users = list.Paginate(PageSize, PageNo).ToList();
                return adminUsers;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                await logRepository.LogToDatabaseAsync(ex, httpContextAccessor);
                throw new CustomException("Something went wrong while fetching User...!", ex);
            }
        }

        public async Task<TblUser> GetAsync(int Id)
        {
            try
            {
                if (Id == 0)
                {
                    throw new CustomException("User Id Cannot Be 0");
                }
                return await context.TblUsers.Where(a => a.Id == Id).FirstOrDefaultAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                await logRepository.LogToDatabaseAsync(ex, httpContextAccessor);
                throw new CustomException("Something went wrong while updating User...!", ex);
            }
        }

        public async Task<TblUser> GetAsync(string userName, string password)
        {
            try
            {
                return await context.TblUsers.Where(a => a.Mobile.Equals(userName) && a.Password.Equals(password) && a.IsActive.Value).FirstOrDefaultAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                await logRepository.LogToDatabaseAsync(ex, httpContextAccessor);
                throw new CustomException("Something went wrong while Getting user...!", ex);
            }
        }

        public async Task<TblUser> GetAsync(string userName, int UserId = 0)
        {
            try
            {
                if (UserId == 0)
                {
                    return await context.TblUsers.Where(a => a.Mobile.Equals(userName)).FirstOrDefaultAsync();
                }
                return await context.TblUsers.Where(a => a.Mobile.Equals(userName) && a.Id != UserId).FirstOrDefaultAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                await logRepository.LogToDatabaseAsync(ex, httpContextAccessor);
                throw new CustomException("Something went wrong while removing user...!", ex);
            }
        }

        public async Task<TblUser> GetAsync(string UserName)
        {
            try
            {
                if (string.IsNullOrEmpty(UserName))
                {
                    throw new CustomException("User UserName Cannot null");
                }
                return await context.TblUsers.Where(a => a.Mobile == UserName && a.IsActive.Value).FirstOrDefaultAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                await logRepository.LogToDatabaseAsync(ex, httpContextAccessor);
                throw new CustomException("Something went wrong while updating User...!", ex);
            }
        }

        public async Task<TblUser> AddUserAsync(TblUser user)
        {
            try
            {
                await context.TblUsers.AddAsync(user);
                await context.SaveChangesAsync();
                return user;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                await logRepository.LogToDatabaseAsync(ex, httpContextAccessor);
                throw new CustomException("Cannot Create User", ex);
            }
        }

        public async Task<TblUser> UpdateUserAsync(TblUser user)
        {
            try
            {
                if (user.Id == 0)
                {
                    throw new CustomException("User ID cannot be 0...!");
                }

                context.TblUsers.Update(user);
                await context.SaveChangesAsync();
                return user;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                await logRepository.LogToDatabaseAsync(ex, httpContextAccessor);
                throw new CustomException("Something went wrong while updating stock...!", ex);
            }
        }

        public async Task<TblUser> RemoveUserAsync(TblUser user)
        {
            try
            {
                context.TblUsers.Remove(user);
                await context.SaveChangesAsync();
                return user;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                await logRepository.LogToDatabaseAsync(ex, httpContextAccessor);
                throw new CustomException("Something went wrong while removing user...!", ex);
            }
        }
    }
}
﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Data.SqlClient;
using System.IO;
using System.Threading.Tasks;

//using FlourPicker.Persistence.Contract;
using ProductAgri.Persistence.Contract;

namespace ProductAgri.Persistence
{
    /// <summary>
    /// Need to refractor this Method
    /// </summary>
    public class LoggerRepository : ILoggerRepository
    {
        private readonly AppDBContext _context;

        public LoggerRepository(AppDBContext context)
        {
            _context = context;
        }

        // public async Task<string> LogToDatabase(Exception ex, IHttpContextAccessor ctxObject)
        public async System.Threading.Tasks.Task LogToDatabaseAsync(Exception ex, IHttpContextAccessor ctxObject)
        {
            try
            {
                if (ex != null)
                {
                    string strReqURL = ctxObject.HttpContext.Request.Host.Host;
                    string strReqQS = ctxObject.HttpContext.Request.QueryString.ToString();
                    string strServerName = ctxObject.HttpContext.Request.Headers["Referer"].ToString();
                    string strUserAgent = ctxObject.HttpContext.Request.Headers["User-Agent"].ToString();
                    string strUserIP = ctxObject.HttpContext.Connection.RemoteIpAddress.ToString();
                    string strUserAuthen = ctxObject.HttpContext.User.Identity.IsAuthenticated.ToString();
                    string strUserName = (ctxObject.HttpContext.User.Identity.Name != null) ? ctxObject.HttpContext.User.Identity.Name : string.Empty;

                    string strSource = ex.Source;
                    string strTargetSite = ex.TargetSite?.ToString();
                    string strStackTrace = ex.StackTrace?.ToString();
                    string Datetime = DateTime.Now.ToString();
                    string InnerExecption = ex.Message?.ToString();

                    string queryString = $"exec csp_LogExceptionToDB '{strSource}', '{Datetime}',  '{InnerExecption}','{strReqQS}','{strTargetSite}', '{strStackTrace}', '{strServerName}', '{strReqURL}', '{strUserAgent}', '{strUserIP}', '{strUserAuthen}', '{strUserName}';";

                    var query = await _context.Database.ExecuteSqlRawAsync(queryString);
                    //return strMessage;
                }
                //return "";
            }
            catch (Exception e)
            {
                File.WriteAllLines("execption", new string[] { ex.Message });
                Console.WriteLine(e);
                //  return "";
            }
        }
    }
}
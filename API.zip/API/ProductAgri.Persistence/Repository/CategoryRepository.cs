﻿using Microsoft.EntityFrameworkCore;
using ProductAgri.Domain;
using ProductAgri.Persistence.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductAgri.Persistence.Repository
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly AppDBContext context;

        public CategoryRepository(AppDBContext context)
        {
            this.context = context;
        }

        public async Task<TblCategory> AddAsync(TblCategory category)
        {
            try
            {
                await context.TblCategories.AddAsync(category);

                await context.SaveChangesAsync();

                return category;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create grain", ex);
            }
        }

        public async Task<List<TblCategory>> GetAsync(int pageSize, int pageNumber)
        {
            try
            {
                return await context.TblCategories.OrderByDescending(a => a.Id).Paginate(pageSize, pageNumber).ToListAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create grain", ex);
            }
        }

        public async Task<List<TblCategory>> GetAsync(int pageSize, int pageNumber, bool IsActive = true)
        {
            try
            {
                return await context.TblCategories.Where(a => a.Active == IsActive).OrderByDescending(a => a.Id).Paginate(pageSize, pageNumber).ToListAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create grain", ex);
            }
        }

        public async Task<TblCategory> GetAsync(int Id)
        {
            try
            {
                if (Id == 0)
                {
                    throw new CustomException("Category Id Cannot Be 0");
                }
                return await context.TblCategories.Where(a => a.Id == Id).FirstOrDefaultAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create grain", ex);
            }
        }

        public async Task<TblCategory> GetAsync(string categoryName, int CategoryId = 0)
        {
            try
            {
                if (CategoryId == 0)
                {
                    return await context.TblCategories.Where(a => a.NameEng.Equals(categoryName) && a.Active).FirstOrDefaultAsync();
                }
                return await context.TblCategories.Where(a => a.NameEng.Equals(categoryName) && a.Id != CategoryId && a.Active).FirstOrDefaultAsync();
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create grain", ex);
            }
        }

        public async Task<TblCategory> RemoveAsync(TblCategory category)
        {
            try
            {
                context.TblCategories.Remove(category);

                await context.SaveChangesAsync();

                return category;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create grain", ex);
            }
        }

        public async Task<TblCategory> UpdateAsync(TblCategory category)
        {
            try
            {
                context.TblCategories.Update(category);

                await context.SaveChangesAsync();

                return category;
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Cannot Create grain", ex);
            }
        }
    }
}
﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using ProductAgri.Persistence;
using ProductAgri.Domain.Model;

namespace ProductAgri.Persistence
{
    public class SeedDatabase
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            var context = serviceProvider.GetRequiredService<AppDBContext>();
            context.Database.EnsureCreated();

            if (!context.TblAdminUsers.Any())
            {
                TblAdminUser user = new TblAdminUser()
                {
                    FirstName = "Admin",
                    LastName = "Product Agri",
                    Email = "Admin@admin.Com",
                    MobileNo = "99999999",
                    UserName = "99999999",
                    Password = PasswordEncryptDecrypt.Encrypt("111111"),
                    //RoleId = 1,
                    IsActive = true,
                    IsDelete = true,
                    CreatedDate = DateTime.UtcNow
                };
                context.TblAdminUsers.AddAsync(user);
                context.SaveChangesAsync();

            }
        }
    }
}
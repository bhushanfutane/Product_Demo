﻿

//USE[master]
//GO
///****** Object:  Database [flourdb]    Script Date: 28-Sep-20 11:52:03 AM ******/
//CREATE DATABASE[flourdb]
// CONTAINMENT = NONE
// ON  PRIMARY
//(NAME = N'flourdb', FILENAME = N'D:\rdsdbdata\DATA\flourdb.mdf' , SIZE = 14592KB , MAXSIZE = UNLIMITED, FILEGROWTH = 10 %)
// LOG ON
//(NAME = N'flourdb_log', FILENAME = N'D:\rdsdbdata\DATA\flourdb_log.ldf' , SIZE = 4224KB , MAXSIZE = 2048GB , FILEGROWTH = 10 %)
//GO
//ALTER DATABASE[flourdb] SET COMPATIBILITY_LEVEL = 140
//GO
//IF(1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
//begin
//EXEC[flourdb].[dbo].[sp_fulltext_database] @action = 'enable'
//end
//GO
//ALTER DATABASE[flourdb] SET ANSI_NULL_DEFAULT OFF
//GO
//ALTER DATABASE[flourdb] SET ANSI_NULLS OFF
//GO
//ALTER DATABASE[flourdb] SET ANSI_PADDING OFF
//GO
//ALTER DATABASE[flourdb] SET ANSI_WARNINGS OFF
//GO
//ALTER DATABASE[flourdb] SET ARITHABORT OFF
//GO
//ALTER DATABASE[flourdb] SET AUTO_CLOSE OFF
//GO
//ALTER DATABASE[flourdb] SET AUTO_SHRINK OFF
//GO
//ALTER DATABASE[flourdb] SET AUTO_UPDATE_STATISTICS ON
//GO
//ALTER DATABASE[flourdb] SET CURSOR_CLOSE_ON_COMMIT OFF
//GO
//ALTER DATABASE[flourdb] SET CURSOR_DEFAULT  GLOBAL
//GO
//ALTER DATABASE[flourdb] SET CONCAT_NULL_YIELDS_NULL OFF
//GO
//ALTER DATABASE[flourdb] SET NUMERIC_ROUNDABORT OFF
//GO
//ALTER DATABASE[flourdb] SET QUOTED_IDENTIFIER OFF
//GO
//ALTER DATABASE[flourdb] SET RECURSIVE_TRIGGERS OFF
//GO
//ALTER DATABASE[flourdb] SET DISABLE_BROKER
//GO
//ALTER DATABASE[flourdb] SET AUTO_UPDATE_STATISTICS_ASYNC OFF
//GO
//ALTER DATABASE[flourdb] SET DATE_CORRELATION_OPTIMIZATION OFF
//GO
//ALTER DATABASE[flourdb] SET TRUSTWORTHY OFF
//GO
//ALTER DATABASE[flourdb] SET ALLOW_SNAPSHOT_ISOLATION OFF
//GO
//ALTER DATABASE[flourdb] SET PARAMETERIZATION SIMPLE
//GO
//ALTER DATABASE[flourdb] SET READ_COMMITTED_SNAPSHOT OFF
//GO
//ALTER DATABASE[flourdb] SET HONOR_BROKER_PRIORITY OFF
//GO
//ALTER DATABASE[flourdb] SET RECOVERY FULL
//GO
//ALTER DATABASE[flourdb] SET  MULTI_USER
//GO
//ALTER DATABASE[flourdb] SET PAGE_VERIFY CHECKSUM
//GO
//ALTER DATABASE[flourdb] SET DB_CHAINING OFF
//GO
//ALTER DATABASE[flourdb] SET FILESTREAM(NON_TRANSACTED_ACCESS = OFF)
//GO
//ALTER DATABASE[flourdb] SET TARGET_RECOVERY_TIME = 0 SECONDS
//GO
//ALTER DATABASE[flourdb] SET DELAYED_DURABILITY = DISABLED
//GO
//ALTER DATABASE[flourdb] SET QUERY_STORE = OFF
//GO
//USE[flourdb]
//GO
///****** Object:  User [admin]    Script Date: 28-Sep-20 11:52:05 AM ******/
//CREATE USER[admin] FOR LOGIN[admin] WITH DEFAULT_SCHEMA =[dbo]
//GO
//ALTER ROLE[db_owner] ADD MEMBER[admin]
//GO
///****** Object:  UserDefinedFunction [dbo].[cfn_GetAdminSubGrainStock]    Script Date: 28-Sep-20 11:52:05 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO

//-- =============================================
//-- Author:		<Pradip warambhe>
//-- Create date: <11 March 2020>
//-- Description:	<Get SubGrain stock>
//-- =============================================
//CREATE FUNCTION[dbo].[cfn_GetAdminSubGrainStock]
//(
//   @SubgrainId int
//)
//RETURNS int
//AS
//BEGIN

//declare @Stock int
//set @Stock=0
//set @Stock = (select isnull(Stock,0) from(
//  Select Total.GrainCategoryId, (Isnull(TotalQuantity,0)-ISNULL(ReleaseQuantity,0)) as Stock from(Select GrainCategoryId, Sum(Quantity) as TotalQuantity from tblStockDetail
//   group by GrainCategoryId) Total
//  left join(
//  Select GrainCategoryId, Sum(Quantity) as ReleaseQuantity from tblGPartnerStockDetail GPSD
//  inner join tblGPartnerStock GPS on GPS.Id= GPSD.GPartnerStockId
//  --where GPS.Status= 1
//  group by  GrainCategoryId ) Release
//  on Total.GrainCategoryId=Release.GrainCategoryId
//  where Total.GrainCategoryId=@SubgrainId)
//as s)
	

//RETURN isnull(@Stock,0);

//END
//GO
///****** Object:  UserDefinedFunction [dbo].[cfn_GetSubGrainStock]    Script Date: 28-Sep-20 11:52:06 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//-- =============================================
//-- Author:		<Pradip warambhe>
//-- Create date: <11 March 2020>
//-- Description:	<Get SubGrain stock>
//-- =============================================
//CREATE FUNCTION[dbo].[cfn_GetSubGrainStock]
//(
//   @SubgrainId int,
//	@GPId int
//)
//RETURNS int
//AS
//BEGIN

//declare @Stock int
//set @Stock=0
//set @Stock = (select isnull(Stock,0) from(
//  select GSD.GrainCategoryId, Sum(GSD.Quantity) as Stock from tblGPartnerStockDetail GSD
//  inner join


//   tblGPartnerStock GS on GS.Id= GSD.GPartnerStockId


//   where Gs.Status= 1 and GPartnerId = @GPId and GSD.GrainCategoryId= @SubgrainId


//   group by GSD.GrainCategoryId)
//as s)
	

//RETURN isnull(@Stock,0);

//END
//GO
///****** Object:  Table [dbo].[tblSubOrderDetail]    Script Date: 28-Sep-20 11:52:06 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblSubOrderDetail]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [OrderDetailId] [int] NULL,
//	[GrainCategoryId] [int] NULL,
//	[Quantity] [decimal] (18, 2) NULL,
//	[Price] [decimal] (18, 2) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK_tblSubOrderDetail] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblGPartnerStock]    Script Date: 28-Sep-20 11:52:06 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblGPartnerStock]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [AssignedById] [int] NULL,
//	[GPatnerId] [int] NULL,
//	[BillNumber] [nvarchar] (150) NULL,
//	[Status] [int] NULL,
//	[StatusUpdateDate] [datetime] NULL,
//	[DocumentPath] [nvarchar] (250) NULL,
//	[TotalPrice] [decimal] (18, 2) NULL,
//	[Tax] [decimal] (18, 2) NULL,
//	[CreatedDate] [datetime] NULL,
//	[DeliverdBy] [nvarchar] (100) NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[IsAcceptByBP] [bit] NULL,
// CONSTRAINT[PK_tblGPartnerStock] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblGPartnerStockDetail]    Script Date: 28-Sep-20 11:52:07 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblGPartnerStockDetail]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [GPartnerId] [int] NULL,
//	[GrainCategoryId] [int] NULL,
//	[Quantity] [decimal] (18, 2) NULL,
//	[Price] [decimal] (18, 2) NULL,
//	[GPartnerStockId] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK_tblGPartnerStockDetail] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblGPStockCapacity]    Script Date: 28-Sep-20 11:52:07 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblGPStockCapacity]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [GPId] [int]
//NOT NULL,

//  [GrainCategoryId] [int] NULL,
//	[CapacityInKg] [int] NULL,
//	[minPercentage] [decimal] (5, 2) NULL,
//	[UpdatedDate] [datetime] NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK_tblGPStockCapacity] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblGrain]    Script Date: 28-Sep-20 11:52:07 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblGrain]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [Name_ENG] [nvarchar] (50) NOT NULL,

//   [Name_MAR] [nvarchar] (50) NOT NULL,

//    [Name_HIN] [nvarchar] (50) NOT NULL,


//     [ImagePath] [nvarchar] (50) NULL,
//	[Active]
//[bit]
//NOT NULL,

//    [IsDelete] [bit] NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK_tblGrain] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblGrainCategory]    Script Date: 28-Sep-20 11:52:07 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblGrainCategory]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [GrainId] [int] NULL,
//	[Name_ENG] [nvarchar] (50) NULL,
//	[Name_MAR] [nvarchar] (50) NULL,
//	[Name_HIN] [nvarchar] (50) NULL,
//	[ImagePath] [nvarchar] (100) NULL,
//	[Price] [decimal] (18, 2) NULL,
//	[Active] [bit] NULL,
//	[IsDelete] [bit] NULL,
//	[Discription] [nvarchar] (500) NULL,
//	[minStock] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK_GrainType] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblOrder]    Script Date: 28-Sep-20 11:52:08 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblOrder]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [UserId] [int] NULL,
//	[OrderDate] [datetime] NULL,
//	[Amount] [decimal] (18, 2) NULL,
//	[OrderNo] [nvarchar] (50) NULL,
//	[DeliveryCharges] [decimal] (18, 0) NULL,
//	[TotalAmount] [decimal] (18, 0) NULL,
//	[PaymentStatus] [int] NULL,
//	[InVoiceNo] [nvarchar] (50) NULL,
//	[Discount] [decimal] (18, 0) NULL,
//	[Address] [nvarchar] (1000) NULL,
//	[Pincode] [nvarchar] (10) NULL,
//	[AreaCode] [nvarchar] (5) NULL,
//	[ContactNo] [nvarchar] (15) NULL,
//	[PaymentMode] [int] NULL,
//	[GpartnerId] [int] NULL,
//	[DeliverySlotId] [int] NULL,
//	[Email] [nvarchar] (50) NULL,
//	[CreatedDate] [datetime] NULL,
//	[Updateddate] [datetime] NULL,
//	[CraetedBy] [int] NULL,
//	[UpdatedBy] [int] NULL,
//	[OrderStatus] [int] NULL,
//	[AreaID] [int] NULL,
//	[BagNo] [nvarchar] (50) NULL,
//	[DeliveryDate] [datetime] NULL,
//	[DeliveryNote] [nvarchar] (1500) NULL,
//	[OTP] [nvarchar] (10) NULL,
//	[ReturnReason] [nvarchar] (1000) NULL,
//	[ConvCharges] [decimal] (18, 2) NULL,
//	[GstAmount] [decimal] (18, 2) NULL,
//	[WalletAmount] [decimal] (18, 2) NULL,
//	[OrderPlacedFrom] [int] NULL,
//	[TotalGrindingAmount] [decimal] (18, 2) NULL,
//	[GrindingAmountPaidStatus] [int] NULL,
//	[OrderCompleteDate] [datetime] NULL,
//	[DeliverStatus] [int] NULL,
//	[DeliveryBoyId] [int] NULL,
//	[DeliveryboyPaymnetStatus] [int] NULL,
// CONSTRAINT[PK_tblOrder] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblOrderDetail]    Script Date: 28-Sep-20 11:52:08 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblOrderDetail]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [OrderId] [int] NULL,
//	[ProductId] [int] NULL,
//	[Quantity] [int] NULL,
//	[Amount] [decimal] (18, 2) NULL,
//	[Size] [int] NULL,
//	[GrindingType] [int] NULL,
//	[ProductType] [int] NULL,
//	[Discount] [decimal] (18, 2) NULL,
//	[MRP] [decimal] (18, 2) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[TotalAmount] [decimal] (18, 2) NULL,
//	[Weight] [decimal] (18, 2) NULL,
//	[GrindingCharges] [decimal] (18, 2) NULL,
//	[IsRefund] [bit] NULL,
// CONSTRAINT[PK_tblOrderDetail] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  UserDefinedFunction [dbo].[fun_gpstocklist]    Script Date: 28-Sep-20 11:52:08 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO

//-- =============================================
//-- Author:		<Pradip Warambhe>
//-- Create date: <18 july 2020>
//-- Description:	<get bussiness partner stock list>
//-- =============================================
//CREATE FUNCTION[dbo].[fun_gpstocklist]
//(
//@GPartnerId int
//)
//RETURNS TABLE
//AS
//RETURN
//(

//Select G.Name_ENG as Grain, GC.Name_ENG as GrainCategory, (isnull(Total.Quantity,0) -isnull(Sold.Quantity,0) )as Stock,isnull(Total.Quantity,0) as Total_Quantity,isnull(Sold.Quantity,0) as Sold_Quantity from tblGrainCategory GC
//left join
//(Select GrainCategoryId, Sum(isnull(Quantity,0)) as Quantity from tblGPartnerStockDetail GSD
//inner Join tblGPartnerStock GS on GS.Id= GSD.GPartnerStockId
//where GS.Status= 1 and GS.GPatnerId= @GPartnerId group by GrainCategoryId ) as Total on GC.id=Total.GrainCategoryId
//  left join(
//  Select SOD.GrainCategoryId, SUM(SOD.Quantity* OD.Size) as Quantity from tblSubOrderDetail SOD inner join tblOrderDetail OD on SOD.OrderDetailId=OD.Id
//    inner join tblOrder O on OD.OrderId= O.Id where (O.OrderStatus= 7 or O.OrderStatus= 5)  and O.GpartnerId=@GPartnerId
//       group by SOD.GrainCategoryId ) as Sold on GC.Id=Sold.GrainCategoryId
//      left join(Select GrainCategoryId, cast (CapacityInKg as decimal )as CapacityInKg  ,minPercentage from tblGPStockCapacity where GPId=@GPartnerId) as Capacity on Capacity.GrainCategoryId=Gc.Id
//      inner join tblGrain G on GC.GrainId=G.Id
//)
//GO
///****** Object:  Table [dbo].[tblAdminNotification]    Script Date: 28-Sep-20 11:52:08 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblAdminNotification]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [Message] [nvarchar] (500) NULL,
//	[OrderId] [int] NULL,
//	[OrderStatus] [int] NULL,
//	[IsRead] [bit] NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
// CONSTRAINT[PK_tblAdminNotification] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblAdminUser]    Script Date: 28-Sep-20 11:52:08 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblAdminUser]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [FirstName] [nvarchar] (50) NULL,
//	[LastName] [nvarchar] (50) NULL,
//	[UserName] [nvarchar] (50) NULL,
//	[Email] [nvarchar] (50) NULL,
//	[IsVerify]
//[bit]
//NOT NULL,

//    [MobileNo] [nvarchar] (15) NULL,
//	[RoleId] [int] NULL,
//	[Address] [nvarchar] (500) NULL,
//	[Password] [nvarchar] (100) NULL,
//	[Otp] [nchar] (10) NULL,
//	[OtpExpireTime] [datetime] NULL,
//	[RegistrationDate] [date] NULL,
//	[CreatedBy] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[AreaId] [int] NULL,
//	[AreaCode] [nvarchar] (50) NULL,
//	[IsActive]
//[bit]
//NOT NULL,

//    [IsDelete] [bit] NULL,
//	[profilepath] [nvarchar] (50) NULL,
//	[SalaryGradeId] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK_tblAdminUser] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblApplyGpartner]    Script Date: 28-Sep-20 11:52:08 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblApplyGpartner]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [FullName] [nvarchar] (100) NULL,
//	[MobileNo] [nvarchar] (15) NULL,
//	[Address] [nvarchar] (500) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[Lat] [nvarchar] (50) NULL,
//	[Long] [nvarchar] (50) NULL,
//	[Status] [int] NULL,
// CONSTRAINT[PK_tblApplyGpartner] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblArea]    Script Date: 28-Sep-20 11:52:09 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblArea]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [CityId] [int] NULL,
//	[AreaName_ENG] [nvarchar] (100) NULL,
//	[AreaName_MAR] [nvarchar] (100) NULL,
//	[AreaName_HIN] [nvarchar] (100) NULL,
//	[PinCode] [nvarchar] (10) NULL,
//	[AreaCode] [nvarchar] (100) NULL,
//	[IsAvailable]
//[bit]
//NOT NULL,

//    [IsActive] [bit]
//NOT NULL,

//    [HolidayId] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[MultiGrainGrindingCharges] [decimal] (18, 2) NULL,
//	[RecipeGrindingCharges] [decimal] (18, 2) NULL,
// CONSTRAINT[PK__tblArea__3214EC07DF4CE21B] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblAreaRateBoard]    Script Date: 28-Sep-20 11:52:09 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblAreaRateBoard]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [AreaId] [int]
//NOT NULL,

//  [GrainId] [int]
//NOT NULL,

//  [Rate] [decimal] (5, 2) NOT NULL,

//   [UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
// CONSTRAINT[PK_tblAreaRateBoard] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[TblBanner]    Script Date: 28-Sep-20 11:52:09 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[TblBanner]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [TypeId] [int]
//NOT NULL,

//  [BannerPath] [nvarchar] (200) NOT NULL,

//   [StartDate] [datetime] NULL,
//	[EndDate] [datetime] NULL,
//	[IsMobile] [bit] NULL,
//	[IsDefault] [bit] NULL,
//	[RedirectionId] [int] NULL,
//	[Createdby] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
// CONSTRAINT[PK__TblBanne__3214EC07820631D1] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblCart]    Script Date: 28-Sep-20 11:52:10 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblCart]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [UserId] [int] NULL,
//	[ProductTypeId] [int] NULL,
//	[ProductId] [int] NULL,
//	[Size] [int] NULL,
//	[GrindingType] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[DiscountPercentage] [decimal] (18, 2) NULL,
// CONSTRAINT[PK_tblCart] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblCity]    Script Date: 28-Sep-20 11:52:10 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblCity]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [CityName_ENG] [nvarchar] (100) NULL,
//	[CityName_MAR] [nvarchar] (100) NULL,
//	[CityName_HIN] [nvarchar] (100) NULL,
//	[IsActive]
//[bit]
//NOT NULL,

//    [CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK__tblCity__3214EC07AB21A9CF] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblComplaint]    Script Date: 28-Sep-20 11:52:11 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblComplaint]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [UserId] [int] NULL,
//	[OrderId] [int] NULL,
//	[ComplaintType] [int] NULL,
//	[ComplaintCode] [nvarchar] (50) NULL,
//	[Discription] [nvarchar] (2000) NULL,
//	[Status] [int] NULL,
//	[Assign_To] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[ReSolution] [int] NULL,
//	[ResolutionRemark] [nvarchar] (2000) NULL,
//	[ImageUrl] [nvarchar] (50) NULL,
// CONSTRAINT[PK_tblComplaint] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblDeliverBoy]    Script Date: 28-Sep-20 11:52:11 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblDeliverBoy]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [DB_Id] [nvarchar] (50) NULL,
//	[FirstName] [nvarchar] (50) NULL,
//	[LastName] [nvarchar] (50) NULL,
//	[Joining_Date] [datetime] NULL,
//	[Address] [nvarchar] (500) NULL,
//	[Mobile_1] [nvarchar] (15) NULL,
//	[Mobile_2] [nvarchar] (15) NULL,
//	[AreaId] [int] NULL,
//	[Active]
//[bit]
//NOT NULL,

//    [Email] [nvarchar] (50) NULL,
//	[UserName] [nvarchar] (50) NULL,
//	[Password] [nvarchar] (100) NULL,
//	[CreatedBy] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[IsSytemGeneratedCredential] [bit] NULL,
//	[Otp] [nvarchar] (10) NULL,
//	[OtpExpireTime] [datetime] NULL,
//	[ImageUrl] [nvarchar] (100) NULL,
//	[profilepath] [nvarchar] (50) NULL,
//	[SalaryGradeId] [int] NULL,
//	[BankName] [nvarchar] (100) NULL,
//	[IFSCCode] [nvarchar] (50) NULL,
//	[Branch] [nvarchar] (20) NULL,
//	[AccNo] [nvarchar] (50) NULL,
// CONSTRAINT[PK_tblDeliverBoy] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblDeliveryBoyArea]    Script Date: 28-Sep-20 11:52:11 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblDeliveryBoyArea]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [DeliveryBoyId] [int]
//NOT NULL,

//  [AreaId] [int]
//NOT NULL,
//CONSTRAINT[PK_tblDeliveryBoyArea] PRIMARY KEY CLUSTERED
//(
// [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblDeliveryBoyOrder]    Script Date: 28-Sep-20 11:52:11 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblDeliveryBoyOrder]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [GpartnerId] [int] NULL,
//	[OrderId] [int] NULL,
//	[UserId] [int] NULL,
//	[DeliveryBoyId] [int] NULL,
//	[DeliveryStatus] [int] NULL,
//	[Date] [datetime] NULL,
//	[Km] [decimal] (18, 2) NULL,
//	[Weight] [decimal] (18, 2) NULL,
//	[KmperUnit] [decimal] (18, 2) NULL,
//	[Weightperunit] [decimal] (18, 2) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[Reason] [nvarchar] (500) NULL,
// CONSTRAINT[PK_tblDeliveryBoyOrder] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblDeliveryBoyPayment]    Script Date: 28-Sep-20 11:52:12 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblDeliveryBoyPayment]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [DeliverBoyId] [int] NULL,
//	[Amount] [decimal] (18, 0) NULL,
//	[Date] [datetime] NULL,
//	[Basic] [decimal] (18, 0) NULL,
//	[OrderAmount] [decimal] (18, 0) NULL,
//	[Month] [int] NULL,
//	[CreatedBy] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//PRIMARY KEY CLUSTERED
//(
//    [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblDeliveryCharges]    Script Date: 28-Sep-20 11:52:12 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblDeliveryCharges]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [Weight] [decimal] (18, 2) NULL,
//	[Km] [decimal] (18, 2) NULL,
//	[Charges] [decimal] (18, 2) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK_tblDeliveryCharges] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblDeliverySlot]    Script Date: 28-Sep-20 11:52:13 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblDeliverySlot]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [Shr] [int] NULL,
//	[Smn] [int] NULL,
//	[Sampm] [nvarchar] (2) NOT NULL,


//     [Discription] [nvarchar] (100) NULL,
//	[Ehr] [int] NULL,
//	[Emn] [int] NULL,
//	[Eampm] [nvarchar] (2) NULL,
//	[IsActive]
//[bit]
//NOT NULL,

//    [CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK__tblDeliv__3214EC071F363D97] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblDocument]    Script Date: 28-Sep-20 11:52:13 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblDocument]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [EmployeeType] [int] NULL,
//	[EmployeeId] [int] NULL,
//	[DocType] [int] NULL,
//	[Path] [nvarchar] (100) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK_tblDocument] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblDPartnerPaymentRelease]    Script Date: 28-Sep-20 11:52:13 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblDPartnerPaymentRelease]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [DeliveryBoyId] [int] NULL,
//	[Status] [int] NULL,
//	[TotalAmount] [decimal] (18, 0) NULL,
//	[ReleaseDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[ReleaseNumber] [nvarchar] (50) NULL,
//	[TransactionNumber] [nvarchar] (50) NULL,
// CONSTRAINT[PK_DPartnerPaymentRelease] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblDPartnerPaymentReleaseDetail]    Script Date: 28-Sep-20 11:52:14 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblDPartnerPaymentReleaseDetail]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [ReleasePaymentId] [int] NULL,
//	[OrderId] [int] NULL,
//	[Amount] [decimal] (18, 2) NULL,
//	[Weight] [decimal] (18, 2) NULL,
//	[Distance] [decimal] (18, 2) NULL,
//	[Createddate] [datetime] NULL,
// CONSTRAINT[PK_tblDPartnerPaymentReleaseDetail] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblExceptionLogItems]    Script Date: 28-Sep-20 11:52:14 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblExceptionLogItems]
//(

//   [EventId][int] IDENTITY(1,1) NOT NULL,

//  [LogDateTime] [nvarchar] (300) NULL,
//	[Source] [char] (100) NULL,
//	[Message] [varchar] (1000) NULL,
//	[QueryString] [varchar] (2000) NULL,
//	[TargetSite] [varchar] (300) NULL,
//	[StackTrace] [varchar] (4000) NULL,
//	[ServerName] [varchar] (250) NULL,
//	[RequestURL] [varchar] (300) NULL,
//	[UserAgent] [varchar] (300) NULL,
//	[UserIP] [varchar] (300) NULL,
//	[UserAuthentication] [varchar] (300) NULL,
//	[UserName] [varchar] (300) NULL,
// CONSTRAINT[PK_tblExceptionLogItems] PRIMARY KEY CLUSTERED
//(
//   [EventId] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblGoogleDistance]    Script Date: 28-Sep-20 11:52:14 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblGoogleDistance]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [Origin] [nvarchar] (100) NULL,
//	[Destination] [nvarchar] (100) NULL,
//	[Distance] [decimal] (18, 3) NULL,
//	[CreatedDate] [datetime] NULL,
// CONSTRAINT[PK_tblGoogleDistance] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblGPartner]    Script Date: 28-Sep-20 11:52:15 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblGPartner]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [FirstName] [nvarchar] (150) NULL,
//	[LastName] [nvarchar] (150) NULL,
//	[EstablishedYear] [datetime] NULL,
//	[OwnerEmail] [nvarchar] (150) NULL,
//	[Address] [nvarchar] (250) NULL,
//	[Contact1] [nvarchar] (20) NULL,
//	[Contact2] [nvarchar] (20) NULL,
//	[ImagePath] [nvarchar] (250) NULL,
//	[GP_LocationCode] [nvarchar] (250) NULL,
//	[IsOwnerOperator] [bit] NULL,
//	[Pincode] [nvarchar] (10) NULL,
//	[EmployeeFirstName] [nvarchar] (250) NULL,
//	[EmployeeLastName] [nvarchar] (250) NULL,
//	[EmployeeContact1] [nvarchar] (50) NULL,
//	[EmployeeContact2] [nvarchar] (50) NULL,
//	[EmployeeEmail] [nvarchar] (150) NULL,
//	[EmployeeBirthDate] [datetime] NULL,
//	[NoOfMachine] [int] NULL,
//	[AreaOfShop] [nvarchar] (250) NULL,
//	[MillName] [nvarchar] (250) NULL,
//	[ShedType] [int] NULL,
//	[DoesOperatorChewTobaco] [bit] NULL,
//	[DoesOperatorHaveAnyDesease] [bit] NULL,
//	[OwnerBirthDate] [datetime] NULL,
//	[ProductTypeId] [int] NULL,
//	[GPCode] [nvarchar] (10) NULL,
//	[IsDelete] [bit] NULL,
//	[UserName] [nvarchar] (150) NULL,
//	[Password] [nvarchar] (100) NULL,
//	[Otp] [nvarchar] (10) NULL,
//	[OtpExpireTime] [datetime] NULL,
//	[IsVerified] [bit] NULL,
//	[AreaId] [int] NULL,
//	[IsSytemGeneratedCredential] [bit] NULL,
//	[Lat_Lang] [nvarchar] (50) NULL,
//	[IsActive]
//[bit]
//NOT NULL,

//    [ShopActNo] [nvarchar] (50) NULL,
//	[FssaiNo] [nvarchar] (50) NULL,
//	[IFSC] [nvarchar] (50) NULL,
//	[BankName] [nvarchar] (100) NULL,
//	[AccNo] [nvarchar] (50) NULL,
//	[BranchName] [nvarchar] (50) NULL,
//	[Discription] [nvarchar] (1000) NULL,
//	[VerifiedBy] [int] NULL,
//	[VerificationFomPath] [nvarchar] (50) NULL,
//	[profilepath] [nvarchar] (50) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[MultiGrainGrindingCharges] [decimal] (18, 2) NULL,
//	[RecipeGrindingCharges] [decimal] (18, 2) NULL,
//	[AreaCode] [nvarchar] (5) NULL,
// CONSTRAINT[PK_tblGPartner] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblGPartnerOrder]    Script Date: 28-Sep-20 11:52:15 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblGPartnerOrder]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [OrderId] [int] NULL,
//	[GPartnerId] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[StatusId] [int] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[Reason] [nvarchar] (500) NULL,
// CONSTRAINT[PK_tblGPartnerOrder] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblGpartnerPassReason]    Script Date: 28-Sep-20 11:52:15 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblGpartnerPassReason]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [GpartnerId] [int] NULL,
//	[OrderId] [int] NULL,
//	[ReasonId] [int] NULL,
//	[ReasonText] [nvarchar] (500) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK_tblGpartnerPassReason] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblGpartnerPayment]    Script Date: 28-Sep-20 11:52:16 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblGpartnerPayment]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [GpartnerId] [int] NULL,
//	[Amount] [decimal] (18, 0) NULL,
//	[Date] [datetime] NULL,
//	[PaymentType] [int] NULL,
//	[TransactionNo] [nvarchar] (50) NULL,
//	[Remark] [nvarchar] (500) NULL,
//	[CreatedBy] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
// CONSTRAINT[PK_tblGpartnerPayment] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblGPartnerPaymentRelease]    Script Date: 28-Sep-20 11:52:16 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblGPartnerPaymentRelease]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [GPartnerId] [int] NULL,
//	[TotalAmount] [decimal] (18, 2) NULL,
//	[PaymentStatus] [int] NULL,
//	[PaymentReleaseDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[ReleaseNumber] [nvarchar] (10) NULL,
//	[TransactionNumber] [nvarchar] (50) NULL,
// CONSTRAINT[PK_tblGPartnerPaymentRelease] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[TblGpartnerPaymentReleaseDetail]    Script Date: 28-Sep-20 11:52:16 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[TblGpartnerPaymentReleaseDetail]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [ReleasePaymentId] [int] NULL,
//	[OrderId] [int] NULL,
//	[Amount] [decimal] (18, 0) NULL,
// CONSTRAINT[PK_TblGpartnerPaymentReleaseDetail] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblGPHoliday]    Script Date: 28-Sep-20 11:52:16 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblGPHoliday]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [GPId] [int]
//NOT NULL,

//  [DayId] [int]
//NOT NULL,

//  [IsHoliday] [bit]
//NOT NULL,

//  [UpdatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
// CONSTRAINT[PK_tblGPHoliday] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblGrade]    Script Date: 28-Sep-20 11:52:17 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblGrade]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [Gradecode] [nvarchar] (50) NULL,
//	[IsActive]
//[bit]
//NOT NULL,

//    [Salary] [decimal] (18, 2) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//PRIMARY KEY CLUSTERED
//(
//    [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblGrinderRateBoard]    Script Date: 28-Sep-20 11:52:17 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblGrinderRateBoard]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [GpId] [int]
//NOT NULL,

//  [GrainId] [int] NULL,
//	[Rate] [decimal] (5, 2) NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
// CONSTRAINT[PK_tblGrinderRateBoard] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblHelpAndSupport]    Script Date: 28-Sep-20 11:52:17 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblHelpAndSupport]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [UserId] [int] NULL,
//	[Subject] [nvarchar] (250) NULL,
//	[Message] [nvarchar] (250) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[Ordered] [int] NULL,
//	[Status] [int] NULL,
//	[AlternateContactNumber] [nvarchar] (15) NULL,
//PRIMARY KEY CLUSTERED
//(
//    [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblNotification]    Script Date: 28-Sep-20 11:52:17 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblNotification]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [DeviceToken] [nvarchar] (max) NOT NULL,
//	[UserId]
//[int]
//NOT NULL,

//    [ActorId] [int]
//NOT NULL,

//    [FromDeviceId] [int] NULL,
//PRIMARY KEY CLUSTERED
//(
//    [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY] TEXTIMAGE_ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblOrderBagnumber]    Script Date: 28-Sep-20 11:52:17 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblOrderBagnumber]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [BagNumber] [nvarchar] (50) NULL,
//	[OrderId] [int] NULL,
//	[GpartnerId] [int] NULL,
//	[UserId] [int] NULL,
//	[IsPickedUp] [bit] NULL,
//	[IsDeliverd] [bit] NULL,
//	[CreatedBy] [int] NULL,
//	[Createddate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
// CONSTRAINT[PK_tblOrderBagnumber] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblPage]    Script Date: 28-Sep-20 11:52:18 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblPage]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [Page] [nvarchar] (50) NULL,
//	[Module] [nvarchar] (50) NULL,
// CONSTRAINT[PK_tblPage] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY],
//UNIQUE NONCLUSTERED
//(
//    [Page] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblPageAccess]    Script Date: 28-Sep-20 11:52:18 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblPageAccess]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [PageId] [int] NULL,
//	[RoleId] [int] NULL,
//	[IsWrite] [bit] NULL,
//	[IsRead] [bit] NULL,
// CONSTRAINT[PK_tblPageAccess] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblPincodeArea]    Script Date: 28-Sep-20 11:52:18 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblPincodeArea]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [pincode] [nvarchar] (10) NULL,
//	[AreaName] [nvarchar] (100) NULL,
//	[CreatedDate] [datetime] NULL,
//	[district] [nvarchar] (50) NULL,
// CONSTRAINT[PK_tblPincodeArea] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblProduct]    Script Date: 28-Sep-20 11:52:19 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblProduct]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [Name_ENG] [nvarchar] (100) NOT NULL,

//   [Name_MAR] [nvarchar] (100) NOT NULL,

//    [Name_HIN] [nvarchar] (100) NOT NULL,


//     [TypeId] [int] NULL,
//	[Price] [decimal] (8, 2) NULL,
//	[Tax] [decimal] (18, 2) NULL,
//	[Active]
//[bit]
//NOT NULL,

//    [IsDelete] [bit] NULL,
//	[CreatedBy] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[TotalPrice] [decimal] (5, 2) NULL,
//	[ImageUrl] [nvarchar] (100) NULL,
//	[Discription] [nvarchar] (2000) NULL,
//	[Discription_Hn] [nvarchar] (2000) NULL,
//	[Discription_Mr] [nvarchar] (2000) NULL,
//	[MRP] [decimal] (18, 2) NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[UserId] [int] NULL,
//	[Weight] [decimal] (18, 2) NULL,
// CONSTRAINT[PK_tblProduct] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[TblProductDetail]    Script Date: 28-Sep-20 11:52:19 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[TblProductDetail]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [ProductId] [int] NULL,
//	[GrainCategoryId] [int] NULL,
//	[Quantity] [decimal] (5, 3) NULL,
//	[Price] [decimal] (18, 2) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK_TblProductDetail] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblProductImages]    Script Date: 28-Sep-20 11:52:19 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblProductImages]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [ProductId] [int] NULL,
//	[ImagePath] [nvarchar] (50) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK_tblProductImages] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[TblProductType]    Script Date: 28-Sep-20 11:52:20 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[TblProductType]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [ProductType] [nvarchar] (50) NULL,
//	[IsActive] [bit] NULL,
//	[Description] [nvarchar] (100) NULL,
// CONSTRAINT[PK_TblProductType] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblProSet]    Script Date: 28-Sep-20 11:52:20 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblProSet]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [Name] [nvarchar] (250) NOT NULL,

//   [SettingKey] [nvarchar] (250) NOT NULL,

//    [SettingValue] [nvarchar] (500) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[Description] [nvarchar] (500) NULL,
// CONSTRAINT[PK_tblProSet] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblRating]    Script Date: 28-Sep-20 11:52:20 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblRating]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [UserId] [int] NULL,
//	[OrderId] [int] NULL,
//	[QualityRating] [int] NULL,
//	[ServiceRating] [int] NULL,
//	[Remark] [nvarchar] (500) NULL,
//	[CreatedBy] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
// CONSTRAINT[PK_tblRatingReview] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblReturnReason]    Script Date: 28-Sep-20 11:52:21 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblReturnReason]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [Reason] [nvarchar] (200) NULL,
//	[IsActive]
//[bit]
//NOT NULL,

//    [UserType] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[ReasonMar] [nvarchar] (200) NULL,
//	[ReasonHin] [nvarchar] (200) NULL,
// CONSTRAINT[PK_tblReturnReason] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblReview]    Script Date: 28-Sep-20 11:52:21 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblReview]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [UserId] [int] NULL,
//	[ProductId] [int] NULL,
//	[Review] [nvarchar] (500) NULL,
//	[IsShowonSite] [bit] NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
// CONSTRAINT[PK_tblReview] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblSaveForLater]    Script Date: 28-Sep-20 11:52:21 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblSaveForLater]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [UserId] [int] NULL,
//	[ProductId] [int] NULL,
//	[ProductTypeId] [int] NULL,
//	[Quantity] [int] NULL,
//	[Amount] [decimal] (18, 2) NULL,
//	[Size] [int] NULL,
//	[GrindingType] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK_tblSaveForLater] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblShed]    Script Date: 28-Sep-20 11:52:22 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblShed]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [ShedType] [nvarchar] (50) NULL,
// CONSTRAINT[PK_Table_1] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblStock]    Script Date: 28-Sep-20 11:52:22 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblStock]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [VendorId] [int] NULL,
//	[Date] [datetime] NULL,
//	[Amount] [decimal] (18, 2) NULL,
//	[TaxAmount] [decimal] (18, 2) NULL,
//	[Percentage] [decimal] (18, 2) NULL,
//	[CreatedBy] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[ModifiedBy] [int] NULL,
//	[ModifiedDate] [datetime] NULL,
//	[BillNo] [nvarchar] (50) NULL,
//	[DocumentPath] [nvarchar] (250) NULL,
//	[TotalPrice] [decimal] (18, 2) NULL,
//	[Discription] [nvarchar] (500) NULL,
// CONSTRAINT[PK__tblStock__3214EC0743E86123] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblStockDetail]    Script Date: 28-Sep-20 11:52:22 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblStockDetail]
//(

//   [id][int] IDENTITY(1,1) NOT NULL,

//  [StockId] [int] NULL,
//	[GrainCategoryId] [int] NULL,
//	[Quantity] [decimal] (18, 2) NULL,
//	[PricePerUnit] [decimal] (18, 2) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK_tblStockDetail] PRIMARY KEY CLUSTERED
//(
//   [id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblTransaction]    Script Date: 28-Sep-20 11:52:23 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblTransaction]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [OrderId] [int] NULL,
//	[TransactionOrderId] [nvarchar] (50) NULL,
//	[PaymentStatus] [int] NULL,
//	[Price] [decimal] (18, 0) NULL,
//	[CreatedDate] [datetime] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[razororderid] [nvarchar] (50) NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK__tblTrans__3214EC07A779D041] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblUser]    Script Date: 28-Sep-20 11:52:23 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblUser]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [UserName] [nvarchar] (50) NULL,
//	[FirstName] [nvarchar] (50) NULL,
//	[LastName] [nvarchar] (50) NULL,
//	[Email] [nvarchar] (50) NULL,
//	[IsEmailVerified] [bit] NULL,
//	[Mobile] [nvarchar] (15) NULL,
//	[IsMobileVerified] [bit] NULL,
//	[Password] [nvarchar] (100) NULL,
//	[Otp] [nchar] (10) NULL,
//	[OtpExpiredTime] [datetime] NULL,
//	[IsOtpVerified] [bit] NULL,
//	[ExtranallogintypeId] [int] NULL,
//	[Extranallogin_Token]
//[nvarchar]
//(max) NULL,

//    [CreatedDate] [datetime] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[DefaultLanguage] [nvarchar] (5) NULL,
//	[BirthDate] [datetime] NULL,
//	[ReferedBy] [int] NULL,
//	[RegistationDate] [nchar] (10) NULL,
//	[Cust_Id] [nvarchar] (50) NULL,
//	[profilepath] [nvarchar] (50) NULL,
//	[Pincode] [nvarchar] (10) NULL,
//	[AreaName] [nvarchar] (50) NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedBy] [int] NULL,
//	[RegisteredFrom] [int] NULL,
//	[IsActive] [bit] NULL,
//	[ReferCode] [nvarchar] (50) NULL,
// CONSTRAINT[PK_tblUser] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY] TEXTIMAGE_ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblUserAddress]    Script Date: 28-Sep-20 11:52:23 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblUserAddress]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [UserId] [int]
//NOT NULL,

//  [HouseNo] [nvarchar] (100) NULL,
//	[AppartmentName] [nvarchar] (100) NULL,
//	[StreetDetails] [nvarchar] (200) NULL,
//	[Landmark] [nvarchar] (250) NULL,
//	[CityId] [int] NULL,
//	[AreaName] [nvarchar] (50) NULL,
//	[Pincode] [nvarchar] (10) NULL,
//	[AddressType] [int] NULL,
//	[niknameAddress] [nvarchar] (150) NULL,
//	[Isdefault] [bit] NULL,
//	[Latitude] [nvarchar] (50) NULL,
//	[Longitude] [nvarchar] (50) NULL,
//	[AreaCode] [nvarchar] (50) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[AreaId] [int] NULL,
//	[PlaceId] [nvarchar] (50) NULL,
// CONSTRAINT[PK_tblUserAddress] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblUserRegistration]    Script Date: 28-Sep-20 11:52:24 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblUserRegistration]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [FirstName] [nvarchar] (100) NULL,
//	[LastName] [nvarchar] (100) NULL,
//	[UserName] [nvarchar] (50) NULL,
//	[Password] [nvarchar] (100) NULL,
//	[IsMobile]
//[bit]
//NOT NULL,

//    [Otp] [nchar] (10) NULL,
//	[IsVerified] [bit] NULL,
//	[OtpExpire] [datetime] NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK_tblUserRegistration] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblVendor]    Script Date: 28-Sep-20 11:52:24 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblVendor]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [VendorName] [nvarchar] (100) NULL,
//	[Address] [nvarchar] (500) NULL,
//	[VendorCode] [nvarchar] (10) NULL,
//	[OwnerContactNo] [nvarchar] (15) NULL,
//	[ContactPersonMobNo] [nvarchar] (15) NULL,
//	[Active] [bit] NULL,
//	[ContactPersonName] [nvarchar] (150) NULL,
//	[OwnerName] [nvarchar] (150) NULL,
//	[CreatedDate] [datetime] NULL,
//	[CreatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
// CONSTRAINT[PK__tblVendo__3214EC073872D51E] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
///****** Object:  Table [dbo].[tblWallet]    Script Date: 28-Sep-20 11:52:24 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE[dbo].[tblWallet]
//(

//   [Id][int] IDENTITY(1,1) NOT NULL,

//  [UserId] [int] NULL,
//	[OrderId] [int] NULL,
//	[Amount] [decimal] (18, 2) NULL,
//	[IsCredited] [bit] NULL,
//	[CreatedBy] [int] NULL,
//	[CreatedDate] [datetime] NULL,
//	[UpdatedBy] [int] NULL,
//	[UpdatedDate] [datetime] NULL,
//	[ReferUserId] [int] NULL,
//	[Remark] [nvarchar] (500) NULL,
// CONSTRAINT[PK_tblWallet] PRIMARY KEY CLUSTERED
//(
//   [Id] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON[PRIMARY]
//) ON[PRIMARY]
//GO
//ALTER TABLE[dbo].[tblAdminNotification] WITH CHECK ADD CONSTRAINT[FK_tblAdminNotification_tblOrder] FOREIGN KEY([OrderId])
//REFERENCES[dbo].[tblOrder]
//([Id])
//GO
//ALTER TABLE[dbo].[tblAdminNotification]
//CHECK CONSTRAINT[FK_tblAdminNotification_tblOrder]
//GO
//ALTER TABLE[dbo].[tblAdminUser] WITH CHECK ADD CONSTRAINT[FK_tblAdminUser_tblArea] FOREIGN KEY([AreaId])
//REFERENCES[dbo].[tblArea]
//([Id])
//GO
//ALTER TABLE[dbo].[tblAdminUser]
//CHECK CONSTRAINT[FK_tblAdminUser_tblArea]
//GO
//ALTER TABLE[dbo].[tblArea] WITH CHECK ADD CONSTRAINT[FK__tblArea__CityId__75A278F5] FOREIGN KEY([CityId])
//REFERENCES[dbo].[tblCity]
//([Id])
//GO
//ALTER TABLE[dbo].[tblArea]
//CHECK CONSTRAINT[FK__tblArea__CityId__75A278F5]
//GO
//ALTER TABLE[dbo].[tblAreaRateBoard] WITH CHECK ADD CONSTRAINT[FK_tblAreaRateBoard_tblArea] FOREIGN KEY([AreaId])
//REFERENCES[dbo].[tblArea]
//([Id])
//GO
//ALTER TABLE[dbo].[tblAreaRateBoard]
//CHECK CONSTRAINT[FK_tblAreaRateBoard_tblArea]
//GO
//ALTER TABLE[dbo].[tblAreaRateBoard] WITH CHECK ADD CONSTRAINT[FK_tblAreaRateBoard_tblGrain] FOREIGN KEY([GrainId])
//REFERENCES[dbo].[tblGrain]
//([Id])
//GO
//ALTER TABLE[dbo].[tblAreaRateBoard]
//CHECK CONSTRAINT[FK_tblAreaRateBoard_tblGrain]
//GO
//ALTER TABLE[dbo].[tblCart] WITH CHECK ADD CONSTRAINT[FK_tblCart_tblProduct] FOREIGN KEY([ProductId])
//REFERENCES[dbo].[tblProduct]
//([Id])
//GO
//ALTER TABLE[dbo].[tblCart]
//CHECK CONSTRAINT[FK_tblCart_tblProduct]
//GO
//ALTER TABLE[dbo].[tblCart] WITH CHECK ADD CONSTRAINT[FK_tblCart_tblUsers] FOREIGN KEY([UserId])
//REFERENCES[dbo].[tblUser]
//([Id])
//GO
//ALTER TABLE[dbo].[tblCart]
//CHECK CONSTRAINT[FK_tblCart_tblUsers]
//GO
//ALTER TABLE[dbo].[tblComplaint] WITH CHECK ADD CONSTRAINT[FK_tblComplaint_tblOrder] FOREIGN KEY([OrderId])
//REFERENCES[dbo].[tblOrder]
//([Id])
//GO
//ALTER TABLE[dbo].[tblComplaint]
//CHECK CONSTRAINT[FK_tblComplaint_tblOrder]
//GO
//ALTER TABLE[dbo].[tblComplaint] WITH CHECK ADD CONSTRAINT[FK_tblComplaint_tblUser] FOREIGN KEY([UserId])
//REFERENCES[dbo].[tblUser]
//([Id])
//GO
//ALTER TABLE[dbo].[tblComplaint]
//CHECK CONSTRAINT[FK_tblComplaint_tblUser]
//GO
//ALTER TABLE[dbo].[tblDeliverBoy] WITH CHECK ADD CONSTRAINT[FK_tblDeliverBoy_tblArea] FOREIGN KEY([AreaId])
//REFERENCES[dbo].[tblArea]
//([Id])
//GO
//ALTER TABLE[dbo].[tblDeliverBoy]
//CHECK CONSTRAINT[FK_tblDeliverBoy_tblArea]
//GO
//ALTER TABLE[dbo].[tblDeliverBoy] WITH CHECK ADD CONSTRAINT[FK_tblDeliverBoy_tblGrade] FOREIGN KEY([SalaryGradeId])
//REFERENCES[dbo].[tblGrade]
//([Id])
//GO
//ALTER TABLE[dbo].[tblDeliverBoy]
//CHECK CONSTRAINT[FK_tblDeliverBoy_tblGrade]
//GO
//ALTER TABLE[dbo].[tblDeliveryBoyOrder] WITH CHECK ADD CONSTRAINT[FK_tblDeliveryBoyOrder_tblDeliverBoy] FOREIGN KEY([DeliveryBoyId])
//REFERENCES[dbo].[tblDeliverBoy]
//([Id])
//GO
//ALTER TABLE[dbo].[tblDeliveryBoyOrder]
//CHECK CONSTRAINT[FK_tblDeliveryBoyOrder_tblDeliverBoy]
//GO
//ALTER TABLE[dbo].[tblDeliveryBoyOrder] WITH CHECK ADD CONSTRAINT[FK_tblDeliveryBoyOrder_tblGPartner] FOREIGN KEY([GpartnerId])
//REFERENCES[dbo].[tblGPartner]
//([Id])
//GO
//ALTER TABLE[dbo].[tblDeliveryBoyOrder]
//CHECK CONSTRAINT[FK_tblDeliveryBoyOrder_tblGPartner]
//GO
//ALTER TABLE[dbo].[tblDeliveryBoyOrder] WITH CHECK ADD CONSTRAINT[FK_tblDeliveryBoyOrder_tblOrder] FOREIGN KEY([OrderId])
//REFERENCES[dbo].[tblOrder]
//([Id])
//GO
//ALTER TABLE[dbo].[tblDeliveryBoyOrder]
//CHECK CONSTRAINT[FK_tblDeliveryBoyOrder_tblOrder]
//GO
//ALTER TABLE[dbo].[tblDeliveryBoyOrder] WITH CHECK ADD CONSTRAINT[FK_tblDeliveryBoyOrder_tblUser] FOREIGN KEY([UserId])
//REFERENCES[dbo].[tblUser]
//([Id])
//GO
//ALTER TABLE[dbo].[tblDeliveryBoyOrder]
//CHECK CONSTRAINT[FK_tblDeliveryBoyOrder_tblUser]
//GO
//ALTER TABLE[dbo].[tblDeliveryBoyPayment] WITH CHECK ADD FOREIGN KEY([DeliverBoyId])
//REFERENCES[dbo].[tblDeliverBoy]
//([Id])
//GO
//ALTER TABLE[dbo].[tblDPartnerPaymentRelease] WITH CHECK ADD CONSTRAINT[FK_DPartnerPaymentRelease_tblDeliverBoy] FOREIGN KEY([DeliveryBoyId])
//REFERENCES[dbo].[tblDeliverBoy]
//([Id])
//GO
//ALTER TABLE[dbo].[tblDPartnerPaymentRelease]
//CHECK CONSTRAINT[FK_DPartnerPaymentRelease_tblDeliverBoy]
//GO
//ALTER TABLE[dbo].[tblDPartnerPaymentReleaseDetail] WITH CHECK ADD CONSTRAINT[FK_tblDPartnerPaymentReleaseDetail_tblOrder] FOREIGN KEY([OrderId])
//REFERENCES[dbo].[tblOrder]
//([Id])
//GO
//ALTER TABLE[dbo].[tblDPartnerPaymentReleaseDetail]
//CHECK CONSTRAINT[FK_tblDPartnerPaymentReleaseDetail_tblOrder]
//GO
//ALTER TABLE[dbo].[tblGPartner] WITH CHECK ADD CONSTRAINT[FK_tblGPartner_tblAdminUser] FOREIGN KEY([VerifiedBy])
//REFERENCES[dbo].[tblAdminUser]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGPartner]
//CHECK CONSTRAINT[FK_tblGPartner_tblAdminUser]
//GO
//ALTER TABLE[dbo].[tblGPartner] WITH CHECK ADD CONSTRAINT[FK_tblGPartner_tblArea] FOREIGN KEY([AreaId])
//REFERENCES[dbo].[tblArea]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGPartner]
//CHECK CONSTRAINT[FK_tblGPartner_tblArea]
//GO
//ALTER TABLE[dbo].[tblGPartnerOrder] WITH CHECK ADD CONSTRAINT[FK_tblGPartnerOrder_tblOrder] FOREIGN KEY([OrderId])
//REFERENCES[dbo].[tblOrder]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGPartnerOrder]
//CHECK CONSTRAINT[FK_tblGPartnerOrder_tblOrder]
//GO
//ALTER TABLE[dbo].[tblGpartnerPassReason] WITH CHECK ADD CONSTRAINT[FK_tblGpartnerPassReason_tblGPartner] FOREIGN KEY([GpartnerId])
//REFERENCES[dbo].[tblGPartner]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGpartnerPassReason]
//CHECK CONSTRAINT[FK_tblGpartnerPassReason_tblGPartner]
//GO
//ALTER TABLE[dbo].[tblGpartnerPassReason] WITH CHECK ADD CONSTRAINT[FK_tblGpartnerPassReason_tblOrder] FOREIGN KEY([OrderId])
//REFERENCES[dbo].[tblOrder]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGpartnerPassReason]
//CHECK CONSTRAINT[FK_tblGpartnerPassReason_tblOrder]
//GO
//ALTER TABLE[dbo].[tblGpartnerPayment] WITH CHECK ADD CONSTRAINT[FK_tblGpartnerPayment_tblGPartner] FOREIGN KEY([GpartnerId])
//REFERENCES[dbo].[tblGPartner]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGpartnerPayment]
//CHECK CONSTRAINT[FK_tblGpartnerPayment_tblGPartner]
//GO
//ALTER TABLE[dbo].[tblGPartnerPaymentRelease] WITH CHECK ADD CONSTRAINT[FK_tblGPartnerPaymentRelease_tblGPartner] FOREIGN KEY([GPartnerId])
//REFERENCES[dbo].[tblGPartner]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGPartnerPaymentRelease]
//CHECK CONSTRAINT[FK_tblGPartnerPaymentRelease_tblGPartner]
//GO
//ALTER TABLE[dbo].[TblGpartnerPaymentReleaseDetail] WITH CHECK ADD CONSTRAINT[FK_TblGpartnerPaymentReleaseDetail_tblGPartnerPaymentRelease] FOREIGN KEY([ReleasePaymentId])
//REFERENCES[dbo].[tblGPartnerPaymentRelease]
//([Id])
//GO
//ALTER TABLE[dbo].[TblGpartnerPaymentReleaseDetail]
//CHECK CONSTRAINT[FK_TblGpartnerPaymentReleaseDetail_tblGPartnerPaymentRelease]
//GO
//ALTER TABLE[dbo].[TblGpartnerPaymentReleaseDetail] WITH CHECK ADD CONSTRAINT[FK_TblGpartnerPaymentReleaseDetail_tblOrder] FOREIGN KEY([OrderId])
//REFERENCES[dbo].[tblOrder]
//([Id])
//GO
//ALTER TABLE[dbo].[TblGpartnerPaymentReleaseDetail]
//CHECK CONSTRAINT[FK_TblGpartnerPaymentReleaseDetail_tblOrder]
//GO
//ALTER TABLE[dbo].[tblGPartnerStockDetail] WITH CHECK ADD CONSTRAINT[FK_tblGPartnerStockDetail_tblGPartner] FOREIGN KEY([GPartnerId])
//REFERENCES[dbo].[tblGPartner]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGPartnerStockDetail]
//CHECK CONSTRAINT[FK_tblGPartnerStockDetail_tblGPartner]
//GO
//ALTER TABLE[dbo].[tblGPartnerStockDetail] WITH CHECK ADD CONSTRAINT[FK_tblGPartnerStockDetail_tblGPartnerStock] FOREIGN KEY([GPartnerStockId])
//REFERENCES[dbo].[tblGPartnerStock]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGPartnerStockDetail]
//CHECK CONSTRAINT[FK_tblGPartnerStockDetail_tblGPartnerStock]
//GO
//ALTER TABLE[dbo].[tblGPartnerStockDetail] WITH CHECK ADD CONSTRAINT[FK_tblGPartnerStockDetail_tblGrainCategory2] FOREIGN KEY([GrainCategoryId])
//REFERENCES[dbo].[tblGrainCategory]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGPartnerStockDetail]
//CHECK CONSTRAINT[FK_tblGPartnerStockDetail_tblGrainCategory2]
//GO
//ALTER TABLE[dbo].[tblGPHoliday] WITH CHECK ADD CONSTRAINT[FK_tblGPHoliday_tblGPartner] FOREIGN KEY([GPId])
//REFERENCES[dbo].[tblGPartner]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGPHoliday]
//CHECK CONSTRAINT[FK_tblGPHoliday_tblGPartner]
//GO
//ALTER TABLE[dbo].[tblGPStockCapacity] WITH CHECK ADD CONSTRAINT[FK_tblGPStockCapacity_tblGPartner] FOREIGN KEY([GPId])
//REFERENCES[dbo].[tblGPartner]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGPStockCapacity]
//CHECK CONSTRAINT[FK_tblGPStockCapacity_tblGPartner]
//GO
//ALTER TABLE[dbo].[tblGPStockCapacity] WITH CHECK ADD CONSTRAINT[FK_tblGPStockCapacity_tblGrainCategory] FOREIGN KEY([GrainCategoryId])
//REFERENCES[dbo].[tblGrainCategory]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGPStockCapacity]
//CHECK CONSTRAINT[FK_tblGPStockCapacity_tblGrainCategory]
//GO
//ALTER TABLE[dbo].[tblGrainCategory] WITH CHECK ADD CONSTRAINT[FK_GrainType_tblGrain] FOREIGN KEY([GrainId])
//REFERENCES[dbo].[tblGrain]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGrainCategory]
//CHECK CONSTRAINT[FK_GrainType_tblGrain]
//GO
//ALTER TABLE[dbo].[tblGrinderRateBoard] WITH CHECK ADD CONSTRAINT[FK_tblGrinderRateBoard_tblGPartner] FOREIGN KEY([GpId])
//REFERENCES[dbo].[tblGPartner]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGrinderRateBoard]
//CHECK CONSTRAINT[FK_tblGrinderRateBoard_tblGPartner]
//GO
//ALTER TABLE[dbo].[tblGrinderRateBoard] WITH CHECK ADD CONSTRAINT[FK_tblGrinderRateBoard_tblGrain] FOREIGN KEY([GrainId])
//REFERENCES[dbo].[tblGrain]
//([Id])
//GO
//ALTER TABLE[dbo].[tblGrinderRateBoard]
//CHECK CONSTRAINT[FK_tblGrinderRateBoard_tblGrain]
//GO
//ALTER TABLE[dbo].[tblHelpAndSupport] WITH CHECK ADD FOREIGN KEY([UserId])
//REFERENCES[dbo].[tblUser]
//([Id])
//GO
//ALTER TABLE[dbo].[tblOrder] WITH CHECK ADD CONSTRAINT[FK_tblOrder_tblDeliverySlot] FOREIGN KEY([DeliverySlotId])
//REFERENCES[dbo].[tblDeliverySlot]
//([Id])
//GO
//ALTER TABLE[dbo].[tblOrder]
//CHECK CONSTRAINT[FK_tblOrder_tblDeliverySlot]
//GO
//ALTER TABLE[dbo].[tblOrder] WITH CHECK ADD CONSTRAINT[FK_tblOrder_tblUser] FOREIGN KEY([UserId])
//REFERENCES[dbo].[tblUser]
//([Id])
//GO
//ALTER TABLE[dbo].[tblOrder]
//CHECK CONSTRAINT[FK_tblOrder_tblUser]
//GO
//ALTER TABLE[dbo].[tblOrderBagnumber] WITH CHECK ADD CONSTRAINT[FK_tblOrderBagnumber_tblGPartner] FOREIGN KEY([GpartnerId])
//REFERENCES[dbo].[tblGPartner]
//([Id])
//GO
//ALTER TABLE[dbo].[tblOrderBagnumber]
//CHECK CONSTRAINT[FK_tblOrderBagnumber_tblGPartner]
//GO
//ALTER TABLE[dbo].[tblOrderBagnumber] WITH CHECK ADD CONSTRAINT[FK_tblOrderBagnumber_tblOrder] FOREIGN KEY([OrderId])
//REFERENCES[dbo].[tblOrder]
//([Id])
//GO
//ALTER TABLE[dbo].[tblOrderBagnumber]
//CHECK CONSTRAINT[FK_tblOrderBagnumber_tblOrder]
//GO
//ALTER TABLE[dbo].[tblOrderBagnumber] WITH CHECK ADD CONSTRAINT[FK_tblOrderBagnumber_tblUser] FOREIGN KEY([UserId])
//REFERENCES[dbo].[tblUser]
//([Id])
//GO
//ALTER TABLE[dbo].[tblOrderBagnumber]
//CHECK CONSTRAINT[FK_tblOrderBagnumber_tblUser]
//GO
//ALTER TABLE[dbo].[tblOrderDetail] WITH CHECK ADD CONSTRAINT[FK_tblOrderDetail_tblOrder] FOREIGN KEY([OrderId])
//REFERENCES[dbo].[tblOrder]
//([Id])
//GO
//ALTER TABLE[dbo].[tblOrderDetail]
//CHECK CONSTRAINT[FK_tblOrderDetail_tblOrder]
//GO
//ALTER TABLE[dbo].[tblOrderDetail] WITH CHECK ADD CONSTRAINT[FK_tblOrderDetail_tblProduct] FOREIGN KEY([ProductId])
//REFERENCES[dbo].[tblProduct]
//([Id])
//GO
//ALTER TABLE[dbo].[tblOrderDetail]
//CHECK CONSTRAINT[FK_tblOrderDetail_tblProduct]
//GO
//ALTER TABLE[dbo].[tblPageAccess] WITH CHECK ADD CONSTRAINT[FK_tblPageAccess_tblPage] FOREIGN KEY([PageId])
//REFERENCES[dbo].[tblPage]
//([Id])
//GO
//ALTER TABLE[dbo].[tblPageAccess]
//CHECK CONSTRAINT[FK_tblPageAccess_tblPage]
//GO
//ALTER TABLE[dbo].[TblProductDetail] WITH CHECK ADD CONSTRAINT[FK_TblProductDetail_tblGrainCategory] FOREIGN KEY([GrainCategoryId])
//REFERENCES[dbo].[tblGrainCategory]
//([Id])
//GO
//ALTER TABLE[dbo].[TblProductDetail]
//CHECK CONSTRAINT[FK_TblProductDetail_tblGrainCategory]
//GO
//ALTER TABLE[dbo].[TblProductDetail] WITH CHECK ADD CONSTRAINT[FK_TblProductDetail_tblProduct] FOREIGN KEY([ProductId])
//REFERENCES[dbo].[tblProduct]
//([Id])
//GO
//ALTER TABLE[dbo].[TblProductDetail]
//CHECK CONSTRAINT[FK_TblProductDetail_tblProduct]
//GO
//ALTER TABLE[dbo].[tblProductImages] WITH CHECK ADD CONSTRAINT[FK_tblProductImages_tblProduct] FOREIGN KEY([ProductId])
//REFERENCES[dbo].[tblProduct]
//([Id])
//GO
//ALTER TABLE[dbo].[tblProductImages]
//CHECK CONSTRAINT[FK_tblProductImages_tblProduct]
//GO
//ALTER TABLE[dbo].[tblRating] WITH CHECK ADD CONSTRAINT[FK_tblRating_tblOrder] FOREIGN KEY([OrderId])
//REFERENCES[dbo].[tblOrder]
//([Id])
//GO
//ALTER TABLE[dbo].[tblRating]
//CHECK CONSTRAINT[FK_tblRating_tblOrder]
//GO
//ALTER TABLE[dbo].[tblRating] WITH CHECK ADD CONSTRAINT[FK_tblRating_tblUser] FOREIGN KEY([UserId])
//REFERENCES[dbo].[tblUser]
//([Id])
//GO
//ALTER TABLE[dbo].[tblRating]
//CHECK CONSTRAINT[FK_tblRating_tblUser]
//GO
//ALTER TABLE[dbo].[tblReview] WITH CHECK ADD CONSTRAINT[FK_tblReview_tblProduct] FOREIGN KEY([ProductId])
//REFERENCES[dbo].[tblProduct]
//([Id])
//GO
//ALTER TABLE[dbo].[tblReview]
//CHECK CONSTRAINT[FK_tblReview_tblProduct]
//GO
//ALTER TABLE[dbo].[tblReview] WITH CHECK ADD CONSTRAINT[FK_tblReview_tblUser] FOREIGN KEY([UserId])
//REFERENCES[dbo].[tblUser]
//([Id])
//GO
//ALTER TABLE[dbo].[tblReview]
//CHECK CONSTRAINT[FK_tblReview_tblUser]
//GO
//ALTER TABLE[dbo].[tblSaveForLater] WITH CHECK ADD CONSTRAINT[FK_tblSaveForLater_tblProduct] FOREIGN KEY([ProductId])
//REFERENCES[dbo].[tblProduct]
//([Id])
//GO
//ALTER TABLE[dbo].[tblSaveForLater]
//CHECK CONSTRAINT[FK_tblSaveForLater_tblProduct]
//GO
//ALTER TABLE[dbo].[tblSaveForLater] WITH CHECK ADD CONSTRAINT[FK_tblSaveForLater_tblUser] FOREIGN KEY([UserId])
//REFERENCES[dbo].[tblUser]
//([Id])
//GO
//ALTER TABLE[dbo].[tblSaveForLater]
//CHECK CONSTRAINT[FK_tblSaveForLater_tblUser]
//GO
//ALTER TABLE[dbo].[tblStock] WITH CHECK ADD CONSTRAINT[FK_tblStock_tblVendor] FOREIGN KEY([VendorId])
//REFERENCES[dbo].[tblVendor]
//([Id])
//GO
//ALTER TABLE[dbo].[tblStock]
//CHECK CONSTRAINT[FK_tblStock_tblVendor]
//GO
//ALTER TABLE[dbo].[tblStockDetail] WITH CHECK ADD CONSTRAINT[FK_tblStockDetail_tblGrainCategory] FOREIGN KEY([GrainCategoryId])
//REFERENCES[dbo].[tblGrainCategory]
//([Id])
//GO
//ALTER TABLE[dbo].[tblStockDetail]
//CHECK CONSTRAINT[FK_tblStockDetail_tblGrainCategory]
//GO
//ALTER TABLE[dbo].[tblStockDetail] WITH CHECK ADD CONSTRAINT[FK_tblStockDetail_tblStock] FOREIGN KEY([StockId])
//REFERENCES[dbo].[tblStock]
//([Id])
//GO
//ALTER TABLE[dbo].[tblStockDetail]
//CHECK CONSTRAINT[FK_tblStockDetail_tblStock]
//GO
//ALTER TABLE[dbo].[tblSubOrderDetail] WITH CHECK ADD CONSTRAINT[FK_tblSubOrderDetail_tblGrainCategory] FOREIGN KEY([GrainCategoryId])
//REFERENCES[dbo].[tblGrainCategory]
//([Id])
//GO
//ALTER TABLE[dbo].[tblSubOrderDetail]
//CHECK CONSTRAINT[FK_tblSubOrderDetail_tblGrainCategory]
//GO
//ALTER TABLE[dbo].[tblSubOrderDetail] WITH CHECK ADD CONSTRAINT[FK_tblSubOrderDetail_tblOrderDetail] FOREIGN KEY([OrderDetailId])
//REFERENCES[dbo].[tblOrderDetail]
//([Id])
//GO
//ALTER TABLE[dbo].[tblSubOrderDetail]
//CHECK CONSTRAINT[FK_tblSubOrderDetail_tblOrderDetail]
//GO
//ALTER TABLE[dbo].[tblTransaction] WITH CHECK ADD CONSTRAINT[FK_tblTransaction_tblOrder] FOREIGN KEY([OrderId])
//REFERENCES[dbo].[tblOrder]
//([Id])
//GO
//ALTER TABLE[dbo].[tblTransaction]
//CHECK CONSTRAINT[FK_tblTransaction_tblOrder]
//GO
//ALTER TABLE[dbo].[tblUserAddress] WITH CHECK ADD CONSTRAINT[FK_tblUserAddress_tblUser] FOREIGN KEY([UserId])
//REFERENCES[dbo].[tblUser]
//([Id])
//GO
//ALTER TABLE[dbo].[tblUserAddress]
//CHECK CONSTRAINT[FK_tblUserAddress_tblUser]
//GO
//ALTER TABLE[dbo].[tblWallet] WITH CHECK ADD CONSTRAINT[FK_tblWallet_tblOrder] FOREIGN KEY([OrderId])
//REFERENCES[dbo].[tblOrder]
//([Id])
//GO
//ALTER TABLE[dbo].[tblWallet]
//CHECK CONSTRAINT[FK_tblWallet_tblOrder]
//GO
//ALTER TABLE[dbo].[tblWallet] WITH CHECK ADD CONSTRAINT[FK_tblWallet_tblUser] FOREIGN KEY([UserId])
//REFERENCES[dbo].[tblUser]
//([Id])
//GO
//ALTER TABLE[dbo].[tblWallet]
//CHECK CONSTRAINT[FK_tblWallet_tblUser]
//GO
///****** Object:  StoredProcedure [dbo].[csp_DayPassedOrderedUser]    Script Date: 28-Sep-20 11:52:25 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO

//-- =============================================
//-- Author:		<Pradip Warambhe >
//-- Create date: <18-July 2020>
//-- Description:	<get 15 day product not order users >
//-- =============================================
//CREATE PROCEDURE[dbo].[csp_DayPassedOrderedUser]
//AS
//BEGIN
//Select 0 as Sr_No, Mobile,U.FirstName+' ' +U.LastName as Customer,o.OrderNo,o.OrderDate,DATEDIFF(DAY, O.OrderDate, GETDATE()) AS Days from tblorder o
//   inner join tbluser U on o.UserId=U.Id where o.id in (Select
//   max(Id) from tblorder where PaymentStatus=1
//group by UserId having DATEDIFF(DAY, max(OrderDate), GETDATE())>15 )
//END
//GO
///****** Object:  StoredProcedure [dbo].[csp_GetAllGpartnersStock]    Script Date: 28-Sep-20 11:52:25 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO

//-- =============================================
//-- Author:		<Pradip Warambhe>
//-- Create date: <18 July 2020>
//-- Description:	<Get All Gpartners Stock>
//-- =============================================
//CREATE PROCEDURE[dbo].[csp_GetAllGpartnersStock]

//AS
//BEGIN

//declare @count int ,@i int =1 ,@c int ,@gpid int


//CREATE TABLE gpids(
//    id INT IDENTITY(1,1) ,
//    GpartnerId int NOT NULL
//);
 
// insert into gpids(GpartnerId)
// Select id from tblGPartner

//set @count = (Select count(id) from gpids);
//--Select* from gpids
//while(@i<=@count)
//begin

//set @gpid= (Select GpartnerId from gpids where id=@i)
//--Select @gpid
//select(cast (@i as nvarchar(5))  +'_'+ MillName+'_'+AreaCode) as name from tblGPartner where id=@gpid;
//Select* from fun_gpstocklist(@gpid);
//set @i = @i + 1
//end
//drop table gpids


//END


//--Select* from tblGPartner where MillName like '%Shri Datta Flour Millflour mills%'
//GO
///****** Object:  StoredProcedure [dbo].[csp_GetAreaStock]    Script Date: 28-Sep-20 11:52:25 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO

//-- =============================================
//-- Author:		<Pradip Warambhe>
//-- Create date: <17-07-2020>
//-- Description:	<Get Area total Stock>
//-- =============================================
//CREATE PROCEDURE[dbo].[csp_GetAreaStock]
//@AreaId int
//AS
//BEGIN
//Select G.Name_ENG as Grain ,Gc.Name_ENG as GrainCategory,GC.Id as GrainCategoryId,ISNULL(S.stock,0) AS Stock from tblGrainCategory GC left join
// (
//    Select GrainCategoryId, SUM(GSD.Quantity) as stock from  tblGPartnerStockDetail GSD

//    inner join tblGPartnerStock GS on GS.Id= GSD.GPartnerStockId

//    inner join tblGPartner G on G.Id= GSD.GPartnerId

//    where GSD.GPartnerId in (Select Id from tblGPartner where AreaId = @AreaId) and GS.Status=1
//	group by GrainCategoryId


//  )
// S on GC.id=S.GrainCategoryId
// inner join tblGrain G on G.Id=GC.GrainId
//END
//GO
///****** Object:  StoredProcedure [dbo].[csp_GrindingRate]    Script Date: 28-Sep-20 11:52:25 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO

//-- =============================================
//-- Author:		<Pradip Warambhe>
//-- Create date: <18 JULY 2020>
//-- Description:	<Get Grinding charges per grain>
//-- =============================================
//CREATE PROCEDURE[dbo].[csp_GrindingRate]
//@GrinderPartnerId int
//AS
//BEGIN
//sELECT G.Id,G.Name_ENG as Grain ,ISNULL(GR.Rate,0) AS Rate FROM tblGrain G LEFT JOIN(
//select* from  tblGrinderRateBoard
//where   GpId= 5)  GR ON G.Id=GR.GrainId where g.Active=1  and G.IsDelete=0

//END

//--Select* from tblGPartner
//--Select* from tblGrain
//GO
///****** Object:  StoredProcedure [dbo].[csp_IntransistStockList]    Script Date: 28-Sep-20 11:52:25 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE Proc [dbo].[csp_IntransistStockList] --30
//@GPartnerId int = 0

//as
//begin

//select A.GrainCategoryId, Stock, G.Name_ENG as Grain , c.GrainId, C.Name_ENG as GrainCategory , cast(isnull(c.Price,0) as decimal ) as Price,isnull(C.ImagePath,'') as ImagePath,cast(0 as decimal) as MinStock,0.0 as CapacityInKg,0.0 as minPercentage
//,0.0 as Total_Quantity, 0.0 as Release_Quantity ,0.0 as Sold_Quantity
//  from(Select GrainCategoryId, sum(Quantity) as Stock from tblGPartnerStockDetail sd
//inner join tblGPartnerStock s on s.id= sd.GPartnerStockId
//where Status = 0 and GPartnerId = case when @GPartnerId = 0 then GPartnerId
//										else @GPartnerId end
//group by GrainCategoryId   )as  A
//left join tblgrainCategory C on A.GrainCategoryId=C.Id
//left join tblgrain G on  G.Id=C.GrainId
//end
//GO
///****** Object:  StoredProcedure [dbo].[csp_Inventory]    Script Date: 28-Sep-20 11:52:25 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO

//-- =============================================
//-- Author:		<Pradip Warambhe>
//-- Create date: <10-Aug-2020>
//-- Description:	<StockreportsComapny>
//-- =============================================
//CREATE PROCEDURE[dbo].[csp_Inventory]

//AS
//BEGIN


//Select G.Name_ENG as Grain, GC.Name_ENG as GrainCategory, (isnull(Total.Quantity,0) -isnull(Release.Quantity,0) )as Stock,isnull(Total.Quantity,0) as Total, isnull(Release.Quantity,0) as Release
//,isnull(Sold.Quantity,0) as Sold
//,isnull(Intransite.Quantity,0) as Intransist
// from tblGrainCategory GC
//left join
//(Select GrainCategoryId, Sum(isnull(Quantity,0)) as Quantity from tblStockDetail group by GrainCategoryId ) as Total on GC.id=Total.GrainCategoryId
// left join(
// Select GrainCategoryId, sum(Quantity) as Quantity from tblGPartnerStockDetail GPSD
// inner join tblGPartnerStock GPS on GPS.Id= GPSD.GPartnerStockId
// where Status !=2

//  Group By GrainCategoryId ) as Release on GC.Id=Release.GrainCategoryId

//  left join(
// Select GrainCategoryId, sum(Quantity) as Quantity from tblGPartnerStockDetail GPSD
// inner join tblGPartnerStock GPS on GPS.Id= GPSD.GPartnerStockId
// where Status = 0


//  Group By GrainCategoryId ) as Intransite on GC.Id=Intransite.GrainCategoryId
// Left Join(
// Select SOD.GrainCategoryId, SUM(SOD.Quantity* OD.Size) as Quantity from tblSubOrderDetail SOD inner join tblOrderDetail OD on SOD.OrderDetailId=OD.Id
//   inner join tblOrder O on OD.OrderId= O.Id where O.OrderStatus= 7
//   group by  SOD.GrainCategoryId ) as Sold on GC.Id=Sold.GrainCategoryId
//   inner join tblGrain G on GC.GrainId=G.Id
//   END
//GO
///****** Object:  StoredProcedure [dbo].[csp_LogExceptionToDB]    Script Date: 28-Sep-20 11:52:25 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO


//-- ======================================================================
//-- Author		:   mahesh warambhe
//-- Create date  :	19-August-2014
//-- Description	:	Insert exceptions
//-- Used For     :	Error Handling
//-- Example		:	
//-- ======================================================================
//CREATE PROC[dbo].[csp_LogExceptionToDB]
//@source varchar(100),
//@LogDateTime varchar(8000),
//@Message varchar(1000),
//@QueryString varchar(2000),
//@TargetSite varchar(300),
//@StackTrace varchar(4000),
//@ServerName varchar(300),
//@RequestURL varchar(300),
//@UserAgent varchar(300),
//@UserIP varchar(300),
//@UserAuthentication varchar(300),
//@UserName varchar(300)

//AS

//INSERT INTO tblExceptionLogItems
//(Source, LogDateTime, Message, QueryString, TargetSite, StackTrace, ServerName, RequestURL,
//UserAgent, UserIP, UserAuthentication, UserName)
//Values(
//@Source,
//@LogDateTime,
//@Message,
//@QueryString,
//@TargetSite,
//@StackTrace,
//@ServerName,
//@RequestURL,
//@UserAgent,
//@UserIP,
//@UserAuthentication,
//@UserName
//)




//GO
///****** Object:  StoredProcedure [dbo].[cspAdminStockList]    Script Date: 28-Sep-20 11:52:25 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO

//-- =============================================
//-- Author:		<Pradip Warambhe>
//-- Create date: <23-May-2020>
//-- Description:	<Description,,>
//-- =============================================
//CREATE PROCEDURE[dbo].[cspAdminStockList]
//as
//BEGIN



//Select G.Name_ENG as Grain,Gc.GrainId, GC.Id as GrainCategoryId,GC.Name_ENG as GrainCategory,GC.Price,isnull(GC.ImagePath,'') as ImagePath,(isnull(Total.Quantity,0) -isnull(Release.Quantity,0) )as Stock,isnull(Total.Quantity,0) as Total_Quantity, isnull(Release.Quantity,0) as Release_Quantity ,isnull(Sold.Quantity,0) as Sold_Quantity,
//cast(GC.minStock as decimal) as MinStock,0.0 as CapacityInKg,0.0 minPercentage from tblGrainCategory GC
//left join
//(Select GrainCategoryId, Sum(isnull(Quantity,0)) as Quantity from tblStockDetail group by GrainCategoryId ) as Total on GC.id=Total.GrainCategoryId
// left join(
// Select GrainCategoryId, sum(Quantity) as Quantity from tblGPartnerStockDetail GPSD
// inner join tblGPartnerStock GPS on GPS.Id= GPSD.GPartnerStockId
// where Status !=2

//  Group By GrainCategoryId ) as Release on GC.Id=Release.GrainCategoryId
// Left Join(
// Select SOD.GrainCategoryId, SUM(SOD.Quantity* OD.Size) as Quantity from tblSubOrderDetail SOD inner join tblOrderDetail OD on SOD.OrderDetailId=OD.Id
//   inner join tblOrder O on OD.OrderId= O.Id where O.OrderStatus= 7
//   group by  SOD.GrainCategoryId ) as Sold on GC.Id=Sold.GrainCategoryId
//   inner join tblGrain G on GC.GrainId=G.Id
//   END
//GO
///****** Object:  StoredProcedure [dbo].[cspGpstockCapacityList]    Script Date: 28-Sep-20 11:52:25 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO

//-- =============================================
//-- Author:		<Pradip Warambhe>
//-- Create date: <>
//-- Description:	<Description,,>
//-- =============================================
//CREATE PROCEDURE[dbo].[cspGpstockCapacityList]
//as
//BEGIN


//Select G.Name_ENG as Grain ,Gc.GrainId,Gc.Id as GrainCategoryId,Gc.Name_ENG as GrainCategory from tblGrainCategory Gc
//inner join tblGrain G
//on G.Id=Gc.GrainId





//END

//GO
///****** Object:  StoredProcedure [dbo].[cspStockList]    Script Date: 28-Sep-20 11:52:25 AM ******/
//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO

//-- =============================================
//-- Author:		<Pradip Warambhe>
//-- Create date: <>
//-- Description:	<Description,,>
//-- =============================================
//CREATE PROCEDURE [dbo].[cspStockList]  --17--60
//@GPartnerId int

//BEGIN

//Select G.Name_ENG as Grain, Gc.GrainId, GC.Id as GrainCategoryId, GC.Name_ENG as GrainCategory, GC.Price, isnull(GC.ImagePath,'') as ImagePath,(isnull(Total.Quantity,0) -isnull(Sold.Quantity,0) )as Stock,isnull(Total.Quantity,0) as Total_Quantity, 0.0 as Release_Quantity ,isnull(Sold.Quantity,0) as Sold_Quantity,
//0.0  as MinStock,cast(ISnull(Capacity.CapacityInKg,0.0) as decimal) as CapacityInKg,ISNULL(Capacity.minPercentage,0) as minPercentage from tblGrainCategory GC
//left join
//(Select GrainCategoryId, Sum(isnull(Quantity,0)) as Quantity from tblGPartnerStockDetail GSD
//inner Join tblGPartnerStock GS on GS.Id= GSD.GPartnerStockId
//where GS.Status= 1 and GS.GPatnerId= @GPartnerId group by GrainCategoryId ) as Total on GC.id=Total.GrainCategoryId
//  left join(
//  Select SOD.GrainCategoryId, SUM(SOD.Quantity* OD.Size) as Quantity from tblSubOrderDetail SOD inner join tblOrderDetail OD on SOD.OrderDetailId=OD.Id
//    inner join tblOrder O on OD.OrderId= O.Id where (O.OrderStatus= 7 or O.OrderStatus= 5)  and O.GpartnerId=@GPartnerId
//       group by SOD.GrainCategoryId ) as Sold on GC.Id=Sold.GrainCategoryId
//      left join(Select GrainCategoryId, cast (CapacityInKg as decimal )as CapacityInKg  ,minPercentage from tblGPStockCapacity where GPId=@GPartnerId) as Capacity on Capacity.GrainCategoryId=Gc.Id
//      inner join tblGrain G on GC.GrainId=G.Id

//--where G.IsDelete=0 and Gc.IsDelete= 0
//END

//GO
//USE[master]
//GO
//ALTER DATABASE [flourdb] SET READ_WRITE
//GO



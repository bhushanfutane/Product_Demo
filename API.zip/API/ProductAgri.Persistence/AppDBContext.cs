﻿using System;
using ProductAgri.Domain.Model;
using Microsoft.EntityFrameworkCore;
using ProductAgri;

namespace ProductAgri.Persistence
{
    public partial class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions options) : base(options)
        {
        }

        public virtual DbSet<TblAdminUser> TblAdminUsers { get; set; }
        public virtual DbSet<TblCategory> TblCategories { get; set; }
        public virtual DbSet<TblExceptionLogItem> TblExceptionLogItems { get; set; }
        public virtual DbSet<TblProduct> TblProducts { get; set; }
        public virtual DbSet<TblSubCategory> TblSubCategories { get; set; }
        public virtual DbSet<TblUser> TblUsers { get; set; }
        public virtual DbSet<TblUserAddress> TblUserAddresses { get; set; }

        //////////////////////////////// For Stored Procedures Models /////////////////////////////

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TblAdminUser>(entity =>
            {
                entity.ToTable("tblAdminUser");

                entity.Property(e => e.Address).HasMaxLength(500);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Email).HasMaxLength(50);

                entity.Property(e => e.FirstName).HasMaxLength(50);

                entity.Property(e => e.LastName).HasMaxLength(50);

                entity.Property(e => e.MobileNo).HasMaxLength(15);

                entity.Property(e => e.OtpExpireTime).HasColumnType("datetime");

                entity.Property(e => e.Password).HasMaxLength(100);

                entity.Property(e => e.RegistrationDate).HasColumnType("date");

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.UserName).HasMaxLength(50);
            });

            modelBuilder.Entity<TblCategory>(entity =>
            {
                entity.ToTable("tblCategory");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.ImagePath).HasMaxLength(50);

                entity.Property(e => e.NameEng)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("Name_ENG");

                entity.Property(e => e.NameHin)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("Name_HIN");

                entity.Property(e => e.NameMar)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("Name_MAR");

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<TblExceptionLogItem>(entity =>
            {
                entity.HasKey(e => e.EventId);

                entity.ToTable("tblExceptionLogItems");

                entity.Property(e => e.LogDateTime).HasColumnType("datetime");

                entity.Property(e => e.Message)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.QueryString)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.RequestUrl)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("RequestURL");

                entity.Property(e => e.ServerName)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.StackTrace)
                    .HasMaxLength(4000)
                    .IsUnicode(false);

                entity.Property(e => e.TargetSite)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.UserAgent)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.UserAuthentication)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.UserIp)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("UserIP");

                entity.Property(e => e.UserName)
                    .HasMaxLength(300)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblProduct>(entity =>
            {
                entity.ToTable("tblProduct");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Discription).HasMaxLength(2000);

                entity.Property(e => e.DiscriptionHn)
                    .HasMaxLength(2000)
                    .HasColumnName("Discription_Hn");

                entity.Property(e => e.DiscriptionMr)
                    .HasMaxLength(2000)
                    .HasColumnName("Discription_Mr");

                entity.Property(e => e.ImageUrl).HasMaxLength(100);

                entity.Property(e => e.Mrp)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("MRP");

                entity.Property(e => e.NameEng)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("Name_ENG");

                entity.Property(e => e.NameHin)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("Name_HIN");

                entity.Property(e => e.NameMar)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasColumnName("Name_MAR");

                entity.Property(e => e.Price).HasColumnType("decimal(8, 2)");

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.Weight).HasColumnType("decimal(5, 3)");

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.TblProducts)
                    .HasForeignKey(d => d.CategoryId)
                    .HasConstraintName("FK_tblProduct_tblCategory");
            });

            modelBuilder.Entity<TblSubCategory>(entity =>
            {
                entity.ToTable("tblSubCategory");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Discription).HasMaxLength(500);

                entity.Property(e => e.ImagePath).HasMaxLength(100);

                entity.Property(e => e.NameEng)
                    .HasMaxLength(50)
                    .HasColumnName("Name_ENG");

                entity.Property(e => e.NameHin)
                    .HasMaxLength(50)
                    .HasColumnName("Name_HIN");

                entity.Property(e => e.NameMar)
                    .HasMaxLength(50)
                    .HasColumnName("Name_MAR");

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.TblSubCategories)
                    .HasForeignKey(d => d.CategoryId)
                    .HasConstraintName("FK_tblSubCategory_tblCategory");
            });

            modelBuilder.Entity<TblUser>(entity =>
            {
                entity.ToTable("TblUser");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Email).HasMaxLength(50);

                entity.Property(e => e.FullName).HasMaxLength(50);

                entity.Property(e => e.Mobile).HasMaxLength(15);

                entity.Property(e => e.Password).HasMaxLength(50);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<TblUserAddress>(entity =>
            {
                entity.ToTable("tblUserAddress");

                entity.Property(e => e.AppartmentName).HasMaxLength(100);

                entity.Property(e => e.AreaName).HasMaxLength(50);
                entity.Property(e => e.City).HasMaxLength(50);

                entity.Property(e => e.Contact).HasMaxLength(15);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.HouseNo).HasMaxLength(100);

                entity.Property(e => e.Landmark).HasMaxLength(250);

                entity.Property(e => e.NiknameAddress)
                    .HasMaxLength(150)
                    .HasColumnName("niknameAddress");

                entity.Property(e => e.Pincode).HasMaxLength(10);

                entity.Property(e => e.StreetDetails).HasMaxLength(200);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.TblUserAddresses)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblUserAddress_tblUser");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }

    public static class AppDbContextExtension
    {
        [DbFunction("cfn_GetAdminSubGrainStock", "dbo")]
        public static decimal GetAdminSubGrainStock(int GrainCategory)
        {
            throw new NotImplementedException();
        }

        [DbFunction("cfn_GetSubGrainStock", "dbo")]
        public static int GetGpartnerSubGrainStock(int GrainCategory, int GpartnerId)
        {
            throw new NotImplementedException();
        }

        [DbFunction("ExtractMasters", "dbo")]
        public static string ExtractMasters(int MasterType, int MasterId)
        {
            throw new NotImplementedException();
        }

        [DbFunction("GetDocumentsByType", "dbo")]
        public static string GetDocumentsByType(int UserProfileId, int Type)
        {
            throw new NotImplementedException();
        }

        [DbFunction("IsFollowing", "dbo")]
        public static bool IsFollowing(int userProfilId, int FollowerUserProfileId)
        {
            throw new NotImplementedException();
        }
    }
}
﻿using ProductAgri.Domain.Model;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace ProductAgri.Application

{
    /// <summary>
    ///
    /// </summary>
    public static class JwtAuthManager
    {
        /// <summary>
        ///
        /// </summary>
        public const string SecretKey = "MyAdvanceSupperKey";

        /// <summary>
        ///
        /// </summary>
        /// <param name="user"></param>
        /// <param name="expire_in_Minutes"></param>
        /// <returns></returns>
        public static AuthTokenModel GenerateJWTToken(UserInfo user, int expire_in_Days, bool isrefershtoken)
        {
            // var symmetric_Key = Convert.FromBase64String(SecretKey);
            var symmetric_Key = Encoding.UTF8.GetBytes(SecretKey);
            var token_Handler = new JwtSecurityTokenHandler();

            var now = DateTime.UtcNow.AddHours(5).AddMinutes(30);
            DateTime expTime;
            if (isrefershtoken)
            {
                expTime = now.AddDays(Convert.ToInt32(expire_in_Days));
            }
            else
            {
                //  expTime = now.AddMinutes(Convert.ToInt32(expire_in_Days));
                expTime = now.AddDays(Convert.ToInt32(expire_in_Days)); // TO DO remove temp refresh token
            }

            var RoleId = Convert.ToInt32(user.RoleId);

            var securitytokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                        {
                    new Claim(ClaimTypes.Email, user.Email is null ? "" : user.Email),
                    new Claim(ClaimTypes.UserData,Convert.ToString(user.UserId)),
                    new Claim(ClaimTypes.Name, user.FullName is null ? "" : user.FullName),
                    new Claim(ClaimTypes.Role, user.MobileNo is null ? "" : user.MobileNo),
                    new Claim(ClaimTypes.Actor,  Convert.ToString(RoleId)),
                    //new Claim(ClaimTypes.Surname,  user.LastName is null ? "" : user.LastName),
                    new Claim(ClaimTypes.GivenName,  Convert.ToString(user.LoginFrom)),
                    new Claim(ClaimTypes.Sid,  Convert.ToString(user.AdminRoleId)),
                    new Claim(ClaimTypes.Expired,Convert.ToString(expTime)),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                }),

                Issuer = "http://oec.com",
                Audience = "http://oec.com",
                Expires = expTime,
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(symmetric_Key), SecurityAlgorithms.HmacSha256Signature)
            };

            var stoken = token_Handler.CreateToken(securitytokenDescriptor);
            var token = token_Handler.WriteToken(stoken);

            if (isrefershtoken && user.RoleId != Actor.Admin)
            {
                Random random = new Random();
                int i = random.Next(100, 999);
                token = token + "%" + i.ToString();
            }

            return new AuthTokenModel { Token = token, ValidTill = expTime };
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        public static ClaimsPrincipal GetPrincipal(string token)
        {
            try
            {
                if (!(token.Contains("bearer") || token.Contains("Bearer")))
                {
                    return null;
                }

                // remove bearer from token
                var rowtoken = token.Trim().Substring(7, token.Length - 7);

                var tokenHandler = new JwtSecurityTokenHandler();
                var jwtToken = tokenHandler.ReadToken(rowtoken) as JwtSecurityToken;

                if (jwtToken == null)
                    return null;

                var symmetricKey = Encoding.UTF8.GetBytes(SecretKey);

                var validationParameters = new TokenValidationParameters()
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidAudience = "http://oec.com",
                    ValidIssuer = "http://oec.com",
                    RequireExpirationTime = true,
                    IssuerSigningKey = new SymmetricSecurityKey(symmetricKey)
                };

                SecurityToken securityToken;
                var principal = tokenHandler.ValidateToken(rowtoken, validationParameters, out securityToken);

                return principal;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
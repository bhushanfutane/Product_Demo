﻿using ProductAgri.Application.Contract;
using ProductAgri.Persistence.Contract;
using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;

namespace ProductAgri.Application
{
    public class LoggingManager : ILoggingManager
    {
        private ILoggerRepository loggerRepository;

        public LoggingManager(ILoggerRepository _loggerRepository)
        {
            loggerRepository = _loggerRepository;
        }

        // public async Task<string> LogException(Exception ex, IHttpContextAccessor httpContext)
        // {
        //     return await loggerRepository.LogToDatabase(ex,httpContext);
        // }

        public async Task LogException(Exception ex, IHttpContextAccessor httpContext)
        {
            await loggerRepository.LogToDatabaseAsync(ex, httpContext);
        }
    }
}
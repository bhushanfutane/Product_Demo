﻿using Microsoft.Extensions.Configuration;
using ProductAgri.Application.Contract;
using ProductAgri.Domain;
using ProductAgri.Domain.Model;
using ProductAgri.Domain.Model.Response;
using ProductAgri.Persistence.Contract;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ProductAgri.Application.Bussiness
{
    public class CategoryApplication : ICategoryApplication
    {
        private readonly ICategoryRepository categories;
        private readonly ISubCategoryRepository subCategories;
        private readonly IConfiguration configuration;
        private readonly IResponseModel responseModel;

        public CategoryApplication(ICategoryRepository categories,
            ISubCategoryRepository subCategories,
            IConfiguration configuration,
            IResponseModel responseModel)
        {
            this.categories = categories;
            this.subCategories = subCategories;
            this.configuration = configuration;
            this.responseModel = responseModel;
        }

        public async Task<ResponseModel> AddAsync(Category category)
        {
            try
            {
                UserInfo user = responseModel.GetCurrentUser();
                var cate = await categories.GetAsync(category.NameEng, 0);
                if (cate != null)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Username Taken...!", null);
                }

                TblCategory category1 = new TblCategory();

                category1.CreatedBy = user.UserId;
                category1.CreatedDate = DateTime.UtcNow;
                category1.NameEng = category.NameEng;
                category1.NameHin = category.NameHin;
                category1.NameMar = category.NameMar;
                category1.Active = category.Active;
                category1 = await categories.AddAsync(category1);
                if (category1.Id == 0)
                {
                    return responseModel.CreateResponse(HttpStatusCode.BadRequest, "Failed to add category");
                }

                return responseModel.CreateResponse(HttpStatusCode.OK, "Category Added", category);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> AddSubAsync(SubCategory subCategory)
        {
            try
            {
                UserInfo user = responseModel.GetCurrentUser();
                var cate = await subCategories.GetAsync(subCategory.NameEng, 0);
                if (cate != null)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Username Taken...!", null);
                }

                TblSubCategory category1 = new TblSubCategory();

                category1.CreatedBy = user.UserId;
                category1.CreatedDate = DateTime.UtcNow;
                category1.NameEng = subCategory.NameEng;
                category1.NameHin = subCategory.NameHin;
                category1.NameMar = subCategory.NameMar;
                category1.Active = subCategory.Active;
                category1 = await subCategories.AddAsync(category1);
                if (category1.Id == 0)
                {
                    return responseModel.CreateResponse(HttpStatusCode.BadRequest, "Failed to add subcategory");
                }

                return responseModel.CreateResponse(HttpStatusCode.OK, "subCategory Added", subCategory);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> GetActive()
        {
            try
            {
                string baseurl = configuration.GetValue<string>("AttachmentsSettings:ImageUrl");
                string NoImage = configuration.GetValue<string>("AttachmentsSettings:NoImage");
                var category = await categories.GetAsync(0, 0, true);
                if (category == null || category.Count == 0)
                {
                    return responseModel.CreateResponse(HttpStatusCode.NoContent, "Empty");
                }
                List<Category> cates = new List<Category>();
                Category cate;
                foreach (var item in category)
                {
                    cate = new Category();
                    cate.Id = item.Id;
                    cate.NameEng = item.NameEng;
                    cate.NameHin = item.NameHin;
                    cate.NameMar = item.NameMar;
                    cate.Active = item.Active;
                    cate.ImagePath = string.IsNullOrEmpty(item.ImagePath) ? NoImage : baseurl + item.ImagePath;
                    cates.Add(cate);
                }
                return responseModel.CreateResponse(HttpStatusCode.OK, "List", cates);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> GetAll()
        {
            try
            {
                string baseurl = configuration.GetValue<string>("AttachmentsSettings:ImageUrl");
                string NoImage = configuration.GetValue<string>("AttachmentsSettings:NoImage");
                var category = await categories.GetAsync(0, 0);
                if (category == null || category.Count == 0)
                {
                    return responseModel.CreateResponse(HttpStatusCode.NoContent, "Empty");
                }
                List<Category> cates = new List<Category>();
                Category cate;
                foreach (var item in category)
                {
                    cate = new Category();
                    cate.Id = item.Id;
                    cate.NameEng = item.NameEng;
                    cate.NameHin = item.NameHin;
                    cate.NameMar = item.NameMar;
                    cate.Active = item.Active;
                    cate.ImagePath = string.IsNullOrEmpty(item.ImagePath) ? NoImage : baseurl + item.ImagePath;
                    cates.Add(cate);
                }
                return responseModel.CreateResponse(HttpStatusCode.OK, "List", cates);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> GetSubActive()
        {
            try
            {
                string baseurl = configuration.GetValue<string>("AttachmentsSettings:ImageUrl");
                string NoImage = configuration.GetValue<string>("AttachmentsSettings:NoImage");
                var category = await subCategories.GetAsync(0, 0, true);
                if (category == null || category.Count == 0)
                {
                    return responseModel.CreateResponse(HttpStatusCode.NoContent, "Empty");
                }
                List<Category> cates = new List<Category>();
                Category cate;
                foreach (var item in category)
                {
                    cate = new Category();
                    cate.Id = item.Id;
                    cate.NameEng = item.NameEng;
                    cate.NameHin = item.NameHin;
                    cate.NameMar = item.NameMar;
                    cate.Active = item.Active.Value;
                    cate.ImagePath = string.IsNullOrEmpty(item.ImagePath) ? NoImage : baseurl + item.ImagePath;
                    cates.Add(cate);
                }
                return responseModel.CreateResponse(HttpStatusCode.OK, "List", cates);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> GetSubAll()
        {
            try
            {
                string baseurl = configuration.GetValue<string>("AttachmentsSettings:ImageUrl");
                string NoImage = configuration.GetValue<string>("AttachmentsSettings:NoImage");
                var category = await subCategories.GetAsync(0, 0);
                if (category == null || category.Count == 0)
                {
                    return responseModel.CreateResponse(HttpStatusCode.NoContent, "Empty");
                }
                List<Category> cates = new List<Category>();
                Category cate;
                foreach (var item in category)
                {
                    cate = new Category();
                    cate.Id = item.Id;
                    cate.NameEng = item.NameEng;
                    cate.NameHin = item.NameHin;
                    cate.NameMar = item.NameMar;
                    cate.Active = item.Active.Value;
                    cate.ImagePath = item.ImagePath;
                    cate.ImagePath = string.IsNullOrEmpty(item.ImagePath) ? NoImage : baseurl + item.ImagePath;
                    cates.Add(cate);
                }
                return responseModel.CreateResponse(HttpStatusCode.OK, "List", cates);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> UpdateAsync(Category category)
        {
            try
            {
                try
                {
                    UserInfo user = responseModel.GetCurrentUser();
                    var cate = await categories.GetAsync(category.Id);
                    if (cate == null)
                    {
                        return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Not found...!", null);
                    }

                    cate.CreatedBy = user.UserId;
                    cate.CreatedDate = DateTime.UtcNow;
                    cate.NameEng = category.NameEng;
                    cate.NameHin = category.NameHin;
                    cate.NameMar = category.NameMar;
                    cate.Active = category.Active;
                    cate = await categories.UpdateAsync(cate);
                    if (cate.Id == 0)
                    {
                        return responseModel.CreateResponse(HttpStatusCode.BadRequest, "Failed to Update category");
                    }

                    return responseModel.CreateResponse(HttpStatusCode.OK, "Category Updated", category);
                }
                catch (CustomException ex)
                {
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw new CustomException("Something Went Wrong...!", ex);
                }
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> UpdateSubAsync(SubCategory subCategory)
        {
            try
            {
                UserInfo user = responseModel.GetCurrentUser();
                var cate = await subCategories.GetAsync(subCategory.Id);
                if (cate == null)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Not found...!", null);
                }

                cate.CreatedBy = user.UserId;
                cate.CreatedDate = DateTime.UtcNow;
                cate.NameEng = subCategory.NameEng;
                cate.NameHin = subCategory.NameHin;
                cate.NameMar = subCategory.NameMar;
                cate.Active = subCategory.Active;
                cate = await subCategories.UpdateAsync(cate);
                if (cate.Id == 0)
                {
                    return responseModel.CreateResponse(HttpStatusCode.BadRequest, "Failed to Update subcategory");
                }

                return responseModel.CreateResponse(HttpStatusCode.OK, "subCategory Updated", subCategory);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

using ProductAgri.Application.Contract;
using ProductAgri.Domain;
using ProductAgri.Domain.Model;
using ProductAgri.Domain.Model.Response;
using ProductAgri.Persistence.Contract;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace ProductAgri.Application
{
    public class UserApplication : IUserApplication
    {
        private IUserRepository userRepository;
        private readonly IResponseModel responseModel;
        private readonly ILoggingManager logManager;
        private readonly IHttpContextAccessor httpContextAccessor;

        private readonly IConfiguration configuration;
        private readonly IHttpClientFactory httpClient;

        public UserApplication(IUserRepository userRepository,
                               IResponseModel responseModel,
                               ILoggingManager logManager,
                               IHttpContextAccessor httpContextAccessor,
                               IConfiguration configuration,
                               IHttpClientFactory httpClient)

        {
            this.userRepository = userRepository;
            this.responseModel = responseModel;
            this.logManager = logManager;
            this.httpContextAccessor = httpContextAccessor;

            this.configuration = configuration;
            this.httpClient = httpClient;
        }

        public async Task<ResponseModel> GetUserAsync(int PageNo, int PageSize)
        {
            try
            {
                AdminUsers adminUsers = new AdminUsers();
                var li = await userRepository.GetAsync(PageNo, PageSize);
                if (li.Users.Count == 0)
                {
                    return responseModel.CreateNotFoundResponse(HttpStatusCode.NoContent, statusMessagee: "Empty List...!", Data: li);
                }
                string baseurl = configuration.GetValue<string>("AttachmentsSettings:ImageUrl");
                string NoImage = configuration.GetValue<string>("AttachmentsSettings:NoImage");
                foreach (var item in li.Users)
                {
                    item.Profilepath = string.IsNullOrEmpty(item.Profilepath) ? NoImage : baseurl + item.Profilepath;
                }

                return responseModel.CreateResponse(HttpStatusCode.OK, "List Of User", Data: li);
            }
            catch (CustomException ex)
            {
                return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                await logManager.LogException(ex, httpContextAccessor);
                return responseModel.CreateInternalServerErrorResponse(HttpStatusCode.InternalServerError, "Cannot find Users....!");
            }
        }

        public async Task<ResponseModel> DeleteUserAsync(int Id)
        {
            try
            {
                var user = await userRepository.GetAsync(Id);
                if (user == null)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Id Is Required ...Cannot Delete User....!");
                }
                await userRepository.RemoveUserAsync(user);
                return responseModel.CreateResponse(HttpStatusCode.OK, "User Deleted Successfully....!");
            }
            catch (CustomException ex)
            {
                return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                await logManager.LogException(ex, httpContextAccessor);
                return responseModel.CreateInternalServerErrorResponse(HttpStatusCode.InternalServerError, "Invalid Credential");
            }
        }

        public async Task<ResponseModel> UserRegistration(UserRegistration userModel)
        {
            try
            {
                TblUser user = await userRepository.GetAsync(userModel.Mobile, 0);
                if (user != null && user.IsActive == true)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "User already exists.!", null);
                }

                #region if first time user reistration send otp

                if (user is null)
                {
                    user = new TblUser()
                    {
                        FullName = userModel.FullName,
                        Mobile = userModel.Mobile,
                        Password = PasswordEncryptDecrypt.Encrypt(userModel.Password),
                        IsActive = false,
                        IsMobileVerified = false,
                        CreatedDate = DateTime.UtcNow
                    };
                    user = await userRepository.AddUserAsync(user);
                    if (user == null)
                    {
                        return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Server Error");
                    }

                    return responseModel.CreateResponse(HttpStatusCode.OK, $"Otp Send on {userModel.Mobile} ");
                }

                #endregion if first time user reistration send otp

                else
                {
                    user.IsActive = true;
                    user.CreatedDate = DateTime.UtcNow;
                    user = await userRepository.UpdateUserAsync(user);

                    UserInfo userInfo = new UserInfo();
                    userInfo.UserId = user.Id;
                    userInfo.Email = user.Email;
                    userInfo.MobileNo = user.Mobile;
                    userInfo.FullName = user.FullName;
                    userInfo.RoleId = Actor.User;
                    userInfo.AdminRoleId = 0;

                    RegistrationResponseModel response = new RegistrationResponseModel();
                    response.UserId = user.Id;

                    response.Email = user.Email;
                    response.FullName = user.FullName;
                    response.MobileNumber = user.Mobile;
                    response.Role = Actor.User.ToString();
                    response.RoleId = (int)Actor.User;
                    string baseurl = configuration.GetValue<string>("AttachmentsSettings:ImageUrl");
                    string NoImage = configuration.GetValue<string>("AttachmentsSettings:UserDefault");

                    return responseModel.CreateResponse(HttpStatusCode.OK, "Welcome to ProductAgri...!", Data: response);
                }
            }
            catch (CustomException ex)
            {
                return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                await logManager.LogException(ex, httpContextAccessor);
                return responseModel.CreateInternalServerErrorResponse(HttpStatusCode.InternalServerError, "Server Error");
            }
        }

        public async Task<ResponseModel> Login(UserLoginModel userModel)
        {
            try
            {
                if (string.IsNullOrEmpty(userModel.Mobile) || string.IsNullOrEmpty(userModel.Password))
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Invalid Credential", Data: null);
                }

                TblUser User = await userRepository.GetAsync(userModel.Mobile, PasswordEncryptDecrypt.Encrypt(userModel.Password));
                if (User is null)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Username or password incorrect..! ", Data: null);
                }

                UserInfo userInfo = new UserInfo();
                userInfo.UserId = User.Id;
                userInfo.Email = User.Email;
                userInfo.MobileNo = User.Mobile;
                userInfo.FullName = User.FullName;
                userInfo.RoleId = Actor.User;
                userInfo.AdminRoleId = 0;
                userInfo.AdminRoleId = 0;

                RegistrationResponseModel response = new RegistrationResponseModel();
                response.UserId = User.Id;
                response.Email = User.Email;
                response.FullName = User.FullName;
                response.MobileNumber = User.Mobile;
                response.Role = Actor.User.ToString();
                response.RoleId = (int)Actor.User;
                string baseurl = configuration.GetValue<string>("AttachmentsSettings:ImageUrl");
                string NoImage = configuration.GetValue<string>("AttachmentsSettings:UserDefault");

                return responseModel.CreateResponse(HttpStatusCode.OK, "Welcome to ProductAgri...!", Data: response);
            }
            catch (CustomException ex)
            {
                return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                await logManager.LogException(ex, httpContextAccessor);
                return responseModel.CreateInternalServerErrorResponse(HttpStatusCode.InternalServerError, "Username or password incorrect..!");
            }
        }

        public async Task<ResponseModel> SetNewPassword(SetPassword setPassword)
        {
            try
            {
                TblUser user = await userRepository.GetAsync(setPassword.Mobile);
                if (user is null)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Invalid User", Data: null);
                }
                if (string.IsNullOrEmpty(setPassword.Otp))
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Invalid Otp", Data: null);
                }
                if (string.IsNullOrEmpty(setPassword.NewPassword))
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Invalid Otp", Data: null);
                }
                else
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Invalid Otp", Data: null);
                }
            }
            catch (CustomException ex)
            {
                return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                await logManager.LogException(ex, httpContextAccessor);
                return responseModel.CreateInternalServerErrorResponse(HttpStatusCode.InternalServerError, "Cannot find Stock....!");
            }
        }

        public async Task<ResponseModel> ChangePasswordAsync(ChangePasswordModel changePasswordModel)
        {
            try
            {
                UserInfo user = responseModel.GetCurrentUser();
                TblUser users = await userRepository.GetAsync(user.UserId);
                if (users == null)
                {
                    return responseModel.CreateResponse(HttpStatusCode.BadRequest, "Cant Find User..! ", Data: null);
                }
                string pass = PasswordEncryptDecrypt.Encrypt(changePasswordModel.OldPassword);
                if (users.Password == pass)
                {
                    users.Password = PasswordEncryptDecrypt.Encrypt(changePasswordModel.NewPassword);
                    users = await userRepository.UpdateUserAsync(users);
                    return responseModel.CreateResponse(HttpStatusCode.OK, "Password Change Succesfully ", Data: null);
                }
                return responseModel.CreateResponse(HttpStatusCode.BadRequest, "Password Change Failed ", Data: null);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                await logManager.LogException(ex, httpContextAccessor);
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }

        public async Task<ResponseModel> UpdateUserDetail(string Fullname)
        {
            try
            {
                UserInfo user = responseModel.GetCurrentUser();
                if (!string.IsNullOrEmpty(Fullname))
                {
                    TblUser tblUser = await userRepository.GetAsync(user.UserId);
                    tblUser.FullName = Fullname;
                    tblUser.UpdatedBy = user.UserId; ;
                    tblUser.UpdatedDate = DateTime.UtcNow;

                    var updateUserList = await userRepository.UpdateUserAsync(tblUser);
                    if (updateUserList == null)
                    {
                        return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Cannot Update User ....!");
                    }
                    else
                    {
                        return responseModel.CreateResponse(HttpStatusCode.OK, "User detail Updated Successfully....!", Fullname);
                    }
                }
                return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Cannot Updated User....!");
            }
            catch (CustomException ex)
            {
                return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                await logManager.LogException(ex, httpContextAccessor);
                return responseModel.CreateInternalServerErrorResponse(HttpStatusCode.InternalServerError, "Something Went Wrong...!");
            }
        }
    }
}
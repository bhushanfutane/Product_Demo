﻿using Microsoft.Extensions.Configuration;
using ProductAgri.Application.Contract;
using ProductAgri.Domain;
using ProductAgri.Domain.Model;
using ProductAgri.Domain.Model.Response;
using ProductAgri.Persistence.Contract;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ProductAgri.Application.Bussiness
{
    public class ProductApplication : IProductApplication
    {
        private readonly IProductRepository repository;
        private readonly ICategoryRepository categoryRepository;
        private readonly IResponseModel responseModel;

        private readonly IConfiguration configuration;

        public ProductApplication(IProductRepository repository,
            ICategoryRepository categoryRepository,
            IResponseModel responseModel,

            IConfiguration configuration)
        {
            this.repository = repository;
            this.categoryRepository = categoryRepository;
            this.responseModel = responseModel;

            this.configuration = configuration;
        }

        public async Task<ResponseModel> AddAsync(Prod prod)
        {
            try
            {
                UserInfo user = responseModel.GetCurrentUser();
                var cate = await repository.GetAsync(prod.NameEng, 0);
                if (cate != null)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Name Taken...!", null);
                }

                TblProduct product = new TblProduct();

                product.CreatedBy = user.UserId;
                product.CreatedDate = DateTime.UtcNow;
                product.NameEng = prod.NameEng;
                product.NameHin = prod.NameHin;
                product.NameMar = prod.NameMar;
                product.Active = prod.Active;
                product.Price = prod.Price;
                product.Mrp = prod.Mrp;
                product.CategoryId = prod.CategoryId;
                product.Weight = prod.Weight;
                product.Discription = prod.Discription;
                product.DiscriptionHn = prod.DiscriptionHn;
                product.DiscriptionMr = prod.DiscriptionMr;

                product = await repository.AddAsync(product);
                if (product.Id == 0)
                {
                    return responseModel.CreateResponse(HttpStatusCode.BadRequest, "Failed to add Product");
                }

                return responseModel.CreateResponse(HttpStatusCode.OK, "Product  Added", prod);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> GetActive(int Pagesize, int Pageno)
        {
            try
            {
                string baseurl = configuration.GetValue<string>("AttachmentsSettings:ImageUrl");
                string NoImage = configuration.GetValue<string>("AttachmentsSettings:NoImage");
                var prods = await repository.GetAsync(Pagesize, Pageno, true);
                if (prods == null || prods.Count == 0)
                {
                    return responseModel.CreateResponse(HttpStatusCode.NoContent, "Empty");
                }
                AddProd addProds = new AddProd();
                addProds.Count = prods.Count;
                Prod prod;
                addProds.Product = new List<Prod>();
                foreach (var item in prods)
                {
                    prod = new Prod();
                    prod.Id = item.Id;
                    prod.NameEng = item.NameEng;
                    prod.NameHin = item.NameHin;
                    prod.NameMar = item.NameMar;
                    prod.Active = item.Active;
                    prod.Price = item.Price.Value;
                    prod.Mrp = item.Mrp.Value;
                    prod.Discription = item.Discription;
                    prod.DiscriptionHn = item.DiscriptionHn;
                    prod.DiscriptionMr = item.DiscriptionMr;
                    prod.CategoryId = item.CategoryId.GetValueOrDefault();
                    prod.ImageUrl = string.IsNullOrEmpty(item.ImageUrl) ? NoImage : baseurl + item.ImageUrl;
                    prod.Weight = item.Weight ?? 0;

                    addProds.Product.Add(prod);
                }
                return responseModel.CreateResponse(HttpStatusCode.OK, "List", addProds);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> GetAll(int Pagesize, int Pageno)
        {
            try
            {
                string baseurl = configuration.GetValue<string>("AttachmentsSettings:ImageUrl");
                string NoImage = configuration.GetValue<string>("AttachmentsSettings:NoImage");
                var prods = await repository.GetAsync(Pagesize, Pageno);
                if (prods == null || prods.Count == 0)
                {
                    return responseModel.CreateResponse(HttpStatusCode.NoContent, "Empty");
                }
                AddProd addProds = new AddProd();
                addProds.Count = prods.Count;
                Prod prod;
                addProds.Product = new List<Prod>();

                foreach (var item in prods)
                {
                    prod = new Prod();
                    prod.Id = item.Id;
                    prod.NameEng = item.NameEng;
                    prod.NameHin = item.NameHin;
                    prod.NameMar = item.NameMar;
                    prod.Active = item.Active;
                    prod.Price = item.Price.Value;
                    prod.Mrp = item.Mrp.Value;
                    prod.Discription = item.Discription;
                    prod.DiscriptionHn = item.DiscriptionHn;
                    prod.DiscriptionMr = item.DiscriptionMr;
                    prod.CategoryId = item.CategoryId.GetValueOrDefault();
                    prod.Weight = item.Weight.GetValueOrDefault();

                    prod.ImageUrl = string.IsNullOrEmpty(item.ImageUrl) ? NoImage : baseurl + item.ImageUrl;
                    addProds.Product.Add(prod);
                }
                return responseModel.CreateResponse(HttpStatusCode.OK, "List", addProds);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> UpdateAsync(Prod prod)
        {
            try
            {
                try
                {
                    UserInfo user = responseModel.GetCurrentUser();
                    TblProduct product = await repository.GetAsync(prod.Id);

                    product.UpdatedBy = user.UserId;
                    product.UpdatedDate = DateTime.UtcNow;
                    product.NameEng = prod.NameEng;
                    product.NameHin = prod.NameHin;
                    product.NameMar = prod.NameMar;
                    product.Active = prod.Active;
                    product.Price = prod.Price;
                    product.Mrp = prod.Mrp;
                    product.CategoryId = prod.CategoryId;
                    product.Weight = prod.Weight;
                    product.Discription = prod.Discription;
                    product.DiscriptionHn = prod.DiscriptionHn;
                    product.DiscriptionMr = prod.DiscriptionMr;

                    product = await repository.UpdateAsync(product);
                    if (product.Id == 0)
                    {
                        return responseModel.CreateResponse(HttpStatusCode.BadRequest, "Failed to Update Product");
                    }

                    return responseModel.CreateResponse(HttpStatusCode.OK, "Product Updated", prod);
                }
                catch (CustomException ex)
                {
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw new CustomException("Something Went Wrong...!", ex);
                }
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> GetProducts(int Pagesize, int Pageno)
        {
            try
            {
                UserInfo user = responseModel.GetCurrentUser();
                string baseurl = configuration.GetValue<string>("AttachmentsSettings:ImageUrl");
                string NoImage = configuration.GetValue<string>("AttachmentsSettings:NoImage");
                var prods = await repository.GetAsync(0, 0, true);
                if (prods == null || prods.Count == 0)
                {
                    return responseModel.CreateResponse(HttpStatusCode.NoContent, "Empty");
                }
                Products addProds = new Products();
                addProds.Count = prods.Count;
                Product prod;
                var products = prods.Paginate(Pagesize, Pageno);
                addProds.Product = new List<Product>();
                foreach (var item in products)
                {
                    prod = new Product();
                    prod.Id = item.Id;
                    prod.NameEng = item.NameEng;
                    prod.NameHin = item.NameHin;
                    prod.NameMar = item.NameMar;
                    prod.Active = item.Active;
                    prod.Price = item.Price.Value;
                    prod.Mrp = item.Mrp.Value;
                    prod.Discription = item.Discription;
                    prod.DiscriptionHn = item.DiscriptionHn;
                    prod.DiscriptionMr = item.DiscriptionMr;
                    prod.CategoryId = item.CategoryId.GetValueOrDefault();
                    prod.ImageUrl = string.IsNullOrEmpty(item.ImageUrl) ? NoImage : baseurl + item.ImageUrl;
                    prod.Weight = item.Weight ?? 0;

                    addProds.Product.Add(prod);
                }
                return responseModel.CreateResponse(HttpStatusCode.OK, "List", addProds);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }
    }
}
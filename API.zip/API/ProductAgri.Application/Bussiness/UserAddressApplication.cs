﻿using ProductAgri.Application.Contract;
using ProductAgri.Domain;
using ProductAgri.Domain.Model;
using ProductAgri.Domain.Model.Response;
using ProductAgri.Persistence.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ProductAgri.Application.Bussiness
{
    public class UserAddressApplication : IUserAddressApplication
    {
        private readonly IUserAddressRepository repository;
        private readonly IResponseModel responseModel;

        public UserAddressApplication(IUserAddressRepository repository, IResponseModel responseModel)
        {
            this.repository = repository;
            this.responseModel = responseModel;
        }

        public async Task<ResponseModel> GetUserAddressAsync()
        {
            try
            {
                UserInfo user = responseModel.GetCurrentUser();
                var li = await repository.GetAllAsync(user.UserId);
                if (li.Count == 0)
                {
                    return responseModel.CreateNotFoundResponse(HttpStatusCode.NoContent, statusMessagee: "Empty List...!", Data: li);
                }

                return responseModel.CreateResponse(HttpStatusCode.OK, "List Of Area", Data: li);
            }
            catch (CustomException ex)
            {
                return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                return responseModel.CreateInternalServerErrorResponse(HttpStatusCode.InternalServerError, "Cannot find Area....!");
            }
        }

        public async Task<ResponseModel> DeleteUserAddressAsync(int Id)
        {
            try
            {
                var user = await repository.GetAsync(Id);
                if (user == null)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Cannot Delete User Address....!");
                }
                if (user.Isdefault.Value)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Cannot Delete Default Address....!");
                }
                await repository.Remove(user);
                return responseModel.CreateResponse(HttpStatusCode.OK, "User Address Deleted Successfully....!");
            }
            catch (CustomException ex)
            {
                return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                return responseModel.CreateInternalServerErrorResponse(HttpStatusCode.InternalServerError, "Cannot find User Address ....!");
            }
        }

        public async Task<ResponseModel> AddUserAddressAsync(UserAddressModel userAddress)
        {
            try
            {
                //bool IsServiceAvailable = await repository.IsServiceAvailable(userAddress.Pincode, userAddress.AreaName);
                bool IsServiceAvailable = true;
                if (!IsServiceAvailable)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Service Not Available in this area...!", userAddress);
                }

                UserInfo user = responseModel.GetCurrentUser();
                List<TblUserAddress> list = await repository.GetAllAsync(user.UserId);
                TblUserAddress tblUserAddress = new TblUserAddress();
                tblUserAddress.UserId = user.UserId;
                tblUserAddress.HouseNo = userAddress.HouseNo;
                tblUserAddress.AppartmentName = userAddress.AppartmentName;
                tblUserAddress.StreetDetails = userAddress.StreetDetails;
                tblUserAddress.Landmark = userAddress.Landmark;
                tblUserAddress.City = userAddress.City;
                tblUserAddress.Contact = userAddress.Contact;
                tblUserAddress.AreaName = userAddress.AreaName;
                tblUserAddress.Pincode = userAddress.Pincode;
                tblUserAddress.AddressType = userAddress.AddressType;
                tblUserAddress.NiknameAddress = userAddress.NiknameAddress;
                tblUserAddress.Isdefault = userAddress.Isdefault;
                tblUserAddress.CreatedDate = DateTime.UtcNow;
                tblUserAddress.CreatedBy = user.UserId;
                if (userAddress.Isdefault)
                {
                    foreach (var item in list)
                    {
                        item.Isdefault = false;
                    }
                    list = await repository.UpdateRangeAsync(list);
                }
                else
                {
                    var IsAnyDefault = list.Where(a => a.Isdefault == true).Any();
                    if (!IsAnyDefault)
                    {
                        return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Please select Atleast One Default Address...!");
                    }
                }
                tblUserAddress = await repository.Add(tblUserAddress);

                if (tblUserAddress.Id == 0)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Cannot Add User address ....!");
                }

                return responseModel.CreateResponse(HttpStatusCode.OK, "User Address Added Successfully....!", userAddress);
            }
            catch (CustomException ex)
            {
                return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                return responseModel.CreateInternalServerErrorResponse(HttpStatusCode.InternalServerError, "Something Went Wrong...!");
            }
        }

        public async Task<ResponseModel> UpdateUserAddressAsync(UserAddressModel userAddress)
        {
            try
            {
                //bool IsServiceAvailable = await repository.IsServiceAvailable(userAddress.Pincode, userAddress.AreaName);
                bool IsServiceAvailable = true;
                if (!IsServiceAvailable)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Service Not Available in this area...!", userAddress);
                }

                UserInfo user = responseModel.GetCurrentUser();
                List<TblUserAddress> list = await repository.GetAllAsync(user.UserId);
                TblUserAddress tblUserAddress = list.Where(a => a.Id == userAddress.Id).FirstOrDefault();
                tblUserAddress.UserId = user.UserId;
                tblUserAddress.HouseNo = userAddress.HouseNo;
                tblUserAddress.AppartmentName = userAddress.AppartmentName;
                tblUserAddress.StreetDetails = userAddress.StreetDetails;
                tblUserAddress.Landmark = userAddress.Landmark;
                tblUserAddress.City = userAddress.City;
                tblUserAddress.Contact = userAddress.Contact;
                tblUserAddress.AreaName = userAddress.AreaName;
                tblUserAddress.Pincode = userAddress.Pincode;
                tblUserAddress.AddressType = userAddress.AddressType;
                tblUserAddress.NiknameAddress = userAddress.NiknameAddress;
                tblUserAddress.Isdefault = userAddress.Isdefault;
                tblUserAddress.UpdatedBy = user.UserId;
                tblUserAddress.UpdatedDate = DateTime.UtcNow;

                if (userAddress.Isdefault)
                {
                    foreach (var item in list)
                    {
                        item.Isdefault = false;
                    }
                    list = await repository.UpdateRangeAsync(list);
                    tblUserAddress.Isdefault = userAddress.Isdefault;
                }
                else
                {
                    var IsAnyDefault = list.Where(a => a.Isdefault == true).Any();
                    if (!IsAnyDefault)
                    {
                        return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Please select Atleast One Default Address...!");
                    }
                }
                tblUserAddress = await repository.Update(tblUserAddress);
                if (tblUserAddress.Id == 0)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Cannot update User address ....!");
                }

                return responseModel.CreateResponse(HttpStatusCode.OK, "User Address Updated Successfully....!", userAddress);
            }
            catch (CustomException ex)
            {
                return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                return responseModel.CreateInternalServerErrorResponse(HttpStatusCode.InternalServerError, "Something Went Wrong...!");
            }
        }
    }
}
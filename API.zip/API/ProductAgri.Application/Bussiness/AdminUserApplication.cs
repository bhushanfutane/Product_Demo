using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using ProductAgri.Domain.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using ProductAgri.Application.Contract;
using ProductAgri.Domain.Model.Response;
using ProductAgri.Persistence.Contract;
using ProductAgri.Domain;

namespace ProductAgri.Application.Bussiness
{
    public class AdminUserApplication : IAdminUserApplication
    {
        private IAdminUserRepository AdminUserRepo;
        private readonly IResponseModel responseModel;
        private readonly IConfiguration configuration;

        private readonly ILoggingManager logManager;
        private readonly IUserRepository userRepository;
        private readonly IHttpContextAccessor httpContextAccessor;

        public AdminUserApplication(IAdminUserRepository _AdminUserRepo,
            IResponseModel responseModel,
            IConfiguration configuration,
            ILoggingManager logManager,
            IUserRepository userRepository,
            IHttpContextAccessor httpContextAccessor)
        {
            AdminUserRepo = _AdminUserRepo;
            this.responseModel = responseModel;
            this.configuration = configuration;
            this.logManager = logManager;
            this.userRepository = userRepository;
            this.httpContextAccessor = httpContextAccessor;
        }

        public async Task<ResponseModel> AddAdminUser(AdminUserRegistrationModel adminUser)
        {
            try
            {
                var userInfo = responseModel.GetCurrentUser();
                var isTaken = await AdminUserRepo.IsUserNameTaken(adminUser.MobileNo);
                if (isTaken != null)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Username Taken...!", null);
                }

                TblAdminUser tblAdminUser = new TblAdminUser()
                {
                    CreatedBy = userInfo.UserId,
                    CreatedDate = DateTime.UtcNow,
                    Address = adminUser.Address,
                    Email = adminUser.Email,
                    FirstName = adminUser.FirstName,
                    IsVerify = true,
                    LastName = adminUser.LastName,
                    MobileNo = adminUser.MobileNo,
                    RegistrationDate = adminUser.RegistrationDate,
                    // RoleId = adminUser.RoleId,
                    UserName = adminUser.MobileNo,
                    IsActive = adminUser.IsActive.Value,
                    IsDelete = false,
                    Password = PasswordEncryptDecrypt.Encrypt(adminUser.Password)
                };

                var res = await AdminUserRepo.AddAdminUser(tblAdminUser);

                return responseModel.CreateResponse(HttpStatusCode.OK, "Admin User Added", adminUser);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> GetAdminUser()
        {
            try
            {
                var admin = await AdminUserRepo.GetAdminUser();

                List<AdminUserRegistrationModel> adminUserRegistration = new List<AdminUserRegistrationModel>();
                AdminUserRegistrationModel adminUser;
                foreach (var item in admin)
                {
                    adminUser = new AdminUserRegistrationModel
                    {
                        Id = item.Id,
                        FirstName = item.FirstName,
                        LastName = item.LastName,
                        UserName = item.UserName,
                        Email = item.Email,
                        IsActive = item.IsActive,
                        MobileNo = item.MobileNo,
                        //RoleId = item.RoleId,
                        Address = item.Address,
                        RegistrationDate = item.RegistrationDate
                    };
                    adminUserRegistration.Add(adminUser);
                }
                if (admin.Count == 0)
                {
                    return responseModel.CreateNotFoundResponse(HttpStatusCode.NoContent, statusMessagee: "Empty List...!", Data: null);
                }

                return responseModel.CreateResponse(HttpStatusCode.OK, "List Of Employees", Data: adminUserRegistration);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> GetAdminUserById()
        {
            try
            {
                UserInfo userInfo = responseModel.GetCurrentUser();
                TblAdminUser tblAdminUser = await AdminUserRepo.GetAdminUserById(userInfo.UserId);
                if (tblAdminUser is null)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Cannot Find Admin User...!", null);
                }
                string baseurl = configuration.GetValue<string>("AttachmentsSettings:ImageUrl");
                string NoImage = configuration.GetValue<string>("AttachmentsSettings:NoImage");
                AdminUserInfo AdminUserRegistration = new AdminUserInfo()
                {
                    Address = tblAdminUser.Address,
                    Email = tblAdminUser.Email,
                    FirstName = tblAdminUser.FirstName,
                    Id = tblAdminUser.Id,
                    LastName = tblAdminUser.LastName,
                    MobileNo = tblAdminUser.MobileNo,
                    UserName = tblAdminUser.UserName,
                };
                return responseModel.CreateResponse(HttpStatusCode.OK, "Admin User Info..!", AdminUserRegistration);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> RemoveAdminUser(int EmpId)
        {
            try
            {
                TblAdminUser tblAdminUser = await AdminUserRepo.GetAdminUserById(EmpId);
                if (tblAdminUser is null)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Cannot Find Admin User...!", null);
                }
                var res = await AdminUserRepo.RemoveAdminUser(tblAdminUser);

                return responseModel.CreateResponse(HttpStatusCode.OK, "Admin User Removed", res);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> UpdateAdminUser(AdminUserRegistrationModel adminUser)
        {
            try
            {
                var userInfo = responseModel.GetCurrentUser();
                TblAdminUser tblAdminUser = await AdminUserRepo.GetAdminUserById(adminUser.Id);

                if (tblAdminUser is null)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Cannot Find User...!");
                }

                var isTaken = await AdminUserRepo.IsUserNameTaken(adminUser.MobileNo, adminUser.Id);
                if (isTaken != null)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Username Taken...!", null);
                }
                tblAdminUser.CreatedBy = userInfo.UserId;
                tblAdminUser.UpdatedDate = DateTime.UtcNow;
                tblAdminUser.Address = adminUser.Address;
                tblAdminUser.Email = adminUser.Email;
                tblAdminUser.FirstName = adminUser.FirstName;
                tblAdminUser.IsVerify = true;
                tblAdminUser.LastName = adminUser.LastName;
                tblAdminUser.MobileNo = adminUser.MobileNo;
                tblAdminUser.RegistrationDate = adminUser.RegistrationDate;
                // tblAdminUser.RoleId = adminUser.RoleId;
                tblAdminUser.UserName = adminUser.MobileNo;
                tblAdminUser.IsActive = adminUser.IsActive.Value;
                tblAdminUser.IsDelete = false;
                var res = await AdminUserRepo.UpdateAdminUser(tblAdminUser);
                return responseModel.CreateResponse(HttpStatusCode.OK, "Admin User Updated", adminUser);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw new CustomException("Something Went Wrong...!", ex);
            }
        }

        public async Task<ResponseModel> Login(UserLoginModel userModel)
        {
            try
            {
                if (string.IsNullOrEmpty(userModel.Mobile))
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Username Cannot Be Empty", Data: null);
                }

                if (string.IsNullOrEmpty(userModel.Password))
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Password Cannot Be Empty", Data: null);
                }

                TblAdminUser User = await AdminUserRepo.GetAdminUserByForLogin(userModel.Mobile, PasswordEncryptDecrypt.Encrypt(userModel.Password), false);
                if (User is null)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Invalid Credential", Data: null);
                }
                UserInfo userInfo = new UserInfo();
                userInfo.UserId = User.Id;
                userInfo.Email = User.Email;
                userInfo.MobileNo = User.MobileNo;
                userInfo.FullName = User.FirstName + " " + User.LastName;
                userInfo.RoleId = Actor.Admin;

                RegistrationResponseModel response = new RegistrationResponseModel();
                response.UserId = User.Id;
                response.Email = User.Email;
                response.FullName = User.FirstName + " " + User.LastName;
                response.MobileNumber = User.MobileNo;
                return responseModel.CreateResponse(HttpStatusCode.OK, "Welcome to ProductAgri..!...!", Data: response);
            }
            catch (CustomException ex)
            {
                return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                await logManager.LogException(ex, httpContextAccessor);
                return responseModel.CreateInternalServerErrorResponse(HttpStatusCode.InternalServerError, "Can not send otp");
            }
        }

        public async Task<ResponseModel> SetNewPassword(SetPassword setPassword)
        {
            try
            {
                TblAdminUser user = await AdminUserRepo.GetAdminUserByForLogin(setPassword.Mobile, false);
                if (user is null)
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Invalid User", Data: null);
                }
                if (string.IsNullOrEmpty(setPassword.Otp))
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Invalid Otp", Data: null);
                }
                if (string.IsNullOrEmpty(setPassword.NewPassword))
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Invalid Password", Data: null);
                }
                else
                {
                    return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, "Invalid Otp", Data: null);
                }
            }
            catch (CustomException ex)
            {
                return responseModel.CreateBadRequestResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            catch (Exception ex)
            {
                await logManager.LogException(ex, httpContextAccessor);
                return responseModel.CreateInternalServerErrorResponse(HttpStatusCode.InternalServerError, "Can not send otp");
            }
        }

        public async Task<ResponseModel> ChangePasswordAsync(ChangePasswordModel changePasswordModel)
        {
            try
            {
                UserInfo user = responseModel.GetCurrentUser();
                TblAdminUser users = await AdminUserRepo.GetAdminUserById(user.UserId);
                if (users.Password == null)
                {
                    return responseModel.CreateResponse(HttpStatusCode.BadRequest, "Can not get User...! ", Data: null);
                }
                string pass = PasswordEncryptDecrypt.Encrypt(changePasswordModel.OldPassword);
                if (users.Password == pass)
                {
                    users.Password = PasswordEncryptDecrypt.Encrypt(changePasswordModel.NewPassword);
                    users = await AdminUserRepo.UpdateAdminUser(users);
                    return responseModel.CreateResponse(HttpStatusCode.OK, "Password Change Succesfully ", Data: null);
                }
                return responseModel.CreateResponse(HttpStatusCode.BadRequest, "Password Change Failed ", Data: null);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                await logManager.LogException(ex, httpContextAccessor);
                throw new CustomException("Something Went Wrong..!", ex);
            }
        }
    }
}
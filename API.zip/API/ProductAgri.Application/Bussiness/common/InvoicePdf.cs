// using System;
// using System.IO;
// using System.Net.Http;
// //using AutoMapper.Configuration;
// using iTextSharp.text;
// using iTextSharp.text.pdf;
// using Microsoft.AspNetCore.Hosting;
// using FlourPicker.Domain.Model;
// using FlourPicker.Domain.Model.Response;
// using Castle.Core.Configuration;
// using FlourPicker.Domain;
// // using System.Reflection.Metadata;
// using System.Drawing;
// //using NPOI.XWPF.UserModel;

// namespace FlourPicker.Application
// {
//     public class InvoicePdf
//     {
//         private readonly IResponseModel responseModel;
//         private readonly IConfiguration configuration;
//         public InvoicePdf(IResponseModel responseModel, IConfiguration configuration)
//         {
//             this.responseModel = responseModel;
//             this.configuration = configuration;

//         }

//         public static string GeneratePDF(string serverpath, string UserId, InvoiceModel InvModel, string logoPath)
//         {
//             string newfilepath = "";

//             string folderPath = Path.Combine(serverpath, UserId);

//             ResponseModel res = new ResponseModel();
//             MemoryStream memoryStream = new MemoryStream();
//             Document document = new Document(PageSize.A5.Rotate(), 0f, 0f, 10f, 10f);
//             ///  document.SetMargins(0f,0f,0f,0f);
//             /// document.GetLeft(0f);
//             // document.SetPageSize(iTextSharp.text.PageSize.A5);
//             //  doc.SetPageSize(iTextSharp.text.PageSize.A4.Rotate());
//             if (!System.IO.Directory.Exists(folderPath))
//             {
//                 System.IO.Directory.CreateDirectory(folderPath);
//             }




//             Random rand = new Random();

//             string name = rand.Next(1000, 9000).ToString();

//             string filename = Path.Combine(folderPath, name + ".pdf");//folderPath + "\\" + name + ".pdf";
//             string returnFilePath = UserId + "/" + name + ".pdf";
//             FileStream fs = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None);
//             try
//             {

//                 PdfWriter writer = PdfWriter.GetInstance(document, fs);

//                 Font font1 = new Font(Font.FontFamily.TIMES_ROMAN, 9, Font.BOLD);
//                 Font font2 = new Font(Font.FontFamily.TIMES_ROMAN, 9);
//                 Font font3 = new Font(Font.FontFamily.TIMES_ROMAN, 9);
//                 Font font4 = new Font(Font.FontFamily.TIMES_ROMAN, 9, Font.BOLD, BaseColor.BLACK);
//                 Font font5 = new Font(Font.FontFamily.TIMES_ROMAN, 9);
//                 Font font6 = new Font(Font.FontFamily.TIMES_ROMAN, 7, Font.BOLD);
//                 Font font7 = new Font(Font.FontFamily.TIMES_ROMAN, 6);

//                 #region Header

//                 float[] headercolumnSpecification = { 100f, 15f, 100f };
//             
    // PdfPTable headertable = new PdfPTable(headercolumnSpecification);
//                 headertable.WidthPercentage = 95f;


//                 headertable.DefaultCell.Border = 0;

//                 PdfPCell blankCell = new PdfPCell(new Phrase());
//                 blankCell.Border = 0;

//                 iTextSharp.text.Image jpeg = iTextSharp.text.Image.GetInstance(logoPath);
//                 jpeg.ScaleToFit(100f, 120f);

//                 PdfPCell Headerlogo = new PdfPCell(jpeg);
//                 Headerlogo.Border = 0;
//                 Headerlogo.BorderWidthBottom = 1;

//                 Headerlogo.HorizontalAlignment = Element.ALIGN_LEFT;

//                 PdfPCell headerc5 = new PdfPCell(new Phrase("INVOICE", font1));
//                 headerc5.Colspan = 3;
//                 headerc5.Border = 0;
//                 headerc5.HorizontalAlignment = Element.ALIGN_CENTER;


//                 PdfPTable tblInvoiceDetail = new PdfPTable(1);
//                 tblInvoiceDetail.SpacingBefore = 5f;

//                 tblInvoiceDetail.SpacingAfter = 5f;



//                 PdfPCell InvoiceNoCell = new PdfPCell(new Phrase("Invoice No.:  " + InvModel.InvoiceNumber , font1));
//                 InvoiceNoCell.Border = 0;
//                 InvoiceNoCell.HorizontalAlignment = Element.ALIGN_LEFT;

//                 PdfPCell InvoiceDateCell = new PdfPCell(new Phrase("Invoice Date :  " + InvModel.InvoiceDate, font1));
//                 InvoiceDateCell.Border = 0;
//                 InvoiceDateCell.HorizontalAlignment = Element.ALIGN_LEFT;

//                 tblInvoiceDetail.AddCell(InvoiceNoCell);
//                 tblInvoiceDetail.AddCell(InvoiceDateCell);
//                 PdfPCell OrderIdCell = new PdfPCell(new Phrase("Order Id : " + InvModel.OrderId, font1));
//                 OrderIdCell.Border = 0;
//                 OrderIdCell.HorizontalAlignment = Element.ALIGN_LEFT;
//                 tblInvoiceDetail.AddCell(OrderIdCell);
//                 // PdfPCell PaymentModel = new PdfPCell(new Phrase("Payment Mode : " + InvModel.PaymentMode, font1));
//                 // PaymentModel.Border = 0;
//                 // PaymentModel.HorizontalAlignment = Element.ALIGN_LEFT;
//                 // tblInvoiceDetail.AddCell(PaymentModel);


//                 headerc5.HorizontalAlignment = Element.ALIGN_CENTER;

//                 headertable.AddCell(headerc5);
//                 headertable.AddCell(Headerlogo);
//                 headertable.AddCell(blankCell);
//                 headertable.AddCell(tblInvoiceDetail);
//                 blankCell.Colspan = 3;
//                 headertable.AddCell(blankCell);

//                 PdfPCell headerc6 = new PdfPCell(new Phrase());
//                 headerc6.UseVariableBorders = false;
//                 headerc6.BorderColorBottom = BaseColor.BLACK;
//                 headerc6.BorderWidthBottom = 1f;
//                 headerc6.Colspan = 3;
//                 headertable.AddCell(headerc6);
//                 headertable.AddCell(headerc6);
//                 headertable.AddCell(blankCell);

//                 PdfPTable tblBillingAddress = new PdfPTable(1);
//                 tblBillingAddress.SpacingBefore = 5f;
//                 tblBillingAddress.SpacingAfter = 5f;

//                 PdfPCell billingAddressCell = new PdfPCell(new Phrase("Billing Address:  ", font1));
//                 billingAddressCell.Border = 0;
//                 billingAddressCell.HorizontalAlignment = Element.ALIGN_LEFT;

//                 PdfPCell hBillNameBy = new PdfPCell(new Phrase(InvModel.BillingByName, font3));
//                 hBillNameBy.Border = 0;
//                 hBillNameBy.HorizontalAlignment = Element.ALIGN_LEFT;

//                 PdfPCell hBillingAddress = new PdfPCell(new Phrase(InvModel.BillingByAddress, font2));
//                 hBillingAddress.Border = 0;
//                 hBillingAddress.HorizontalAlignment = Element.ALIGN_LEFT;
//                 tblBillingAddress.AddCell(billingAddressCell);
//                 tblBillingAddress.AddCell(hBillNameBy);
//                 tblBillingAddress.AddCell(hBillingAddress);


//                 PdfPTable tblShippngAddress = new PdfPTable(1);
//                 tblBillingAddress.SpacingBefore = 5f;
//                 tblBillingAddress.SpacingAfter = 5f;
//                 //  tblBillingAddress.SpacingBefore = 5f;
//                 //  tblBillingAddress.SpacingAfter = 5f;
//                 PdfPCell shipingAddressCell = new PdfPCell(new Phrase("Shipping Address:  ", font1));
//                 shipingAddressCell.Border = 0;
//                 shipingAddressCell.HorizontalAlignment = Element.ALIGN_LEFT;

//                 PdfPCell hShippingNameBy = new PdfPCell(new Phrase(InvModel.ShippingByName, font3));
//                 hShippingNameBy.Border = 0;
//                 hShippingNameBy.HorizontalAlignment = Element.ALIGN_LEFT;

//                 PdfPCell hShippingAddress = new PdfPCell(new Phrase(InvModel.ShippingByAddress, font2));
//                 hShippingAddress.Border = 0;
//                 hShippingAddress.HorizontalAlignment = Element.ALIGN_LEFT;
//                 tblShippngAddress.AddCell(shipingAddressCell);
//                 tblShippngAddress.AddCell(hShippingNameBy);
//                 tblShippngAddress.AddCell(hShippingAddress);

//                 headertable.AddCell(tblBillingAddress);
//                 blankCell.Colspan = 0;
//                 headertable.AddCell(blankCell);
//                 headertable.AddCell(tblShippngAddress);

//                 blankCell.Colspan = 3;
//                 headertable.AddCell(blankCell);


//                 document.Open();
//                 document.Add(headertable);


//                 //document.Add(jpg);
//                 #endregion

//                 #region Body

//                 float[] specification = { 4, 40, 30, 7, 7, 7, 7, 7, 7, 7, 7, 9 };
//                 PdfPTable table = new PdfPTable(specification);
//                 table.WidthPercentage = 95f;
//                 //table.HorizontalAlignment = 1;
//                 //leave a gap before and after the table
//                 table.SpacingBefore = 5f;
//                 table.SpacingAfter = 10f;
//                 PdfPCell hSrNo = new PdfPCell(new Phrase("Sr.No.", font6));
//                 hSrNo.BorderWidthLeft = 0;
//                 // b1.BorderWidthLeft = 0;
//                 hSrNo.BorderWidthBottom = 0;
//                 hSrNo.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 hSrNo.HorizontalAlignment = Element.ALIGN_CENTER;
//                 table.AddCell(hSrNo);
//                 PdfPCell hProduct = new PdfPCell(new Phrase("Product", font1));
//                 hProduct.BorderWidthLeft = 0;
//                 hProduct.BorderWidthBottom = 0;
//                 hProduct.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 hProduct.HorizontalAlignment = Element.ALIGN_CENTER;
//                 table.AddCell(hProduct);

//                 PdfPCell bType = new PdfPCell(new Phrase("Type", font1));
//                 bType.BorderWidthLeft = 0;
//                 bType.BorderWidthBottom = 0;
//                 bType.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 bType.HorizontalAlignment = Element.ALIGN_CENTER;
//                 table.AddCell(bType);

//                 PdfPCell GrainType = new PdfPCell(new Phrase("GrainType", font1));
//                GrainType.BorderWidthLeft = 0;
//                GrainType.BorderWidthBottom = 0;
//                GrainType.VerticalAlignment = Element.ALIGN_MIDDLE;
//                GrainType.HorizontalAlignment = Element.ALIGN_CENTER;
//                 table.AddCell(GrainType);

//                 PdfPCell hMRP = new PdfPCell(new Phrase("MRP", font1));
//                 hMRP.BorderWidthLeft = 0;
//                 hMRP.BorderWidthBottom = 0;
//                 hMRP.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 hMRP.HorizontalAlignment = Element.ALIGN_CENTER;
//                 table.AddCell(hMRP);

//                 PdfPCell OfferPrice = new PdfPCell(new Phrase("OfferPrice", font1));
//                 OfferPrice.BorderWidthLeft = 0;
//                 OfferPrice.BorderWidthBottom = 0;
//                 OfferPrice.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 OfferPrice.HorizontalAlignment = Element.ALIGN_CENTER;
//                 table.AddCell(OfferPrice);

//                 PdfPCell hQty = new PdfPCell(new Phrase("Qty", font1));
//                 hQty.BorderWidthLeft = 0;
//                 hQty.BorderWidthBottom = 0;
//                 hQty.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 hQty.HorizontalAlignment = Element.ALIGN_CENTER;
//                 table.AddCell(hQty);

//                 // PdfPCell hofferQuantity = new PdfPCell(new Phrase("FreeQty", font1));
//                 // hofferQuantity.BorderWidthLeft = 0;
//                 // hofferQuantity.BorderWidthBottom = 0;
//                 // hofferQuantity.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 // hofferQuantity.HorizontalAlignment = Element.ALIGN_CENTER;
//                 // table.AddCell(hofferQuantity);


//                 // PdfPCell hAmount = new PdfPCell(new Phrase("Amount", font1));
//                 // hAmount.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 // hAmount.HorizontalAlignment = Element.ALIGN_CENTER;
//                 //               table.AddCell(hAmount);
//                 PdfPCell hSGST = new PdfPCell(new Phrase("SGST", font6));
//                 hSGST.BorderWidthLeft = 0;
//                 hSGST.BorderWidthBottom = 0;
//                 hSGST.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 hSGST.HorizontalAlignment = Element.ALIGN_CENTER;
//                 table.AddCell(hSGST);
                
//                 PdfPCell hGST = new PdfPCell(new Phrase("GST", font6));
//                 hGST.BorderWidthLeft = 0;
//                 hGST.BorderWidthBottom = 0;
//                 hGST.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 hGST.HorizontalAlignment = Element.ALIGN_CENTER;
//                 table.AddCell(hGST);
//                 // PdfPCell hIGST = new PdfPCell(new Phrase("IGST", font6));
//                 // hIGST.BorderWidthLeft = 0;
//                 // hIGST.BorderWidthBottom = 0;
//                 // hIGST.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 // hIGST.HorizontalAlignment = Element.ALIGN_CENTER;
//                 // table.AddCell(hIGST);

//                 PdfPCell hNetAmount = new PdfPCell(new Phrase("Total", font1));
//                 hNetAmount.BorderWidthLeft = 0;
//                 hNetAmount.BorderWidthBottom = 0;
//                 hNetAmount.BorderWidthRight = 0;
//                 hNetAmount.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 hNetAmount.HorizontalAlignment = Element.ALIGN_CENTER;
//                 table.AddCell(hNetAmount);

//                 PdfPCell venBlankCell = new PdfPCell(new Phrase());
//                 //  venBlankCell.BorderWidthRight = 1;
//                 venBlankCell.BorderWidthLeft = 0;
//                 venBlankCell.BorderWidthBottom = 0;
//                 venBlankCell.BorderWidthTop = 0;
//                 PdfPCell venBlankCell1 = new PdfPCell(new Phrase());
//                 venBlankCell1.BorderWidthRight = 0;
//                 venBlankCell1.BorderWidthLeft = 0;
//                 venBlankCell1.BorderWidthBottom = 0;
//                 venBlankCell1.BorderWidthTop = 0;


//                 var InvCount = InvModel.Detail.Count;
//                 invoiceDetail InvDetail = new invoiceDetail();
//                 for (int i = 0; i < InvCount; i++)
//                 {
//                     // calucuate total sale by emp
//                     // int totalSale = item.ProductSellList.Sum(a => a.Qty);
//                     //if (totalSale > 0)
//                     //{
//                     PdfPCell SrNo = new PdfPCell(new Phrase("" + (i + 1), font3));
//                     SrNo.BorderWidthLeft = 0;
//                     SrNo.BorderWidthBottom = 0;
//                     SrNo.HorizontalAlignment = Element.ALIGN_LEFT;
//                     SrNo.VerticalAlignment = Element.ALIGN_MIDDLE;
//                     //  SrNo.Rowspan = 2;
//                     table.AddCell(SrNo);

//                     PdfPCell b1 = new PdfPCell(new Phrase(InvModel.Detail[i].Product, font3));
//                     b1.HorizontalAlignment = Element.ALIGN_LEFT;
//                     b1.VerticalAlignment = Element.ALIGN_MIDDLE;
//                     b1.BorderWidthLeft = 0;
//                     b1.BorderWidthBottom = 0;
//                     table.AddCell(b1);


//                     PdfPCell Type = new PdfPCell(new Phrase(InvModel.Detail[i].Type, font3));
//                     Type.HorizontalAlignment = Element.ALIGN_LEFT;
//                     Type.VerticalAlignment = Element.ALIGN_MIDDLE;
//                     Type.BorderWidthLeft = 0;
//                     Type.BorderWidthBottom = 0;
//                     table.AddCell(Type);

//                     PdfPCell GrainType = new PdfPCell(new Phrase(InvModel.Detail[i].GrainType), font1);
//                     //PdfPCell b2 = new PdfPCell(new Phrase(InvModel.Detail[i].Rate.ToString(), font5));
//                     GrainType.HorizontalAlignment = Element.ALIGN_RIGHT;
//                     GrainType.VerticalAlignment = Element.ALIGN_MIDDLE;
//                     GrainType.BorderWidthLeft = 0;
//                     GrainType.BorderWidthBottom = 0;
//                     //    b2.Rowspan = 2;
//                     table.AddCell(GrainType);

//                     PdfPCell b2 = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.Detail[i].MRP), font1));
//                     //PdfPCell b2 = new PdfPCell(new Phrase(InvModel.Detail[i].Rate.ToString(), font5));
//                     b2.HorizontalAlignment = Element.ALIGN_RIGHT;
//                     b2.VerticalAlignment = Element.ALIGN_MIDDLE;
//                     b2.BorderWidthLeft = 0;
//                     b2.BorderWidthBottom = 0;
//                     //    b2.Rowspan = 2;
//                     table.AddCell(b2);


//                     PdfPCell OfferPrice = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.Detail[i].OfferPrice), font1));
//                     //PdfPCell b2 = new PdfPCell(new Phrase(InvModel.Detail[i].Rate.ToString(), font5));
//                     OfferPrice.HorizontalAlignment = Element.ALIGN_RIGHT;
//                     OfferPrice.VerticalAlignment = Element.ALIGN_MIDDLE;
//                     OfferPrice.BorderWidthLeft = 0;
//                     OfferPrice.BorderWidthBottom = 0;
//                     //    b2.Rowspan = 2;
//                     table.AddCell(OfferPrice);
                    
//                     PdfPCell b3 = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.Detail[i].Quantity), font5));
//                     b3.HorizontalAlignment = Element.ALIGN_RIGHT;
//                     b3.VerticalAlignment = Element.ALIGN_MIDDLE;
//                     b3.BorderWidthLeft = 0;
//                     b3.BorderWidthBottom = 0;
//                     //    b3.Rowspan = 2;
//                     table.AddCell(b3);

//                     // PdfPCell b4 = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.Detail[i].OfferQuantity), font5));
//                     // b4.HorizontalAlignment = Element.ALIGN_RIGHT;
//                     // b4.VerticalAlignment = Element.ALIGN_MIDDLE;
//                     // b4.BorderWidthLeft = 0;
//                     // b4.BorderWidthBottom = 0;
//                     // //      b4.Rowspan = 2;
//                     // table.AddCell(b4);

//                     //PdfPCell acc = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.Detail[i].Amount), font5));
//                     //acc.HorizontalAlignment = Element.ALIGN_RIGHT;
//                     //acc.VerticalAlignment = Element.ALIGN_MIDDLE;
//                     //acc.BorderWidthLeft = 0;
//                     //acc.BorderWidthBottom = 0;
//                     ////      b4.Rowspan = 2;
//                     //table.AddCell(acc);


//                     PdfPCell sgstCell = new PdfPCell(new Phrase(InvModel.Detail[i].SGST.ToString(), font5));
//                     sgstCell.HorizontalAlignment = Element.ALIGN_RIGHT;
//                     sgstCell.VerticalAlignment = Element.ALIGN_MIDDLE;
//                     sgstCell.BorderWidthLeft = 0;
//                     sgstCell.BorderWidthBottom = 0;
//                     //    sgstCell.Rowspan = 2;
//                     table.AddCell(sgstCell);

//                     PdfPCell gstCell = new PdfPCell(new Phrase(InvModel.Detail[i].GST.ToString(), font5));
//                     gstCell.HorizontalAlignment = Element.ALIGN_RIGHT;
//                     gstCell.VerticalAlignment = Element.ALIGN_MIDDLE;
//                     gstCell.BorderWidthLeft = 0;
//                     gstCell.BorderWidthBottom = 0;
//                     //    cgstCell.Rowspan = 2;
//                     table.AddCell(gstCell);
                   
//                     // PdfPCell igstCell = new PdfPCell(new Phrase(InvModel.Detail[i].IGST.ToString(), font5));
//                     // igstCell.HorizontalAlignment = Element.ALIGN_RIGHT;
//                     // igstCell.VerticalAlignment = Element.ALIGN_MIDDLE;
//                     // igstCell.BorderWidthLeft = 0;
//                     // igstCell.BorderWidthBottom = 0;
//                     // //   igstCell.Rowspan = 2;
//                     // table.AddCell(igstCell);
                   
//                     PdfPCell NetAmtCell = new PdfPCell(new Phrase(String.Format("{0:0}", InvModel.Detail[i].Total), font5));
//                     NetAmtCell.BorderWidthRight = 0;
//                     NetAmtCell.HorizontalAlignment = Element.ALIGN_RIGHT;
//                     NetAmtCell.VerticalAlignment = Element.ALIGN_MIDDLE;
//                     NetAmtCell.BorderWidthLeft = 0;
//                     NetAmtCell.BorderWidthBottom = 0;
//                     //    NetAmtCell.Rowspan = 2;
//                     table.AddCell(NetAmtCell);

//                     table.AddCell(venBlankCell);


//                     PdfPCell VendorName = new PdfPCell(new Phrase("Seller: " + InvModel.Detail[i].VendorName + " ,GST :" + InvModel.Detail[i].VendorGSTNo, font7));
//                     VendorName.HorizontalAlignment = Element.ALIGN_LEFT;
//                     VendorName.VerticalAlignment = Element.ALIGN_MIDDLE;
//                     VendorName.BorderWidthLeft = 0;
//                     VendorName.BorderWidthBottom = 0;
//                     // VendorName.BorderWidthRight = 0;
//                     VendorName.BorderWidthTop = 0;
//                     //  table.AddCell(VendorName);



//                     table.AddCell(VendorName);
//                     table.AddCell(venBlankCell);
//                     table.AddCell(venBlankCell);
//                     table.AddCell(venBlankCell);
//                     table.AddCell(venBlankCell);
//                     table.AddCell(venBlankCell);
//                     table.AddCell(venBlankCell);
//                     table.AddCell(venBlankCell);
//                     table.AddCell(venBlankCell);
//                     table.AddCell(venBlankCell);
//                     // table.AddCell(venBlankCell);
//                     table.AddCell(venBlankCell1);


//                 }




//                 PdfPCell blankCellwithBorder = new PdfPCell(new Phrase());
//                 PdfPCell singleblankCell = new PdfPCell(new Phrase());
//                 //      bTOTAL.BorderWidthRight = 0;
//                 singleblankCell.BorderWidthLeft = 0;
//                 singleblankCell.Border = 0;
//                 singleblankCell.Colspan = 7;
//                 PdfPCell bTOTAL = new PdfPCell(new Phrase("TOTAL :", font1));
//                 bTOTAL.BorderWidthBottom = 1;
//                 bTOTAL.BorderWidthRight = 0;
//                 bTOTAL.BorderWidthLeft = 0;
//                 bTOTAL.HorizontalAlignment = Element.ALIGN_LEFT;
//                 bTOTAL.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 bTOTAL.Colspan = 8;
//                 //  table.AddCell(bTOTAL);

//                 PdfPCell b11 = new PdfPCell(new Phrase(String.Format("{0:0}", +Math.Ceiling(InvModel.TotalAmount.Value)), font1));
//                 b11.HorizontalAlignment = Element.ALIGN_RIGHT;
//                 b11.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 PdfPCell b12 = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.TotalGST), font1));
//                 b12.BorderWidthLeft = 0;
//                 b12.BorderWidthBottom = 0;
//                 b12.BorderWidthRight = 0;

//                 b12.HorizontalAlignment = Element.ALIGN_RIGHT;
//                 b12.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 PdfPCell b13 = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.TotalNetAmount), font1));
//                 b13.BorderWidthRight = 0;
//                 b13.BorderWidthLeft = 0;
//                 b13.BorderWidthBottom = 1;
//                 b13.HorizontalAlignment = Element.ALIGN_RIGHT;
//                 b13.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 //  table.AddCell(b13);


//                 //    table.AddCell(b11);
//                 blankCellwithBorder.Colspan = 2;
//                 blankCellwithBorder.BorderWidthRight = 0;
//                 // table.AddCell(singleblankCell);
//                 //   table.AddCell(b12);
//                 // table.AddCell(b13);

//                 // table.AddCell(blankCell);
//                 //table.AddCell(blankCell);
//                 PdfPCell line = new PdfPCell();
//                 line.HorizontalAlignment = Element.ALIGN_RIGHT;
//                 line.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 line.BorderWidthLeft = 0;
//                 line.BorderWidthBottom = 0;
//                 line.BorderWidthRight = 0;
//                 line.BorderWidthTop = 1;
//                 line.Colspan = 12;
//                 table.AddCell(line);
//                 table.AddCell(blankCell);
//                 PdfPCell Total = new PdfPCell(new Phrase("Total :", font3));
//                 //  Total.Border = 0;
//                 Total.BorderWidthLeft = 0;
//                 Total.BorderWidthBottom = 0;
//                 Total.BorderWidthRight = 0;
//                 Total.BorderWidthTop = 0;
//                 Total.HorizontalAlignment = Element.ALIGN_RIGHT;
//                 Total.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 Total.Colspan = 7;

//                 table.AddCell(Total);

//                 PdfPCell TotalAmt = new PdfPCell(new Phrase(String.Format("{0:0}", +Math.Ceiling(InvModel.TotalNetAmount.Value) + " /-"), font1));
//                 TotalAmt.Border = 0;
//                 TotalAmt.HorizontalAlignment = Element.ALIGN_RIGHT;
//                 TotalAmt.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 TotalAmt.Colspan = 3;
//                 TotalAmt.BorderWidthLeft = 0;
//                 TotalAmt.BorderWidthBottom = 0;

//                 table.AddCell(TotalAmt);
//                 table.AddCell(blankCell);
//                 PdfPCell bDeliveryCharge = new PdfPCell(new Phrase("Delivery Charges :", font3));
//                 bDeliveryCharge.Border = 0;
//                 bDeliveryCharge.HorizontalAlignment = Element.ALIGN_RIGHT;
//                 bDeliveryCharge.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 bDeliveryCharge.Colspan = 7;
//                 table.AddCell(bDeliveryCharge);

//                 PdfPCell ShipCharge = new PdfPCell(new Phrase(String.Format("{0:0}", +Math.Ceiling(InvModel.TotalShippingCharge.Value) + " /-"), font1));
//                 ShipCharge.Border = 0;
//                 ShipCharge.HorizontalAlignment = Element.ALIGN_RIGHT;
//                 ShipCharge.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 ShipCharge.Colspan = 3;
//                 table.AddCell(ShipCharge);
//                 //   table.AddCell(blankCell);
//                 // if (InvModel.COD > 0)
//                 // {
//                 //     table.AddCell(blankCell);
//                 //     PdfPCell bCODCharge = new PdfPCell(new Phrase("COD Charges :", font3));
//                 //     bCODCharge.Border = 0;
//                 //     bCODCharge.HorizontalAlignment = Element.ALIGN_RIGHT;
//                 //     bCODCharge.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 //     bCODCharge.Colspan = 7;
//                 //     table.AddCell(bCODCharge);

//                 //     PdfPCell CODCharge = new PdfPCell(new Phrase(String.Format("{0:0}", +Math.Ceiling(InvModel.COD.Value) + " /-"), font1));
//                 //     CODCharge.Border = 0;
//                 //     CODCharge.HorizontalAlignment = Element.ALIGN_RIGHT;
//                 //     CODCharge.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 //     CODCharge.Colspan = 3;

//                 //     table.AddCell(CODCharge);
//                 //     // table.AddCell(blankCell);

//                 // }
//                 // table.AddCell(blankCell);
                
//                 PdfPCell bTotalPrice = new PdfPCell(new Phrase("Total Amount :", font1));
//                 // bTotalPrice.BorderWidthLeft = 0;
//                 // bTotalPrice.BorderWidthBottom = 0;
//                 //  bTotalPrice.BorderWidthRight = 0;
//                 bTotalPrice.Border = 0;
//                 bTotalPrice.HorizontalAlignment = Element.ALIGN_RIGHT;
//                 bTotalPrice.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 bTotalPrice.Colspan = 7;
//                 table.AddCell(bTotalPrice);

//                 decimal dfinal = Math.Ceiling(InvModel.TotalNetAmount.Value + InvModel.TotalShippingCharge.Value + InvModel.COD.Value);
//                 ///   PdfPCell finalTotalPrice = new PdfPCell(new Phrase(String.Format("{0:0}", +Math.Ceiling(Convert.ToDecimal(final)) + " /-"), font1));
//                 PdfPCell finalTotalPrice = new PdfPCell(new Phrase(String.Format("{0:0}", dfinal.ToString() + " /-"), font1));
//                 finalTotalPrice.Border = 0;
//                 finalTotalPrice.HorizontalAlignment = Element.ALIGN_RIGHT;
//                 finalTotalPrice.VerticalAlignment = Element.ALIGN_MIDDLE;
//                 finalTotalPrice.Colspan = 3;

//                 table.AddCell(finalTotalPrice);


//                 //if (document.IsOpen() == false)
//                 //{
//                 //    document.Open();
//                 //}
//                 document.Add(table);

//                 writer.PageEvent = new PDFFooter();

//                 #endregion
//                 newfilepath = returnFilePath;
//             }
//             catch (Exception ex)
//             {
//                 throw ex;
//             }
//             finally
//             {
//                 document.Close();
//             }






//             try
//             {
//                 byte[] bytes = File.ReadAllBytes(Path.Combine(folderPath, name + ".pdf"));
//                 Font blackFont = FontFactory.GetFont("Arial", 12, Font.NORMAL, BaseColor.BLACK);
//                 using (MemoryStream stream = new MemoryStream())
//                 {
//                     PdfReader reader = new PdfReader(bytes);
//                     using (PdfStamper stamper = new PdfStamper(reader, stream))
//                     {
//                         int pages = reader.NumberOfPages;
//                         for (int i = 1; i <= pages; i++)
//                         {
//                             // ColumnText.ShowTextAligned(stamper.GetUnderContent(i), Element.ALIGN_RIGHT, new Phrase(i.ToString(), blackFont), 568f, 15f, 0);
//                         }
//                     }
//                     bytes = stream.ToArray();
//                 }
//                 File.WriteAllBytes(Path.Combine(folderPath, name + ".pdf"), bytes);
//             }
//             catch (Exception ex)
//             {
//                 throw ex;
//             }
//             return newfilepath;

//         }

//     //     public static string GenerateVendorPDF(string serverpath, string UserId, InvoiceModel InvModel, string logoPath)
//     //     {
//     //         string newfilepath = "";

//     //         string folderPath = Path.Combine(serverpath, UserId);

//     //         ResponseModel res = new ResponseModel();
//     //         MemoryStream memoryStream = new MemoryStream();
//     //         Document document = new Document(PageSize.A5.Rotate(), 0f, 0f, 10f, 10f);
//     //         ///  document.SetMargins(0f,0f,0f,0f);
//     //         /// document.GetLeft(0f);
//     //         // document.SetPageSize(iTextSharp.text.PageSize.A5);
//     //         if (!System.IO.Directory.Exists(folderPath))
//     //         {
//     //             System.IO.Directory.CreateDirectory(folderPath);
//     //         }

//     //         string[] filePaths = Directory.GetFiles(folderPath);
//     //         for (int i = 0; i < filePaths.Length; i++)
//     //         {
//     //             // System.IO.Directory.Delete(filePaths[i]);
//     //         }


//     //         Random rand = new Random();

//     //         string name = rand.Next(1000, 9000).ToString();

//     //         string filename = Path.Combine(folderPath, name + ".pdf");
//     //         string returnFilePath = Path.Combine(UserId, name + ".pdf");
//     //         FileStream fs = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None);
//     //         try
//     //         {
//     //             PdfWriter writer = PdfWriter.GetInstance(document, fs);

//     //             Font font1 = new Font(Font.FontFamily.TIMES_ROMAN, 9, Font.BOLD);
//     //             Font font2 = new Font(Font.FontFamily.TIMES_ROMAN, 9);
//     //             Font font3 = new Font(Font.FontFamily.TIMES_ROMAN, 9);
//     //             Font font4 = new Font(Font.FontFamily.TIMES_ROMAN, 9, Font.BOLD, BaseColor.BLACK);
//     //             Font font5 = new Font(Font.FontFamily.TIMES_ROMAN, 9);
//     //             Font font6 = new Font(Font.FontFamily.TIMES_ROMAN, 7, Font.BOLD);

//     //             #region Header

//     //             float[] headercolumnSpecification = { 100f, 15f, 100f };
//     //             PdfPTable headertable = new PdfPTable(headercolumnSpecification);
//     //             headertable.WidthPercentage = 95f;

//     //             //string imageFilePath = "http://demo.knackbe.xyz/assets/images/ayurveda1.jpg";
//     //             //iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageFilePath);
//     //             //jpg.ScaleToFit(375, 700);
//     //             //jpg.Alignment = iTextSharp.text.Image.UNDERLYING;
//     //             //jpg.SetAbsolutePosition(100, 400);

//     //             headertable.DefaultCell.Border = 0;

//     //             PdfPCell blankCell = new PdfPCell(new Phrase());
//     //             blankCell.Border = 0;
//     //             //string imageURL = serverpath + "\\logo.png";
//     //             //    string imageURL = logoPath;
//     //             iTextSharp.text.Image jpeg = iTextSharp.text.Image.GetInstance(logoPath);
//     //             jpeg.ScaleToFit(125f, 100f);

//     //             PdfPCell Headerlogo = new PdfPCell(jpeg);
//     //             Headerlogo.Border = 0;
//     //             Headerlogo.HorizontalAlignment = Element.ALIGN_LEFT;

//     //             //PdfPCell headerc2 = new PdfPCell(new Phrase("Reg no 898828836777", font1));
//     //             //headerc2.Border = 0;
//     //             //headerc2.HorizontalAlignment = Element.ALIGN_RIGHT;


//     //             PdfPCell headerc5 = new PdfPCell(new Phrase("INVOICE", font1));
//     //             headerc5.Colspan = 3;
//     //             headerc5.Border = 0;
//     //             headerc5.HorizontalAlignment = Element.ALIGN_CENTER;

//     //             PdfPTable tblSoldBy = new PdfPTable(1);
//     //             tblSoldBy.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //             //tblSoldBy.SpacingBefore = 5f;
//     //             //tblSoldBy.SpacingAfter = 5f;
//     //             tblSoldBy.SpacingBefore = 0f;
//     //             tblSoldBy.SpacingAfter = 0f;
//     //             PdfPCell SoldByCell = new PdfPCell(new Phrase("Sold By:  "
//     //             , font1));
//     //             SoldByCell.Border = 0;
//     //             SoldByCell.HorizontalAlignment = Element.ALIGN_LEFT;

//     //             PdfPCell hSoldBy = new PdfPCell(new Phrase(InvModel.soldByName, font3));
//     //             hSoldBy.Border = 0;
//     //             hSoldBy.HorizontalAlignment = Element.ALIGN_LEFT;

//     //             PdfPCell hSoldAddress = new PdfPCell(new Phrase(InvModel.soldByAddress, font2));
//     //             hSoldAddress.Border = 0;
//     //             hSoldAddress.HorizontalAlignment = Element.ALIGN_LEFT;

//     //             PdfPCell hPANNo = new PdfPCell(new Phrase(
//     //                 "PAN No.: " + InvModel.soldByPanNo
//     //                 , font1));
//     //             hPANNo.Border = 0;
//     //             hPANNo.HorizontalAlignment = Element.ALIGN_LEFT;

//     //             PdfPCell hGST = new PdfPCell(new Phrase(
//     //                 "GST No.: " + InvModel.soldByGstNo
//     //                 , font1));
//     //             hGST.Border = 0;
//     //             hGST.HorizontalAlignment = Element.ALIGN_LEFT;
//     //             tblSoldBy.AddCell(SoldByCell);
//     //             tblSoldBy.AddCell(hSoldBy);
//     //             tblSoldBy.AddCell(hSoldAddress);
//     //             tblSoldBy.AddCell(hPANNo);
//     //             tblSoldBy.AddCell(hGST);

//     //             //tblSoldBy.AddCell(SoldByCell);
//     //             //tblSoldBy.AddCell(hSoldBy);
//     //             //tblSoldBy.AddCell(hSoldAddress);

//     //             headerc5.HorizontalAlignment = Element.ALIGN_CENTER;
//     //             //headertable.AddCell(blankCell);
//     //             //for (int i = 0; i < 3; i++) { headertable.AddCell(headerc6); }
//     //             headertable.AddCell(headerc5);

//     //             //headertable.AddCell(blankCell);
//     //             // headertable.AddCell(blankCell);
//     //             //headertable.AddCell(blankCell);
//     //             //headertable.AddCell(headerc2);
//     //             headertable.AddCell(Headerlogo);
//     //             headertable.AddCell(blankCell);
//     //             headertable.AddCell(tblSoldBy);
//     //             blankCell.Colspan = 3;
//     //             headertable.AddCell(blankCell);

//     //             PdfPCell headerc6 = new PdfPCell(new Phrase());
//     //             headerc6.UseVariableBorders = false;
//     //             headerc6.BorderColorBottom = BaseColor.BLACK;
//     //             headerc6.BorderWidthBottom = 1f;
//     //             //headerc5.HorizontalAlignment = Element.ALIGN_CENTER;

//     //             headerc6.Colspan = 3;
//     //             headertable.AddCell(headerc6);
//     //             headertable.AddCell(blankCell);

//     //             PdfPTable tblBillingAddress = new PdfPTable(1);
//     //             tblBillingAddress.SpacingBefore = 5f;
//     //             tblBillingAddress.SpacingAfter = 5f;
//     //             //  tblBillingAddress.SpacingBefore = 0f;
//     //             //  tblBillingAddress.SpacingAfter = 0f;
//     //             PdfPCell billingAddressCell = new PdfPCell(new Phrase("Billing Address:  "
//     //             , font1));
//     //             billingAddressCell.Border = 0;
//     //             billingAddressCell.HorizontalAlignment = Element.ALIGN_LEFT;

//     //             PdfPCell hBillNameBy = new PdfPCell(new Phrase(InvModel.BillingByName, font3));
//     //             hBillNameBy.Border = 0;
//     //             hBillNameBy.HorizontalAlignment = Element.ALIGN_LEFT;

//     //             PdfPCell hBillingAddress = new PdfPCell(new Phrase(InvModel.BillingByAddress, font2));
//     //             hBillingAddress.Border = 0;
//     //             hBillingAddress.HorizontalAlignment = Element.ALIGN_LEFT;
//     //             tblBillingAddress.AddCell(billingAddressCell);
//     //             tblBillingAddress.AddCell(hBillNameBy);
//     //             tblBillingAddress.AddCell(hBillingAddress);


//     //             PdfPTable tblShippngAddress = new PdfPTable(1);
//     //             tblBillingAddress.SpacingBefore = 5f;
//     //             tblBillingAddress.SpacingAfter = 5f;
//     //             //  tblBillingAddress.SpacingBefore = 5f;
//     //             //  tblBillingAddress.SpacingAfter = 5f;
//     //             PdfPCell shipingAddressCell = new PdfPCell(new Phrase("Shipping Address:  "
//     //             , font1));
//     //             shipingAddressCell.Border = 0;
//     //             shipingAddressCell.HorizontalAlignment = Element.ALIGN_LEFT;

//     //             PdfPCell hShippingNameBy = new PdfPCell(new Phrase(InvModel.ShippingByName, font3));
//     //             hShippingNameBy.Border = 0;
//     //             hShippingNameBy.HorizontalAlignment = Element.ALIGN_LEFT;

//     //             PdfPCell hShippingAddress = new PdfPCell(new Phrase(InvModel.ShippingByAddress, font2));
//     //             hShippingAddress.Border = 0;
//     //             hShippingAddress.HorizontalAlignment = Element.ALIGN_LEFT;
//     //             tblShippngAddress.AddCell(shipingAddressCell);
//     //             tblShippngAddress.AddCell(hShippingNameBy);
//     //             tblShippngAddress.AddCell(hShippingAddress);

//     //             headertable.AddCell(tblBillingAddress);
//     //             blankCell.Colspan = 0;
//     //             headertable.AddCell(blankCell);
//     //             headertable.AddCell(tblShippngAddress);

//     //             blankCell.Colspan = 3;
//     //             headertable.AddCell(blankCell);

//     //             PdfPTable tblInvoiceDetail = new PdfPTable(1);
//     //             tblInvoiceDetail.SpacingBefore = 5f;
//     //             //   tblInvoiceDetail.SpacingBefore = 5f;
//     //             tblInvoiceDetail.SpacingAfter = 5f;
//     //             //   tblInvoiceDetail.SpacingAfter = 5f;
//     //             PdfPCell InvoiceNoCell = new PdfPCell(new Phrase("Invoice No.:  " + InvModel.InvoiceNumber
//     //             , font1));
//     //             InvoiceNoCell.Border = 0;
//     //             InvoiceNoCell.HorizontalAlignment = Element.ALIGN_LEFT;

//     //             PdfPCell InvoiceDateCell = new PdfPCell(new Phrase("Invoice Date :  " + InvModel.InvoiceDate, font1));
//     //             InvoiceDateCell.Border = 0;
//     //             InvoiceDateCell.HorizontalAlignment = Element.ALIGN_LEFT;

//     //             tblInvoiceDetail.AddCell(InvoiceNoCell);
//     //             tblInvoiceDetail.AddCell(InvoiceDateCell);


//     //             PdfPTable tblOrderDetail = new PdfPTable(1);
//     //             tblOrderDetail.SpacingBefore = 5f;
//     //             //  tblOrderDetail.SpacingBefore = 0f;
//     //             tblOrderDetail.SpacingAfter = 5f;
//     //             //    tblOrderDetail.SpacingAfter = 0f;
//     //             PdfPCell OrderIdCell = new PdfPCell(new Phrase("Order Id : " + InvModel.OrderId
//     //             , font1));
//     //             OrderIdCell.Border = 0;
//     //             OrderIdCell.HorizontalAlignment = Element.ALIGN_LEFT;
//     //             tblOrderDetail.AddCell(OrderIdCell);

//     //             headertable.AddCell(tblOrderDetail);
//     //             blankCell.Colspan = 0;
//     //             headertable.AddCell(blankCell);
//     //             headertable.AddCell(tblInvoiceDetail);

//     //             blankCell.Colspan = 3;
//     //             headertable.AddCell(blankCell);
//     //             document.Open();
//     //             document.Add(headertable);
//     //             //document.Add(jpg);
//     //             #endregion

//     //             #region Body
//     //             float[] specification = { 4, 40, 30, 9, 7, 5, 5, 5, 5, 5, 5, 8 };
//     //             // float[] specification = { 5, 38, 9, 5, 5, 5, 5, 5, 9 };
//     //             PdfPTable table = new PdfPTable(specification);
//     //             table.WidthPercentage = 95f;
//     //             //table.HorizontalAlignment = 1;
//     //             //leave a gap before and after the table
//     //             table.SpacingBefore = 5f;
//     //             table.SpacingAfter = 10f;
//     //             PdfPCell hSrNo = new PdfPCell(new Phrase("Sr.No.", font6));
//     //             hSrNo.BorderWidthLeft = 0;
//     //             // b1.BorderWidthLeft = 0;
//     //             hSrNo.BorderWidthBottom = 0;
//     //             hSrNo.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             hSrNo.HorizontalAlignment = Element.ALIGN_CENTER;
//     //             table.AddCell(hSrNo);
//     //             PdfPCell hProduct = new PdfPCell(new Phrase("Product", font1));
//     //             hProduct.BorderWidthLeft = 0;
//     //             hProduct.BorderWidthBottom = 0;
//     //             hProduct.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             hProduct.HorizontalAlignment = Element.ALIGN_CENTER;
//     //             table.AddCell(hProduct);


//     //             PdfPCell hBrand = new PdfPCell(new Phrase("Brand", font1));
//     //             hBrand.BorderWidthLeft = 0;
//     //             hBrand.BorderWidthBottom = 0;
//     //             hBrand.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             hBrand.HorizontalAlignment = Element.ALIGN_CENTER;
//     //             table.AddCell(hBrand);

//     //             PdfPCell hMRP = new PdfPCell(new Phrase("MRP", font1));
//     //             hMRP.BorderWidthLeft = 0;
//     //             hMRP.BorderWidthBottom = 0;
//     //             hMRP.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             hMRP.HorizontalAlignment = Element.ALIGN_CENTER;
//     //             table.AddCell(hMRP);

//     //             PdfPCell hRate = new PdfPCell(new Phrase("Rate", font1));
//     //             hRate.BorderWidthLeft = 0;
//     //             hRate.BorderWidthBottom = 0;
//     //             hRate.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             hRate.HorizontalAlignment = Element.ALIGN_CENTER;
//     //             table.AddCell(hRate);

//     //             PdfPCell hDiscount = new PdfPCell(new Phrase("Dis(%)", font1));
//     //             hDiscount.BorderWidthLeft = 0;
//     //             hDiscount.BorderWidthBottom = 0;
//     //             hDiscount.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             hDiscount.HorizontalAlignment = Element.ALIGN_CENTER;
//     //             table.AddCell(hDiscount);

//     //             PdfPCell hQuantity = new PdfPCell(new Phrase("Qty", font1));
//     //             hQuantity.BorderWidthLeft = 0;
//     //             hQuantity.BorderWidthBottom = 0;
//     //             hQuantity.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             hQuantity.HorizontalAlignment = Element.ALIGN_CENTER;
//     //             table.AddCell(hQuantity);

//     //             PdfPCell hofferQuantity = new PdfPCell(new Phrase("freeQty", font1));
//     //             hofferQuantity.BorderWidthLeft = 0;
//     //             hofferQuantity.BorderWidthBottom = 0;
//     //             hofferQuantity.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             hofferQuantity.HorizontalAlignment = Element.ALIGN_CENTER;
//     //             table.AddCell(hofferQuantity);


//     //             PdfPCell hAmount = new PdfPCell(new Phrase("Amount", font1));
//     //             hAmount.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             hAmount.HorizontalAlignment = Element.ALIGN_CENTER;
//     //             //               table.AddCell(hAmount);
//     //             PdfPCell hSGST = new PdfPCell(new Phrase("SGST", font6));
//     //             hSGST.BorderWidthLeft = 0;
//     //             hSGST.BorderWidthBottom = 0;
//     //             hSGST.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             hSGST.HorizontalAlignment = Element.ALIGN_CENTER;
//     //             table.AddCell(hSGST);
//     //             PdfPCell hCGST = new PdfPCell(new Phrase("CGST", font6));
//     //             hCGST.BorderWidthLeft = 0;
//     //             hCGST.BorderWidthBottom = 0;
//     //             hCGST.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             hCGST.HorizontalAlignment = Element.ALIGN_CENTER;
//     //             table.AddCell(hCGST);
//     //             PdfPCell hIGST = new PdfPCell(new Phrase("IGST", font6));
//     //             hIGST.BorderWidthLeft = 0;
//     //             hIGST.BorderWidthBottom = 0;
//     //             hIGST.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             hIGST.HorizontalAlignment = Element.ALIGN_CENTER;
//     //             table.AddCell(hIGST);
//     //             PdfPCell hNetAmount = new PdfPCell(new Phrase("Total", font1));
//     //             hNetAmount.BorderWidthLeft = 0;
//     //             hNetAmount.BorderWidthBottom = 0;
//     //             hNetAmount.BorderWidthRight = 0;
//     //             hNetAmount.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             hNetAmount.HorizontalAlignment = Element.ALIGN_CENTER;
//     //             table.AddCell(hNetAmount);
//     //             var InvCount = InvModel.Detail.Count;
//     //             invoiceDetail InvDetail = new invoiceDetail();
//     //             for (int i = 0; i < InvCount; i++)
//     //             {
//     //                 // calucuate total sale by emp
//     //                 // int totalSale = item.ProductSellList.Sum(a => a.Qty);
//     //                 //if (totalSale > 0)
//     //                 //{
//     //                 PdfPCell SrNo = new PdfPCell(new Phrase("" + (i + 1), font3));
//     //                 SrNo.BorderWidthLeft = 0;
//     //                 SrNo.BorderWidthBottom = 0;
//     //                 SrNo.HorizontalAlignment = Element.ALIGN_LEFT;
//     //                 SrNo.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //                 table.AddCell(SrNo);

//     //                 PdfPCell b1 = new PdfPCell(new Phrase(InvModel.Detail[i].ProductName, font3));
//     //                 b1.HorizontalAlignment = Element.ALIGN_LEFT;
//     //                 b1.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //                 b1.BorderWidthLeft = 0;
//     //                 b1.BorderWidthBottom = 0;
//     //                 table.AddCell(b1);


//     //                 PdfPCell brand1 = new PdfPCell(new Phrase(InvModel.Detail[i].BrandName, font3));
//     //                 brand1.HorizontalAlignment = Element.ALIGN_LEFT;
//     //                 brand1.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //                 brand1.BorderWidthLeft = 0;
//     //                 brand1.BorderWidthBottom = 0;
//     //                 table.AddCell(brand1);

//     //                 PdfPCell MRP1 = new PdfPCell(new Phrase(InvModel.Detail[i].MRP.ToString(), font3));
//     //                 MRP1.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //                 MRP1.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //                 MRP1.BorderWidthLeft = 0;
//     //                 MRP1.BorderWidthBottom = 0;
//     //                 table.AddCell(MRP1);

//     //                 PdfPCell b2 = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.Detail[i].Rate), font3));
//     //                 //PdfPCell b2 = new PdfPCell(new Phrase(InvModel.Detail[i].Rate.ToString(), font5));
//     //                 b2.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //                 b2.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //                 b2.BorderWidthLeft = 0;
//     //                 b2.BorderWidthBottom = 0;
//     //                 table.AddCell(b2);
//     //                 PdfPCell bdis = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.Detail[i].Discount), font3));
//     //                 //PdfPCell b2 = new PdfPCell(new Phrase(InvModel.Detail[i].Rate.ToString(), font5));
//     //                 bdis.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //                 bdis.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //                 bdis.BorderWidthLeft = 0;
//     //                 bdis.BorderWidthBottom = 0;
//     //                 table.AddCell(bdis);
//     //                 PdfPCell b3 = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.Detail[i].Quantity), font5));
//     //                 b3.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //                 b3.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //                 b3.BorderWidthLeft = 0;
//     //                 b3.BorderWidthBottom = 0;
//     //                 table.AddCell(b3);

//     //                 PdfPCell b4 = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.Detail[i].OfferQuantity), font5));
//     //                 b4.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //                 b4.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //                 b4.BorderWidthLeft = 0;
//     //                 b4.BorderWidthBottom = 0;
//     //                 table.AddCell(b4);
//     //                 PdfPCell sgstCell = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.Detail[i].SGST), font5));
//     //                 sgstCell.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //                 sgstCell.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //                 sgstCell.BorderWidthLeft = 0;
//     //                 sgstCell.BorderWidthBottom = 0;
//     //                 table.AddCell(sgstCell);

//     //                 PdfPCell cgstCell = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.Detail[i].CGST), font5));
//     //                 cgstCell.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //                 cgstCell.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //                 cgstCell.BorderWidthLeft = 0;
//     //                 cgstCell.BorderWidthBottom = 0;
//     //                 table.AddCell(cgstCell);
//     //                 PdfPCell igstCell = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.Detail[i].IGST), font5));

//     //                 igstCell.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //                 igstCell.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //                 igstCell.BorderWidthLeft = 0;
//     //                 igstCell.BorderWidthBottom = 0;
//     //                 table.AddCell(igstCell);
//     //                 PdfPCell NetAmtCell = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.Detail[i].NetAmount), font5));
//     //                 NetAmtCell.BorderWidthRight = 0;
//     //                 NetAmtCell.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //                 NetAmtCell.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //                 NetAmtCell.BorderWidthLeft = 0;
//     //                 NetAmtCell.BorderWidthBottom = 0;
//     //                 table.AddCell(NetAmtCell);
//     //             }
//     //             PdfPCell blankCellwithBorder = new PdfPCell(new Phrase());
//     //             PdfPCell singleblankCell = new PdfPCell(new Phrase());
//     //             //      bTOTAL.BorderWidthRight = 0;
//     //             singleblankCell.BorderWidthLeft = 0;
//     //             singleblankCell.Border = 0;
//     //             singleblankCell.Colspan = 12;
//     //             PdfPCell bTOTAL = new PdfPCell(new Phrase("TOTAL :", font1));
//     //             bTOTAL.BorderWidthBottom = 1;
//     //             bTOTAL.BorderWidthRight = 0;
//     //             bTOTAL.BorderWidthLeft = 0;
//     //             bTOTAL.HorizontalAlignment = Element.ALIGN_LEFT;
//     //             bTOTAL.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             bTOTAL.Colspan = 11;
//     //             table.AddCell(singleblankCell);
//     //             table.AddCell(bTOTAL);

//     //             PdfPCell b11 = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.TotalAmount), font1));
//     //             b11.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //             b11.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             PdfPCell b12 = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.TotalGST), font1));
//     //             b12.BorderWidthLeft = 0;
//     //             b12.BorderWidthBottom = 0;
//     //             b12.BorderWidthRight = 0;

//     //             b12.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //             b12.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             PdfPCell b13 = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.TotalNetAmount), font1));
//     //             b13.BorderWidthRight = 0;
//     //             b13.BorderWidthLeft = 0;
//     //             b13.BorderWidthBottom = 1;
//     //             b13.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //             b13.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             //  table.AddCell(b13);


//     //             //   table.AddCell(b11);
//     //             blankCellwithBorder.Colspan = 2;
//     //             blankCellwithBorder.BorderWidthRight = 0;
//     //             // table.AddCell(singleblankCell);
//     //             //   table.AddCell(b12);
//     //             table.AddCell(b13);

//     //             table.AddCell(blankCell);
//     //             //table.AddCell(blankCell);

//     //             PdfPCell Total = new PdfPCell(new Phrase("Total :", font1));
//     //             //  Total.Border = 0;
//     //             Total.BorderWidthLeft = 0;
//     //             Total.BorderWidthBottom = 0;
//     //             Total.BorderWidthRight = 0;
//     //             Total.BorderWidthTop = 0;
//     //             Total.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //             Total.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             Total.Colspan = 7;

//     //             table.AddCell(Total);

//     //             PdfPCell TotalAmt = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.TotalNetAmount + " /-"), font1));
//     //             TotalAmt.Border = 0;
//     //             TotalAmt.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //             TotalAmt.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             TotalAmt.Colspan = 3;
//     //             TotalAmt.BorderWidthLeft = 0;
//     //             TotalAmt.BorderWidthBottom = 0;

//     //             table.AddCell(TotalAmt);
//     //             table.AddCell(blankCell);
//     //             PdfPCell bShippingCharge = new PdfPCell(new Phrase("Shipping Charges :", font1));
//     //             bShippingCharge.Border = 0;
//     //             bShippingCharge.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //             bShippingCharge.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             bShippingCharge.Colspan = 7;
//     //             table.AddCell(bShippingCharge);

//     //             PdfPCell ShipCharge = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.TotalShippingCharge + " /-"), font1));
//     //             ShipCharge.Border = 0;
//     //             ShipCharge.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //             ShipCharge.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             ShipCharge.Colspan = 3;
//     //             table.AddCell(ShipCharge);
//     //             table.AddCell(blankCell);

//     //             PdfPCell bCODCharge = new PdfPCell(new Phrase("COD Charges :", font1));
//     //             bCODCharge.Border = 0;
//     //             bCODCharge.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //             bCODCharge.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             bCODCharge.Colspan = 7;
//     //             table.AddCell(bCODCharge);

//     //             PdfPCell CODCharge = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.COD + " /-"), font1));
//     //             CODCharge.Border = 0;
//     //             CODCharge.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //             CODCharge.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             CODCharge.Colspan = 3;
//     //             table.AddCell(CODCharge);
//     //             table.AddCell(blankCell);

//     //             PdfPCell _bCODCharge = new PdfPCell(new Phrase("Net Amount :", font1));
//     //             _bCODCharge.Border = 0;
//     //             _bCODCharge.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //             _bCODCharge.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             _bCODCharge.Colspan = 7;
//     //             table.AddCell(_bCODCharge);

//     //             PdfPCell _CODCharge = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.FinalPrice + " /-"), font1));
//     //             _CODCharge.Border = 0;
//     //             _CODCharge.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //             _CODCharge.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             _CODCharge.Colspan = 3;
//     //             table.AddCell(_CODCharge);
//     //             table.AddCell(blankCell);

//     //             //PdfPCell bTotalPrice = new PdfPCell(new Phrase("Net Amount :", font1));
//     //             //// bTotalPrice.BorderWidthLeft = 0;
//     //             //// bTotalPrice.BorderWidthBottom = 0;
//     //             ////  bTotalPrice.BorderWidthRight = 0;
//     //             //bTotalPrice.Border = 0;
//     //             //bTotalPrice.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //             //bTotalPrice.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             //bTotalPrice.Colspan = 7;
//     //             //table.AddCell(bTotalPrice);

//     //             //PdfPCell TotalPrice = new PdfPCell(new Phrase(String.Format("{0:0}", +InvModel.FinalPrice + " /-"), font1));
//     //             //TotalPrice.Border = 0;
//     //             //TotalPrice.HorizontalAlignment = Element.ALIGN_RIGHT;
//     //             //TotalPrice.VerticalAlignment = Element.ALIGN_MIDDLE;
//     //             //bTotalPrice.Colspan = 3;

//     //             //table.AddCell(TotalPrice);
//     //             table.AddCell(blankCell); table.AddCell(blankCell); table.AddCell(blankCell);
//     //             document.Add(table);

//     //             writer.PageEvent = new PDFFooter();

//     //             #endregion
//     //             newfilepath = returnFilePath;
//     //         }
//     //         catch (Exception ex)
//     //         {
//     //             throw ex;
//     //         }
//     //         finally
//     //         {
//     //             document.Close();
//     //         }






//     //         try
//     //         {
//     //             byte[] bytes = File.ReadAllBytes(Path.Combine(folderPath, name + ".pdf"));
//     //             Font blackFont = FontFactory.GetFont("Arial", 12, Font.NORMAL, BaseColor.BLACK);
//     //             using (MemoryStream stream = new MemoryStream())
//     //             {
//     //                 PdfReader reader = new PdfReader(bytes);
//     //                 using (PdfStamper stamper = new PdfStamper(reader, stream))
//     //                 {
//     //                     int pages = reader.NumberOfPages;
//     //                     for (int i = 1; i <= pages; i++)
//     //                     {
//     //                         ColumnText.ShowTextAligned(stamper.GetUnderContent(i), Element.ALIGN_RIGHT, new Phrase(i.ToString(), blackFont), 568f, 15f, 0);
//     //                     }
//     //                 }
//     //                 bytes = stream.ToArray();
//     //             }
//     //             File.WriteAllBytes(Path.Combine(folderPath, name + ".pdf"), bytes);
//     //         }
//     //         catch (Exception ex)
//     //         {
//     //             throw ex;
//     //         }
//     //         return newfilepath;

//     //     }
//     // }

//     public class PDFFooter : PdfPageEventHelper
//     {
//         // write on top of document
//         public override void OnOpenDocument(PdfWriter writer, Document document)
//         {
//             base.OnOpenDocument(writer, document);
//             PdfPTable tabFot = new PdfPTable(new float[] { 1F });
//             tabFot.SpacingAfter = 10F;
//             PdfPCell cell;
//             tabFot.TotalWidth = 300F;
//             cell = new PdfPCell(new Phrase(""));
//             cell.Border = Rectangle.NO_BORDER;
//             tabFot.AddCell(cell);
//             tabFot.WriteSelectedRows(0, -1, 150, document.Top, writer.DirectContent);
//         }

//         // write on start of each page
//         public override void OnStartPage(PdfWriter writer, Document document)
//         {
//             base.OnStartPage(writer, document);
//         }

//         // write on end of each page
//         public override void OnEndPage(PdfWriter writer, Document document)
//         {
//             DateTime horario = DateTime.Now;
//             base.OnEndPage(writer, document);
//             PdfPTable tabFot = new PdfPTable(new float[] { 1000F });
//             PdfPCell cell, cell1, cell2;
//             tabFot.TotalWidth = 328F;
//             tabFot.WidthPercentage = 95f;

//             PdfPCell headerc1 = new PdfPCell(new Phrase());
//             headerc1.UseVariableBorders = false;
//             headerc1.BorderColorTop = BaseColor.BLACK;
//             headerc1.BorderWidthBottom = 1f;
//             headerc1.HorizontalAlignment = Element.ALIGN_CENTER;

//             Font f = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.NORMAL, BaseColor.GRAY);

//             cell = new PdfPCell(new Phrase("FlourPicker:", f));
//             cell.Border = Rectangle.NO_BORDER;
//             cell.HorizontalAlignment = Element.ALIGN_CENTER;
//             cell1 = new PdfPCell(new Phrase(
//                 "Mayureshwar, Siddhivinayak Nagar, Goleshwar Road ,Karve nakka Karad 415110, Maharashtra, 415110,India "

//                 , f));
//             cell1.Border = Rectangle.NO_BORDER;
//             cell1.HorizontalAlignment = Element.ALIGN_CENTER;
//             cell2 = new PdfPCell(new Phrase("Page 1 Of", f));
//             cell2.Border = Rectangle.NO_BORDER;
//             cell2.HorizontalAlignment = Element.ALIGN_RIGHT;

//             String text = "Page " + writer.PageNumber + " of ";

//             //Add paging to header  
//             //tabFot.AddCell(cell2);
//             //  tabFot.AddCell(headerc1);
//             //  tabFot.AddCell(cell); tabFot.AddCell(cell1);
//             //  tabFot.WriteSelectedRows(0, -1, 50, document.Bottom + 50, writer.DirectContent);
//         }

//         //write on close of document
//         public override void OnCloseDocument(PdfWriter writer, Document document)
//         {
//             base.OnCloseDocument(writer, document);
//         }
//     }
// }



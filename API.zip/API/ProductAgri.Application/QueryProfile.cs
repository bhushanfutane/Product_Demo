﻿//using AutoMapper;

namespace ProductAgri.Application
{
    /// <summary>
    /// Profile class for mapping Model to DTO. This class is automatically called by AutoMapper service.
    //   /// </summary>
    //public class QueryProfile : Profile
    //{
    //    public QueryProfile()
    //    {
    //      //  CreateMap<User, UserDTO>().IgnoreAllPropertiesWithAnInaccessibleSetter();
    //      //  CreateMap<UserDTO, User>().IgnoreAllPropertiesWithAnInaccessibleSetter();
    //    }
    //}
}
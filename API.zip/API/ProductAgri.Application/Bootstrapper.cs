﻿using Microsoft.Extensions.DependencyInjection;
using ProductAgri.Application.Contract;
using ProductAgri.Domain.Model.Response;
using ProductAgri.Domain;
using ProductAgri.Application.Bussiness;

namespace ProductAgri.Application
{
    public class Bootstrapper
    {
        public static void RegisterDependancies(IServiceCollection services)
        {
            services.AddScoped<IAdminUserApplication, AdminUserApplication>();
            services.AddScoped<IUserApplication, UserApplication>();
            services.AddScoped<IResponseModel, ResponseModel>();
            services.AddScoped<ILoggingManager, LoggingManager>();
            services.AddScoped<ICategoryApplication, CategoryApplication>();
            services.AddScoped<IProductApplication, ProductApplication>();
            services.AddScoped<IUserAddressApplication, UserAddressApplication>();
        }
    }
}
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using ProductAgri.CustomConfig;

namespace ProductAgri
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public string MyAllowSpecificOrigins = "myPolicy";

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy(MyAllowSpecificOrigins,
                builder =>
                {
                    builder
                            .AllowAnyHeader()
                            .AllowAnyOrigin()
                            .AllowAnyMethod();
                });
            });

            services.AddMvc(options =>
            {
                options.EnableEndpointRouting = false;
            })
                .SetCompatibilityVersion(CompatibilityVersion.Version_3_0);

            services.AddHttpClient();

            // Register the Swagger generator, defining 1 or more Swagger documents
            SwaggerConfig.Register(services);

            //For Getting current Context
            CustomHttpServiceCollectionExtensions.AddHttpContextAccessor(services);

            //Register Identity
            IdentityConfig.Register(services, Configuration);
            IdentityConfig.RegisterAppDatabase(services, Configuration);

            //Dependancy registraion
            RegisterDependancyConfig.Register(services);
            services.AddControllers();
            services.AddHttpClient();
            // services.AddAWSService<IAmazonS3>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            if (env.IsProduction() || env.IsStaging() || env.IsEnvironment("Staging_2"))
            {
                app.UseExceptionHandler("/Error");
            }

            app.UseStaticFiles();

            app.UseCors(MyAllowSpecificOrigins);

            SwaggerConfig.Configure(app, Configuration);
            IdentityConfig.SeedDataBase(app);
            IdentityConfig.Configure(app);

            app.UseFileLogMiddleware();

            app.UseMvc();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProductAgri.Application.Contract;

namespace ProductAgri.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserAddressController : Controller
    {
        private readonly IUserAddressApplication application;
        private readonly ILoggingManager loggingManager;
        private readonly IHttpContextAccessor httpContextAccessor;

        public UserAddressController(IUserAddressApplication application, ILoggingManager loggingManager, IHttpContextAccessor httpContextAccessor)
        {
            this.application = application;
            this.loggingManager = loggingManager;
            this.httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="userAddress"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AddUserAddress")]
        [CustomAuthorize]
        public async Task<IActionResult> AddUserAddress([FromBody] UserAddressModel userAddress)
        {
            try
            {
                return Ok(await application.AddUserAddressAsync(userAddress));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="userAddress"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("UpdateUserAddress")]
        [CustomAuthorize]
        public async Task<IActionResult> UpdateUserAddress([FromBody] UserAddressModel userAddress)
        {
            try
            {
                return Ok(await application.UpdateUserAddressAsync(userAddress));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        /// <summary>
        /// Delete User Address
        /// </summary>
        /// <param name="customersModel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("DeleteUserAddress")]
        [CustomAuthorize]
        public async Task<IActionResult> DeleteUserAddress(int Id)
        {
            try
            {
                return Ok(await application.DeleteUserAddressAsync(Id));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpGet]
        [Route("GetUserAddress")]
        [CustomAuthorize]
        public async Task<IActionResult> GetAsync()
        {
            try
            {
                return Ok(await application.GetUserAddressAsync());
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }
    }
}
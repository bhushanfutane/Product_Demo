using System;
using System.Threading.Tasks;
using ProductAgri.Application.Contract;
using ProductAgri.Domain.Model;
using ProductAgri.Domain.Model.Response;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ProductAgri.Controllers
{
    [Route("api/[controller]")]
    public class UserController : Controller
    {
        private readonly IUserApplication application;
        private readonly ILoggingManager loggingManager;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IResponseModel responseModel;

        public UserController(IUserApplication application, ILoggingManager loggingManager, IHttpContextAccessor httpContextAccessor, IResponseModel responseModel)
        {
            this.application = application;
            this.loggingManager = loggingManager;
            this.httpContextAccessor = httpContextAccessor;
            this.responseModel = responseModel;
        }

        /// <summary>
        /// Add User
        /// </summary>
        /// <param name="customersModel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Registration")]
        public async Task<IActionResult> AddUser([FromBody] UserRegistration userModel)
        {
            try
            {
                return Ok(await application.UserRegistration(userModel));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        /// <summary>
        /// Update User
        /// </summary>
        /// <param name="customersModel"></param>
        /// <returns></returns>
        //[HttpPost]
        //[Route("UpdateUser")]
        //[CustomAuthorize]
        //public async Task<IActionResult> UpdateAsync([FromBody] UserModel userModel)
        //{
        //    try
        //    {
        //        return Ok(await application.UpdateUserAsync(userModel));
        //    }
        //    catch (Exception ex)
        //    {
        //        await loggingManager.LogException(ex, httpContextAccessor);
        //        return Ok("Something went wrong...!");
        //    }
        //}

        /// <summary>
        /// Delete User
        /// </summary>
        /// <param name="customersModel"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("DeleteUser")]
        [CustomAuthorize]
        public async Task<IActionResult> DeleteUser(int Id)
        {
            try
            {
                return Ok(await application.DeleteUserAsync(Id));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpGet]
        [Route("GetUserList")]
        [CustomAuthorize]
        public async Task<IActionResult> GetAsync(int Pageno, int PageSize)
        {
            try
            {
                return Ok(await application.GetUserAsync(Pageno, PageSize));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpGet]
        [Route("UpdateUserDetail")]
        [CustomAuthorize]
        public async Task<IActionResult> UpdateUserDetail(string fullName)
        {
            try
            {
                return Ok(await application.UpdateUserDetail(fullName));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpPost]
        [Route("setpassLogin")]
        //  [CustomAuthorize]
        public async Task<IActionResult> setpassLogin([FromBody] SetPassword model)
        {
            try
            {
                return Ok(await application.SetNewPassword(model));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpPost]
        [Route("login")]
        //  [CustomAuthorize]
        public async Task<IActionResult> Login([FromBody] UserLoginModel model)
        {
            try
            {
                return Ok(await application.Login(model));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpPost]
        [Route("ChangePassword")]
        [CustomAuthorize]
        public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordModel changePasswordModel)
        {
            try
            {
                return Ok(await application.ChangePasswordAsync(changePasswordModel));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }
    }
}
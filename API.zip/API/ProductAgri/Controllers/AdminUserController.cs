using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using ProductAgri.Domain.Model;
using ProductAgri.Application.Contract;
using ProductAgri.Domain.Model.Response;

namespace ProductAgri.Controllers
{
    [Route("api/[controller]")]
    public class AdminUserController : ControllerBase
    {
        private readonly IAdminUserApplication adminUserApp;
        private readonly ILoggingManager loggingManager;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IResponseModel responseModel;

        public AdminUserController(
            IAdminUserApplication adminUserApp,
            ILoggingManager loggingManager,
            IHttpContextAccessor httpContextAccessor,
            IResponseModel responseModel)
        {
            this.adminUserApp = adminUserApp;
            this.loggingManager = loggingManager;
            this.httpContextAccessor = httpContextAccessor;
            this.responseModel = responseModel;
        }

        /// <summary>
        /// Registration Admin User
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("AdminUserList")]
        [CustomAuthorize]
        public async Task<IActionResult> AdminUserRegister()
        {
            try
            {
                return Ok(await adminUserApp.GetAdminUser());
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        /// <summary>
        /// Registration Admin User
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("AdminUserRegister")]
        public async Task<IActionResult> AdminUserRegister([FromBody] AdminUserRegistrationModel model)
        {
            try
            {
                return Ok(await adminUserApp.AddAdminUser(model));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        /// <summary>
        /// Registration Admin User
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("UpdateAdminUser")]
        [CustomAuthorize]
        public async Task<IActionResult> UpdateAdminUser([FromBody] AdminUserRegistrationModel model)
        {
            try
            {
                return Ok(await adminUserApp.UpdateAdminUser(model));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        /// <summary>
        /// Registration Admin User
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("RemoveUserRegister")]
        [CustomAuthorize]
        public async Task<IActionResult> RemoveUserRegister(int EmployeeId)
        {
            try
            {
                return Ok(await adminUserApp.RemoveAdminUser(EmployeeId));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpPost]
        [Route("setpassLogin")]
        [CustomAuthorize]
        public async Task<IActionResult> setpassLogin([FromBody] SetPassword model)
        {
            try
            {
                return Ok(await adminUserApp.SetNewPassword(model));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpPost]
        [Route("login")]
        //[CustomAuthorize]
        public async Task<IActionResult> Login([FromBody] UserLoginModel model)
        {
            try
            {
                return Ok(await adminUserApp.Login(model));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpPost]
        [Route("ChangePassword")]
        [CustomAuthorize]
        public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordModel changePasswordModel)
        {
            try
            {
                return Ok(await adminUserApp.ChangePasswordAsync(changePasswordModel));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpGet]
        [Route("Info")]
        [CustomAuthorize]
        public async Task<IActionResult> EmployeeInfo()
        {
            try
            {
                return Ok(await adminUserApp.GetAdminUserById());
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }
    }
}
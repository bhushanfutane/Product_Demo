﻿using ProductAgri.Application.Contract;
using ProductAgri.Persistence;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ProductAgri.Controllers
{
    [Route("api/[controller]")]
    public class AuthController : Controller
    {
        //private readonly IAdminUserApplication adminUserApp;
        private ILoggingManager loggingManager;

        private IHttpContextAccessor httpContextAccessor;
        private readonly IUserApplication userApp;
        private readonly AppDBContext context;
        private readonly IHostingEnvironment hostingEnvironment;

        public AuthController(
            IAdminUserApplication adminUserApp,
            ILoggingManager _loggingManager,
            IHttpContextAccessor _httpContextAccessor,
            IUserApplication userApp,
            AppDBContext context,
            IHostingEnvironment hostingEnvironment)
        {
            //this.adminUserApp = adminUserApp;
            this.loggingManager = _loggingManager;
            this.httpContextAccessor = _httpContextAccessor;
            this.userApp = userApp;
            this.context = context;
            this.hostingEnvironment = hostingEnvironment;
        }
    }
}
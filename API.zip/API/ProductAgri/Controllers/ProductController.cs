﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProductAgri.Application.Contract;
using ProductAgri.Domain.Model;

namespace ProductAgri.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductApplication application;
        private readonly ILoggingManager loggingManager;
        private readonly IHttpContextAccessor httpContextAccessor;

        public ProductController(IProductApplication application, ILoggingManager loggingManager, IHttpContextAccessor httpContextAccessor)
        {
            this.application = application;
            this.loggingManager = loggingManager;
            this.httpContextAccessor = httpContextAccessor;
        }

        [HttpPost]
        [Route("AddAsync")]
        [CustomAuthorize]
        public async Task<IActionResult> AddAsync([FromBody] Prod category)
        {
            try
            {
                return Ok(await application.AddAsync(category));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpPost]
        [Route("UpdateAsync")]
        [CustomAuthorize]
        public async Task<IActionResult> UpdateAsync([FromBody] Prod category)
        {
            try
            {
                return Ok(await application.UpdateAsync(category));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpGet]
        [Route("GetAll")]
        //[CustomAuthorize]
        public async Task<IActionResult> GetAll(int Pagesize, int Pageno)
        {
            try
            {
                return Ok(await application.GetAll(Pagesize, Pageno));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpGet]
        [Route("GetActive")]
        [CustomAuthorize]
        public async Task<IActionResult> GetActive(int Pagesize, int Pageno)
        {
            try
            {
                return Ok(await application.GetActive(Pagesize, Pageno));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpGet]
        [Route("Product")]
        // [CustomAuthorize]
        public async Task<IActionResult> Product(int Pagesize, int Pageno)
        {
            try
            {
                return Ok(await application.GetProducts(Pagesize, Pageno));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }
    }
}
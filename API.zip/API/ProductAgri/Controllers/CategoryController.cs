﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProductAgri.Application.Contract;
using ProductAgri.Domain.Model;

namespace ProductAgri.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryApplication application;
        private readonly ILoggingManager loggingManager;
        private readonly IHttpContextAccessor httpContextAccessor;

        public CategoryController(ICategoryApplication application, ILoggingManager loggingManager, IHttpContextAccessor httpContextAccessor)
        {
            this.application = application;
            this.loggingManager = loggingManager;
            this.httpContextAccessor = httpContextAccessor;
        }

        [HttpPost]
        [Route("AddAsync")]
        [CustomAuthorize]
        public async Task<IActionResult> AddAsync([FromBody] Category category)
        {
            try
            {
                return Ok(await application.AddAsync(category));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpPost]
        [Route("UpdateAsync")]
        [CustomAuthorize]
        public async Task<IActionResult> UpdateAsync([FromBody] Category category)
        {
            try
            {
                return Ok(await application.UpdateAsync(category));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpPost]
        [Route("AddSubAsync")]
        [CustomAuthorize]
        public async Task<IActionResult> AddSubAsync([FromBody] SubCategory category)
        {
            try
            {
                return Ok(await application.AddSubAsync(category));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpPost]
        [Route("UpdateSubAsync")]
        [CustomAuthorize]
        public async Task<IActionResult> UpdateSubAsync([FromBody] SubCategory category)
        {
            try
            {
                return Ok(await application.UpdateSubAsync(category));
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        /// <summary>
        /// Registration Admin User
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetAll")]
        [CustomAuthorize]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                return Ok(await application.GetAll());
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpGet]
        [Route("GetActive")]
        [CustomAuthorize]
        public async Task<IActionResult> GetActive()
        {
            try
            {
                return Ok(await application.GetActive());
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpGet]
        [Route("GetSubAll")]
        [CustomAuthorize]
        public async Task<IActionResult> GetSubAll()
        {
            try
            {
                return Ok(await application.GetSubAll());
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }

        [HttpGet]
        [Route("GetSubActive")]
        [CustomAuthorize]
        public async Task<IActionResult> GetSubActive()
        {
            try
            {
                return Ok(await application.GetSubActive());
            }
            catch (Exception ex)
            {
                await loggingManager.LogException(ex, httpContextAccessor);
                return Ok("Something went wrong...!");
            }
        }
    }
}
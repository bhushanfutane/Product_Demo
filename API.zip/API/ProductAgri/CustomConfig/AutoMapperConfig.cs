﻿using Microsoft.Extensions.DependencyInjection;

namespace WebApiTemplate.CustomConfig
{
    public class AutoMapperConfig
    {
        public static void Register(IServiceCollection services)
        {
            //services.AddAutoMapper(typeof(QueryProfile));
        }
    }
}

﻿using ProductAgri.Domain.Model;
using ProductAgri.Domain.Model.Response;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace ProductAgri
{
    public class LoggerManager
    {
        public RequestDelegate Next { get; }

        public LoggerManager(RequestDelegate next)
        {
            Next = next;
        }

        public Task Invoke(HttpContext context)
        {
            var responseModel = context.RequestServices.GetService<IResponseModel>();

            var v = context.Request.RouteValues.Values;
            var action = string.Join("--->", context.Request.Path.Value.Split('/')[^2..].OrderByDescending(a => a));

            var isUthorize = context.User.Identity.IsAuthenticated;

            return Next(context);
        }
    }

    public static class LoggerManagerExtension
    {
        public static IApplicationBuilder UseFileLogMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<LoggerManager>();
        }
    }
}
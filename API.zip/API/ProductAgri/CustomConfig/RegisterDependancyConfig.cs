﻿// using Microsoft.Extensions.DependencyInjection;
// using FlourPicker.Application;
// using FlourPicker.Application.Contract;
// using FlourPicker.Persistence;
// using FlourPicker.Persistence.Contract;
// using AppBootstrapper = FlourPicker.Application.Bootstrapper;
// using PersistBootstrapper = FlourPicker.Persistence.Bootstrapper;

// namespace FlourPickerTemplate.CustomConfig
// {
//     public class RegisterDependancyConfig
//     {
//         /// <summary>
//         /// Add new Dependacy Class entry here
//         /// </summary>
//         /// <param name="services"></param>
//         public static void Register(IServiceCollection services)
//         {
//             //Application Dependancy registraion
//             AppBootstrapper.RegisterDependancies(services);

//             //Repository Dependancy registraion
//             PersistBootstrapper.RegisterDependancies(services);

//         }
//     }
// }

using Microsoft.Extensions.DependencyInjection;
using ProductAgri.Application;
using ProductAgri.Application.Contract;
using ProductAgri.Persistence;
using ProductAgri.Persistence.Contract;
using AppBootstrapper = ProductAgri.Application.Bootstrapper;
using PersistBootstrapper = ProductAgri.Persistence.Bootstrapper;

namespace ProductAgri.CustomConfig
{
    public class RegisterDependancyConfig
    {
        /// <summary>
        /// Add new Dependacy Class entry here
        /// </summary>
        /// <param name="services"></param>
        public static void Register(IServiceCollection services)
        {
            //Application Dependancy registraion
            AppBootstrapper.RegisterDependancies(services);

            //Repository Dependancy registraion
            PersistBootstrapper.RegisterDependancies(services);
        }
    }
}
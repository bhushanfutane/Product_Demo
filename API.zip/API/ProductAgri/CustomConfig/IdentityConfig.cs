﻿using System;
using System.Configuration;
using System.Text;

//using BooksApi.Models;
using ProductAgri.Persistence;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using MongoDB.Driver;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;
using ProductAgri.Domain.Model;

#pragma warning disable CS0105 // The using directive for 'FlourPicker.Persistence' appeared previously in this namespace
using ProductAgri.Persistence;
#pragma warning restore CS0105 // The using directive for 'FlourPicker.Persistence' appeared previously in this namespace
#pragma warning disable CS0105 // The using directive for 'FlourPicker.Domain.Model' appeared previously in this namespace
using ProductAgri.Domain.Model;
#pragma warning restore CS0105 // The using directive for 'FlourPicker.Domain.Model' appeared previously in this namespace

namespace ProductAgri.CustomConfig
{
    public class IdentityConfig
    {
        public static void Register(IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<Settings>(options =>
            {
                options.ConnectionString = configuration.GetSection("MongoConnection:ConnectionString").Value;
                options.Database = configuration.GetSection("MongoConnection:DatabaseName").Value;
            });

            services.AddSingleton<IMongoDbContext, MongoDbContext>();

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            })
                .AddJwtBearer(options =>
                {
                    options.SaveToken = true;
                    options.RequireHttpsMetadata = false;
                    options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters()
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidAudience = "http://oec.com",
                        ValidIssuer = "http://oec.com",
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("MyAdvanceSupperKey"))
                    };
                });
        }

        public static void RegisterAppDatabase(IServiceCollection services, IConfiguration configuration)
        {
            var constr = configuration.GetValue<string>("ConnectionString:DefaultConnection");

            services.AddDbContext<AppDBContext>(options =>
            {
                options.UseSqlServer(constr);
                options.EnableSensitiveDataLogging();
            });
        }

        public static void SeedDataBase(IApplicationBuilder app)
        {
            SeedDatabase.Initialize(app.ApplicationServices.GetRequiredService<IServiceScopeFactory>().CreateScope().ServiceProvider);
        }

        public static void Configure(IApplicationBuilder app)
        {
            app.UseAuthentication();
        }
    }
}
﻿using ProductAgri.Domain;
using ProductAgri.Domain.Model.Response;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Linq;
using System.Net;
using System.Security.Claims;

namespace ProductAgri
{
    /// <summary>
    /// Authorization Attribute For Authenticating Requests
    /// </summary>
    public class CustomAuthorizeAttribute : TypeFilterAttribute
    {
        /// <summary>
        /// Generate Claims Key Value
        /// </summary>
        /// <param name="claimType"></param>
        /// <param name="claimValue"></param>
        public CustomAuthorizeAttribute() : base(typeof(AuthorizeRequirementFilter))
        {
            Arguments = new object[] { };
        }
    }

    /// <summary>
    /// Filter Claims
    /// </summary>
    public class AuthorizeRequirementFilter : IAuthorizationFilter
    {
#pragma warning disable CS0169 // The field 'AuthorizeRequirementFilter._claim' is never used
        private readonly Claim _claim;
#pragma warning restore CS0169 // The field 'AuthorizeRequirementFilter._claim' is never used
        private readonly IResponseModel responseModel;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="claim"></param>
        /// <param name="responseModel"></param>
        public AuthorizeRequirementFilter(IResponseModel responseModel)
        {
            this.responseModel = responseModel;
        }

        /// <summary>
        /// Check For Specific Claim And Shortcircuit From Pipeline
        /// </summary>
        /// <param name="context"></param>
        public void OnAuthorization(AuthorizationFilterContext context)
        {
            if (!context.HttpContext.User.Identity.IsAuthenticated)
            {
                context.Result = new OkObjectResult(responseModel.CreateUnauthorizeResponse(HttpStatusCode.Unauthorized, "Token Is Invalid Or Expired"));
            }
        }
    }
}
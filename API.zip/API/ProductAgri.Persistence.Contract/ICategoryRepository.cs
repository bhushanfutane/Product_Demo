﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProductAgri.Persistence.Contract
{
    public interface ICategoryRepository
    {
        Task<List<TblCategory>> GetAsync(int pageSize, int pageNumber);

        Task<List<TblCategory>> GetAsync(int pageSize, int pageNumber, bool IsActive = true);

        Task<TblCategory> GetAsync(int Id);

        Task<TblCategory> AddAsync(TblCategory grain);

        Task<TblCategory> UpdateAsync(TblCategory grain);

        Task<TblCategory> RemoveAsync(TblCategory grain);

        Task<TblCategory> GetAsync(string grainName, int grainId = 0);
    }
}
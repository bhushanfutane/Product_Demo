﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProductAgri.Persistence.Contract
{
    public interface IProductRepository
    {
        Task<List<TblProduct>> GetAsync(int pageSize, int pageNumber);

        Task<List<TblProduct>> GetAsync(int pageSize, int pageNumber, bool IsActive = true);

        Task<TblProduct> GetAsync(int Id);

        Task<TblProduct> AddAsync(TblProduct product);

        Task<TblProduct> UpdateAsync(TblProduct product);

        Task<TblProduct> RemoveAsync(TblProduct product);

        Task<TblProduct> GetAsync(string grainName, int grainId = 0);

        Task<List<TblProduct>> GetAsync(List<int> Ids);
    }
}
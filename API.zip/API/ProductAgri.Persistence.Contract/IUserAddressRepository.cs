﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProductAgri.Persistence.Contract
{
    public interface IUserAddressRepository
    {
        Task<TblUserAddress> GetAsync(int Id);

        Task<List<TblUserAddress>> GetAllAsync(int UserId);

        Task<TblUserAddress> GetAsync(int userId, bool Isdefault);

        Task<TblUserAddress> Add(TblUserAddress userAddress);

        Task<TblUserAddress> Remove(TblUserAddress userAddress);

        Task<TblUserAddress> Update(TblUserAddress userAddress);

        Task<List<TblUserAddress>> UpdateRangeAsync(List<TblUserAddress> userAddress);
    }
}
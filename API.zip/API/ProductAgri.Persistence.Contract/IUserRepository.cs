﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ProductAgri;
using ProductAgri.Domain.Model;

namespace ProductAgri.Persistence.Contract
{
    public interface IUserRepository
    {
        Task<AdminUsers> GetAsync(int PageNo, int PageSize, bool IsActive = true);

        Task<AdminUsers> GetAsyncSearch(string SearchStr, int PageNo, int PageSize);

        Task<TblUser> GetAsync(int Id);

        Task<TblUser> GetAsync(string UserName);

        Task<TblUser> AddUserAsync(TblUser user);

        Task<TblUser> UpdateUserAsync(TblUser user);

        Task<TblUser> RemoveUserAsync(TblUser user);

        Task<TblUser> GetAsync(string userName, string password);

        Task<TblUser> GetAsync(string userName, int UserId = 0);
    }
}
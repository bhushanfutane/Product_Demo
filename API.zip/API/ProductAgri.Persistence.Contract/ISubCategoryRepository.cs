﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProductAgri.Persistence.Contract
{
    public interface ISubCategoryRepository
    {
        Task<List<TblSubCategory>> GetAsync(int pageSize, int pageNumber);

        Task<List<TblSubCategory>> GetAsync(int pageSize, int pageNumber, bool IsActive = true, int CategoryId = 0);

        Task<TblSubCategory> GetAsync(int SubcategoryId);

        Task<TblSubCategory> AddAsync(TblSubCategory SubCategory);

        Task<TblSubCategory> UpdateAsync(TblSubCategory SubCategory);

        Task<TblSubCategory> RemoveAsync(TblSubCategory SubCategory);

        Task<TblSubCategory> GetAsync(string Subcategory, int SubcategoryId = 0);
    }
}
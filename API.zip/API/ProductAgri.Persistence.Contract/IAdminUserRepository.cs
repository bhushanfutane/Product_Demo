using ProductAgri.Domain.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProductAgri.Persistence.Contract
{
    public interface IAdminUserRepository
    {
        Task<TblAdminUser> AddAdminUser(TblAdminUser adminUser);

        Task<TblAdminUser> GetAdminUserById(int AdminUserId);

        Task<List<TblAdminUser>> GetAdminUser();

        Task<TblAdminUser> RemoveAdminUser(TblAdminUser adminUser);

        Task<TblAdminUser> UpdateAdminUser(TblAdminUser adminUser);

        Task<TblAdminUser> GetAdminUserByForLogin(string username, string password, bool IsEmail);

        Task<TblAdminUser> GetAdminUserByForLogin(string username, bool IsEmail);

        Task<TblAdminUser> IsUserNameTaken(string userName, int UserId = 0);
    }
}
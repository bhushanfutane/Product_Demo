﻿using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;

namespace ProductAgri.Persistence.Contract
{
    public interface ILoggerRepository
    {
        // void LogToDatabase(Exception ex);
        //  Task<string> LogToDatabase(Exception ex, IHttpContextAccessor httpContext);
        Task LogToDatabaseAsync(Exception ex, IHttpContextAccessor httpContext);
    }
}
﻿using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;

namespace ProductAgri.Application.Contract
{
    public interface ILoggingManager
    {
        // Task<string> LogException(Exception ex, IHttpContextAccessor httpContext);
        Task LogException(Exception ex, IHttpContextAccessor httpContext);
    }
}
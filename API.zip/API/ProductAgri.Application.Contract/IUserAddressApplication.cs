﻿using ProductAgri.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProductAgri.Application.Contract
{
    public interface IUserAddressApplication
    {
        Task<ResponseModel> GetUserAddressAsync();

        Task<ResponseModel> AddUserAddressAsync(UserAddressModel userAddress);

        Task<ResponseModel> UpdateUserAddressAsync(UserAddressModel userAddress);

        Task<ResponseModel> DeleteUserAddressAsync(int Id);
    }
}
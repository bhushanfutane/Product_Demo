﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ProductAgri.Domain;
using ProductAgri.Domain.Model;

//using Todkar.AspNetCore.Http;

namespace ProductAgri.Application.Contract
{
    public interface IUserApplication
    {
        Task<ResponseModel> GetUserAsync(int PageNo, int PageSize);

        Task<ResponseModel> UpdateUserDetail(string Fullname);

        Task<ResponseModel> DeleteUserAsync(int Id);

        Task<ResponseModel> UserRegistration(UserRegistration userModel);

        Task<ResponseModel> Login(UserLoginModel userModel);

        Task<ResponseModel> SetNewPassword(SetPassword setPassword);

        Task<ResponseModel> ChangePasswordAsync(ChangePasswordModel changePasswordModel);
    }
}
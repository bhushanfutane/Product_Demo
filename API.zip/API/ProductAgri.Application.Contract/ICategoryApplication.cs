﻿using ProductAgri.Domain;
using ProductAgri.Domain.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProductAgri.Application.Contract
{
    public interface ICategoryApplication
    {
        Task<ResponseModel> AddAsync(Category category);

        Task<ResponseModel> UpdateAsync(Category category);

        Task<ResponseModel> GetAll();

        Task<ResponseModel> GetActive();

        Task<ResponseModel> AddSubAsync(SubCategory subCategory);

        Task<ResponseModel> UpdateSubAsync(SubCategory subCategory);

        Task<ResponseModel> GetSubAll();

        Task<ResponseModel> GetSubActive();
    }
}
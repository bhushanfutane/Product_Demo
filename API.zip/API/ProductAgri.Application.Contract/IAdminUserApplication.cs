using System.Threading.Tasks;

using ProductAgri.Domain.Model;
using ProductAgri.Domain;

namespace ProductAgri.Application.Contract
{
    public interface IAdminUserApplication
    {
        Task<ResponseModel> AddAdminUser(AdminUserRegistrationModel adminUser);

        Task<ResponseModel> GetAdminUserById();

        Task<ResponseModel> GetAdminUser();

        Task<ResponseModel> RemoveAdminUser(int EmpId);

        Task<ResponseModel> UpdateAdminUser(AdminUserRegistrationModel adminUser);

        Task<ResponseModel> Login(UserLoginModel userModel);

        Task<ResponseModel> SetNewPassword(SetPassword setPassword);

        Task<ResponseModel> ChangePasswordAsync(ChangePasswordModel changePasswordModel);
    }
}
﻿using ProductAgri.Domain;
using ProductAgri.Domain.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProductAgri.Application.Contract
{
    public interface IProductApplication
    {
        Task<ResponseModel> AddAsync(Prod prod);

        Task<ResponseModel> UpdateAsync(Prod prod);

        Task<ResponseModel> GetAll(int Pagesize, int Pageno);

        Task<ResponseModel> GetActive(int Pagesize, int Pageno);

        Task<ResponseModel> GetProducts(int Pagesize, int Pageno);
    }
}
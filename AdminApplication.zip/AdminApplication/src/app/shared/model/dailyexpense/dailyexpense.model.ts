export interface IDailyExpense {
  id: number;
  date: string;
  //time: string;
  purpose: string;
  amount:number;
  isActive: boolean;
}

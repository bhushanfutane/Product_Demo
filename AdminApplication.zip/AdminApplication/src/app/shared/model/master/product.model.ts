export interface IProduct {
  id: number;
  nameEng: string;
  nameMar: string;
  nameHin: string;
  price: number;
  active: boolean;
  imageUrl: string;
  imageBase64: string;
  discription: string;
  discriptionHn: string;
  discriptionMr: string;
  mrp: number; 
  categoryId:number;
  weight:number;

}

export interface IVideo {
  id: number;
  video: string,
  videoHn: string,
  videoMr: string,
  path: string,
  productId: number,
  courseId:number,
  discription: string,
  discriptionHn: string,
  discriptionMr: string,
  isDefaultVideo:boolean,
  
}





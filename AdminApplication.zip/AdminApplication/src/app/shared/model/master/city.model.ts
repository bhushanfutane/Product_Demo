export interface ICity {
  id: number;
  engName: string;
  hindiName: string;
  marathiName: string;
  isActive: boolean;
  cityNameEng: string;
}

export interface ICategory {
  id: number;
  nameEng: string;
  nameMar: string;
  nameHin: string;
  imagePath: string;
  imageBase64: string;
  file: File;
  active: boolean;
  categoryId?: number;
}

export interface ISubCategory {
  id: number;
  categoryId?: number;
  nameEng: string;
  nameMar: string;
  nameHin: string;
  imagePath: string;
  imageBase64: string;
  active: boolean;
  discription: string;

}

export interface ISocial {

  id: number,
  title: string,
  titleHn: string,
  titleMr: string,
  discription: string,
  discriptionHn: string,
  discriptionMr: string,
  imageUrl: string,
  imageBase64: string,
  videoUrl: string,
  isActive: boolean
}

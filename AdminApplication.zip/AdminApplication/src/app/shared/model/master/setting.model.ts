export interface ISetting {
  id: number;
  name: string;
  settingKey: string;
  settingValue: string;
}

export interface ILogin {
  mobile: string;
  password: string;
  loginfrom: 1;
}


export interface IOTPLogin {
  username: string;
  otp: string;
  loginfrom: 1;

}


export interface ISetPassword {
  username: string;
  otp: string;
  newPassword: string;
  loginfrom: 1;
}

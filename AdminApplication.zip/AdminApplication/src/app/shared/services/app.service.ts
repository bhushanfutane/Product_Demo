import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';


@Injectable()
export class AppService {
  private updatemenuSubject = new Subject<boolean>();
  constructor() { }
  getMenu() {
    return this.updatemenuSubject.asObservable();
  }

  setMenu(status: boolean) {
    this.updatemenuSubject.next(status);
  }

}

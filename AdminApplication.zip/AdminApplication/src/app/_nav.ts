import { INavData } from '@coreui/angular';

export const navMaterilaItemsEng: INavData[] = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    icon: 'icon-speedometer',
    badge: {
      variant: 'info',
      text: 'NEW'
    }
  },
  {
    name: 'Master',
    class: 'module-nav',
    children: [
      {
        name: 'Category',
        url: '/master/category',
        icon: 'icon-cursor',
      },
      // {
      //   name: 'Sub-Category',
      //   url: '/master/sub_category',
      //   icon: 'icon-cursor'
      // },
      {
        name: 'Course ',
        url: '/master/course',
        icon: 'icon-cursor',
      },
      {
        name: 'Banner',
        url: '/master/banner',
        icon: 'icon-cursor'
      },
      {
        name: 'Product',
        url: '/master/product',
        icon: 'icon-cursor',
      },
      {
        name: 'Video',
        url: '/master/videos',
        icon: 'icon-cursor',
      },
      {
        name: 'VideoCourse',
        url: '/master/videocourse',
        icon: 'icon-cursor',
      },
      {
        name: 'Social',
        url: '/master/social',
        icon: 'icon-cursor'
      },
      {
        name: 'User',
        url: '/master/users',
        icon: 'icon-cursor'
      },
    
    
      {
        name: 'Order status',
        url: '/master/order_status',
        icon: 'icon-cursor',
      },
      {
        name: 'Delivery',
        url: '/master/delivery',
        icon: 'icon-cursor',
      },

    ]
  },

  // {
  //   name: 'Inventory',

  //   class: 'module-nav',
  //   children: [
  //     {
  //       name: 'Stock In',
  //       url: '/inventory/stock-in',
  //       icon: 'icon-cursor'
  //     },
  //   ]
  // },



  // {
  //   name: 'Course',
  //   url: '/course/course',
  //    icon: 'icon-puzzle',
  //   class: 'module-nav',

  // },
  // {
  //   name: 'Product',
  //   url: '/product/product',
  //   icon: 'icon-envelope-letter',
  // },

  // {
  //   name: 'Chatting',
  //   url: '/chatting/chatting',
  //    icon: 'icon-envelope-letter',
  // },
  // {
  //   name: 'Profile',
  //   url: '/profile/profile',
  //    icon: 'icon-envelope-letter',
  // },
];

export const navMaterilaItemsMar: INavData[] = [
  {
    name: 'डॅशबोर्ड',
    url: '/dashboard',
    icon: 'icon-speedometer',
    badge: {
      variant: 'info',
      text: 'नवीन'
    }
  },

  {
    name: 'कोर्स',
    icon: 'icon-puzzle',
    class: 'module-nav',
    //   children: [
    //     {
    //       name: 'ग्राहक',
    //       url: '/material/customer',
    //       icon: 'icon-dot'
    //     },
    //     {
    //       name: 'मटेरियल',
    //       url: '/material/materials',
    //       icon: 'icon-dot'
    //     },
    //     {
    //       name: 'कंपनी साठा',
    //       url: '/material/companystock',
    //       icon: 'icon-dot'
    //     },
    //   ]


  },

  {
    name: 'उत्पादन',
    url: '/product/product',
    icon: 'icon-puzzle',

  },
  {
    name: 'गप्पा मारणे',
    url: '/chatting/chatting',
    icon: 'icon-puzzle',

  },
  {
    name: 'प्रोफाइल',
    url: '/profile/profile',
    icon: 'icon-puzzle',

  },
];


export const navConstrItemsEng: INavData[] = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    icon: 'icon-speedometer',
    badge: {
      variant: 'info',
      text: 'NEW'
    }
  },
  {
    name: 'Construction',
    icon: 'icon-layers',
    class: 'module-nav',
    children: [
      {
        name: 'Customers',
        url: '/construction/customers',
        icon: 'icon-dot'
      },
      {
        name: 'Worker',
        url: '/construction/worker',
        icon: 'icon-dot'
      },
      {
        name: 'Site',
        url: '/construction/site',
        icon: 'icon-dot'
      },
      {
        name: 'SiteWork',
        url: '/construction/siteworker',
        icon: 'icon-dot'
      },
      {
        name: 'CustomerPayment',
        url: '/construction/customerpayment',
        icon: 'icon-dot'
      },

      {
        name: 'WorkerPayment',
        url: '/construction/workerpayment',
        icon: 'icon-dot'
      },
    ]
  },
  {
    name: 'DailyExpense',
    url: '/dailyexpense/dailyexpense',
    icon: 'icon-envelope-letter',
  },
];

export const navConstrItemsMar: INavData[] = [
  {
    name: 'डॅशबोर्ड',
    url: '/dashboard',
    icon: 'icon-speedometer',
    badge: {
      variant: 'info',
      text: 'नवीन'
    }
  },
  {
    name: 'बांदकाम',
    icon: 'icon-puzzle',
    class: 'module-nav',
    children: [
      {
        name: 'ग्राहक',
        url: '/construction/customers',
        icon: 'icon-dot'
      },
      {
        name: 'कामगार',
        url: '/construction/worker',
        icon: 'icon-dot'
      },
      {
        name: 'साइट',
        url: '/construction/site',
        icon: 'icon-dot'
      },
      {
        name: 'साइट काम',
        url: '/construction/siteworker',
        icon: 'icon-dot'
      },
      {
        name: 'ग्राहकांचे पेमेंट',
        url: '/construction/customerpayment',
        icon: 'icon-dot'
      },

      {
        name: 'कामगार पेमेंट',
        url: '/construction/workerpayment',
        icon: 'icon-dot'
      },
    ]
  },
  {
    name: 'दैनिक खर्च',
    url: '/dailyexpense/dailyexpense',
    icon: 'icon-puzzle',

  },
];



export const navTransItemsEng: INavData[] = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    icon: 'icon-speedometer',
    badge: {
      variant: 'info',
      text: 'NEW'
    }
  },
  {
    name: 'Transport',
    icon: 'icon-puzzle',
    class: 'module-nav',
    children: [
      {
        name: 'Vehicle',
        url: '/transport/vehicle',
        icon: 'icon-dot'
      },
      {
        name: 'VehiclePayment',
        url: '/transport/vehiclepayment',
        icon: 'icon-dot'
      },
      {
        name: 'CompanyPayment',
        url: '/transport/companypayment',
        icon: 'icon-dot'
      }
    ]
  },

  {
    name: 'DailyExpense',
    url: '/dailyexpense/dailyexpense',
    icon: 'icon-envelope-letter',
  },
];

export const navTransItemsMar: INavData[] = [
  {
    name: 'डॅशबोर्ड',
    url: '/dashboard',
    icon: 'icon-speedometer',
    badge: {
      variant: 'info',
      text: 'नवीन'
    }
  },
  {
    name: 'वाहतूक',
    icon: 'icon-puzzle',
    class: 'module-nav',
    children: [
      {
        name: 'वाहन',
        url: '/transport/vehicle',
        icon: 'icon-dot'
      },
      {
        name: 'वाहन पेमेंट',
        url: '/transport/vehiclepayment',
        icon: 'icon-dot'
      },
      {
        name: 'कंपनी पेमेंट',
        url: '/transport/companypayment',
        icon: 'icon-dot'
      }
    ]
  },
  {
    name: 'दैनिक खर्च',
    url: '/dailyexpense/dailyexpense',
    icon: 'icon-puzzle',

  },
];

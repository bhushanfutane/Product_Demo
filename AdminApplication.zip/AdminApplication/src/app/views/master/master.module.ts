// Angular
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { CityComponent } from './city/city.component';

// navbars

// Components Routing
import { MasterRoutingModule } from './master-routing.module';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { NavbarsComponent } from './navbars/navbars.component';
import { BannerComponent } from './banner/banner.component';
import { SettingComponent } from './setting/setting.component';
import { RolerightsComponent } from './rolerights/rolerights.component';
import { RoleComponent } from './role.component';
import { CategoryComponent } from './category/category.component';
import { ProductComponent } from './product/product.component';
import { CousreDetailsComponent } from './cousre-details/cousre-details.component';
import { DeliveryComponent } from './delivery/delivery.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { SocialComponent } from './social/social.component';
import { SubCategoryComponent } from './sub-category/sub-category.component';
import { UsersComponent } from './users/users.component';
import { VideosComponent } from './videos/videos.component';
import { OrderStatusComponent } from './order-status/order-status.component';
import { VediocourseComponent } from './vediocourse/vediocourse.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MasterRoutingModule, 
    CollapseModule.forRoot(),
    PaginationModule.forRoot(), 
    ],
  declarations: [
    CityComponent,
    CategoryComponent,
    NavbarsComponent,
    SubCategoryComponent,
    CousreDetailsComponent,
    OrderDetailsComponent,
    UsersComponent,
    VideosComponent,
    DeliveryComponent,
    BannerComponent,
    SettingComponent,
    RolerightsComponent,
    RoleComponent,
    CategoryComponent,
    ProductComponent,
    OrderDetailsComponent,
    OrderStatusComponent,
    SocialComponent,
    VediocourseComponent
  ],
})
export class MasterModule {}

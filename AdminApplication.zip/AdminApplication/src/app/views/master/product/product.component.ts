import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ICategory, IProduct } from '../../../shared/model';
import { ICourse } from '../../../shared/model/master/course.model';
import { HttpStatusCode, ResponseModel } from '../../../shared/responsemodel';
import { ApiDataService } from '../../../shared/services/apidata.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',

})
export class ProductComponent implements OnInit {
  productForm: FormGroup;
  submitted = false;
  prodList: any[];
  courseListDD = [];
  copyProductList: any[] = [];
  isUpdate = false;
  pageSize = 100;
  pageNumber = 1;
  isSaveDisabled = false;
  pageRole: any;
  roleId: number;
  saveBtnHideForRole = true;
  // file: File;
  bannerfile: File;
  bannerfileSrc = '';
  bannerfileStr = '';
  categoryListForDD = [];
  Id = 0;
  imagePreview: string | ArrayBuffer;
  file: any;
  showEditForm = false;
  id = 0;
  totalItems: number = 1;
  bigTotalItems: number = 675;
  bigCurrentPage: number = 1;
  numPages: number = 0;
  currentPager: number = 4;
  currentPage = 1;
  itemPerPage = 10;
  fileInfo: string;
  imageIsempty = false;
  activeCourseList: any[];
  prodTypeList = [
    {
      id: 1,
      name: 'Kitak_Nashak'
    },
    {
      id: 2,
      name: 'Tan_Nashak'
    },
    {
      id: 3,
      name: 'Tonik '
    }
  ]
  setPage(pageNo: number): void {
    this.currentPage = pageNo;
  }

  constructor(
    private apiservice: ApiDataService,
    private toastrService: ToastrService,
    private apidataservice: ApiDataService,
    private fb: FormBuilder,
    private toastr: ToastrService
  ) {
    this.productForm = this.fb.group({
      // courseId: ['', [Validators.required]],
      // typeId: ['', [Validators.required]],
      categoryId:['',[Validators.required]],
      nameEng: ['', [Validators.required]],
      nameHin: ['', [Validators.required]],
      nameMar: ['', [Validators.required]],
      active: [false],
      price: ['', [Validators.required]],
      mrp: ['', [Validators.required]],
      weight:['',[Validators.required]],
      discription: ['', [Validators.required]],
      discriptionHn: ['', [Validators.required]],
      discriptionMr: ['', [Validators.required]],
      
    });
  }

  ngOnInit() {
    this.getProdList();
    this.getActiveCourseList();
    this.getCategoryList();
  }

  async onselectBannerImages(event) {
    this.bannerfile = event.target.files[0];
    const file64 = await this.apidataservice.toBase64(this.bannerfile);
    this.bannerfileSrc = file64;
    this.bannerfileStr = file64.split(',')[1];
    this.imageIsempty = false;
  }
  clearForm() {
    this.id = 0;
    this.productForm.reset();
    this.showEditForm = false;
    this.bannerfileSrc = '';
    this.submitted = false;
  }
  get f() {
    return this.productForm.controls;
  }
 
  Clearformhide() {
    this.showEditForm = !this.showEditForm;
    this.bannerfileSrc = '';
    this.clearForm();
  }

 
  getCategoryList() {
    const url = `Category/GetAll`;
    this.apiservice.getData(url).subscribe((response: ResponseModel<any[]>) => {
      if (response.status === HttpStatusCode.OK) {
        this.categoryListForDD = (response.data as Array<any>).slice(
          0,
          this.itemPerPage
        );
        console.log(this.categoryListForDD);
      }
    });
  }

  getProdList() {
    const url = `Product/GetAll?Pagesize=0&Pageno=0`;
    this.apiservice.getData(url).subscribe((response: ResponseModel<any>) => {
      if (response.status === HttpStatusCode.OK) {
        this.copyProductList = response.data.product;
        this.prodList = (response.data.product as Array<any>).slice(
          0,
          this.itemPerPage
        );
        this.copyProductList = response.data.product;
      }
    });
  }

  getActiveCourseList() {
    const url = `Course/GetActive?Pagesize=0&Pageno=0`;
    this.apiservice.getData(url).subscribe((response: ResponseModel<any>) => {
      if (response.status === HttpStatusCode.OK) {
        this.courseListDD = response.data.getCourse;
      }
    });
  }

  setValueToForm(item) {
    
    this.showEditForm = true;
    this.id = item.id;
    this.isUpdate = true; 
    this.productForm.controls.categoryId.setValue(item.categoryId); 
    this.productForm.controls.active.setValue(item.active);
    this.productForm.controls.discription.setValue(item.discription);
    this.productForm.controls.discriptionHn.setValue(item.discriptionHn);
    this.productForm.controls.discriptionMr.setValue(item.discriptionMr);
    this.productForm.controls.mrp.setValue(item.mrp);
    this.productForm.controls.price.setValue(item.price); 

    if (item.imageUrl != null || item.imageUrl !== undefined || item.imageUrl !== '') {
      this.bannerfileSrc = item.imageUrl;
    }
    if (
      item.imageUrl != null ||
      item.imageUrl !== undefined ||
      item.imageUrl !== ''
    ) {
      this.bannerfileSrc = item.imageUrl;
    }
  }
  pageChanged(event) {
    const startItem = (event.page - 1) * event.itemsPerPage;
    const endItem = event.page * event.itemsPerPage;

    this.prodList = this.copyProductList.slice(startItem, endItem);

    this.currentPage = event.page;
  }

  addUpdateProduct() {
    const data: IProduct = {
      id: this.id,
      nameEng: this.productForm.value.nameEng,
      nameMar: this.productForm.value.nameMar,
      nameHin: this.productForm.value.nameHin,
      price: this.productForm.value.price,
      active: this.productForm.value.active,
      imageUrl: '',
      imageBase64: this.bannerfileStr,
      discription: this.productForm.value.discription,
      discriptionHn: this.productForm.value.discriptionHn,
      discriptionMr: this.productForm.value.discriptionMr,
      mrp: this.productForm.value.mrp, 
      categoryId: +this.productForm.value.categoryId,
      weight:this.productForm.value.weight
    };

    if (this.productForm.valid && this.bannerfileSrc !== '') {
      this.imageIsempty = false;
      this.isSaveDisabled = true;
      let apiurl = '';
      if (this.id === 0) {
        apiurl = `Product/AddAsync`;
      } else {
        apiurl = `Product/UpdateAsync`;
      }
      this.apiservice
        .postData(apiurl, data)
        .subscribe((response: ResponseModel<ICategory>) => {
          if (response.status === HttpStatusCode.OK) {
            this.imageIsempty = false;
            this.isSaveDisabled = false;
            if (this.id === 0) {
              this.showToast('success', 'Added Successfully');
            } else {
              this.showToast('success', 'Updated Successfully');
            }
            this.productForm.reset();
            this.submitted = false;
            this.getProdList();
            this.clearForm();
            this.bannerfileStr = '';
            this.id = 0;
            this.isUpdate = true;
          } else {
            if (response.status === 400) {
              this.showToast('', response.statusMessage);
              this.isSaveDisabled = false;
            }
            this.isSaveDisabled = false;
            this.id = 0;
            this.isUpdate = false;
          }
        });
    } else {
      if (this.bannerfileSrc === '') {
        this.imageIsempty = true;
      } else {
        this.imageIsempty = false;
      }
    }
  }
  showToast(status, message) {
    this.toastr.success(`${message}`, `${status}`);
  }

  validation() {
    this.submitted = true;
  }
  onFileSelect(input: HTMLInputElement): void {
    function formatBytes(bytes: number): string {
      const UNITS = ['Bytes', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
      const factor = 1024;
      let index = 0;
      while (bytes >= factor) {
        bytes /= factor;
        index++;
      }
      return `${parseFloat(bytes.toFixed(2))} ${UNITS[index]}`;
    }
    this.file = input.files[0];
    this.fileInfo = `${this.file['name']} (${formatBytes(this.file.size)})`;
  }

  filter(str: string) {
    str = str.trim();
    if (str !== '') {
      this.prodList = this.copyProductList.filter((item) => {
        const name = String(item.nameEng).toLocaleLowerCase();
        const searchStr = String(str).toLowerCase();
        return name.startsWith(searchStr);
      });
    } else {
      this.prodList = (this.copyProductList as Array<any>).slice(
        0,
        this.itemPerPage
      );
    }
  }
}

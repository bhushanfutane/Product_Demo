import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { HttpStatusCode, ResponseModel } from '../../shared/responsemodel';
import { ApiDataService } from '../../shared/services/apidata.service';

@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css']
})
export class RoleComponent implements OnInit {

  copyroleList: any[] = [];
  roleList = [];
  itemPerPage = 10;
  showEditForm = false;
  submitted = false;
  roleForm: FormGroup;
  isSaveDisabled = false;
  currentPage = 1;
  id = 0;
  constructor(
    private apiservice: ApiDataService,
    private fb: FormBuilder,
    private toastr: ToastrService
  ) {
    this.roleForm = this.fb.group({
      name: ['', [Validators.required]],
      isDelete: [false],
    });
  }

  ngOnInit(): void {
    this.getRole();
  }
  getRole() {
    const url = `Role/GetAllRoleList`;
    this.apiservice.getData(url).subscribe((response: ResponseModel<any[]>) => {
      if (response.status === HttpStatusCode.OK) {
        this.copyroleList = response.data;
        this.roleList = (response.data as Array<any>).slice(
          0,
          this.itemPerPage
        );
      }
    });
  }
  filter(str: string) {
    str = str.trim();
    if (str !== '') {
      this.roleList = this.copyroleList.filter((item) => {
        const name = String(item.name).toLocaleLowerCase();
        const searchStr = String(str).toLowerCase();
        return name.startsWith(searchStr);
      });
    } else {
      this.roleList = (this.copyroleList as Array<any>).slice(
        0,
        this.itemPerPage
      );
    }
  }
  get f() {
    return this.roleForm.controls;
  }
  setValueToForm(role) {
    this.showEditForm = true;
    this.id = role.id;
    this.roleForm.controls.name.setValue(role.name),
      this.roleForm.controls.isDelete.setValue(role.isActive);
  }
  clearForm() {
    this.id = 0;
    this.roleForm.reset();
    this.showEditForm = false;
    this.submitted = false;
  }
  showToast(status, message) {
    this.toastr.success(`${message}`, `${status}`);
  }
  isNumber(evt) {
    evt = evt ? evt : window.Event;
    const charCode = evt.which ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  addRole() {
    this.submitted = true;
    const data = {
      id: this.id,
      name: this.roleForm.value.name,
      isActive: this.roleForm.value.isDelete,
    };
    if (this.roleForm.valid) {
      this.isSaveDisabled = true;
      let apiUrl = '';
      if (this.id === 0) {
        apiUrl = `Role/AddRoles`;
      } else {
        apiUrl = `Role/UpdateRoles`;
      }
      this.apiservice
        .postData(apiUrl, data)
        .subscribe((response: ResponseModel<[]>) => {
          if (response.status === HttpStatusCode.OK) {
            this.isSaveDisabled = false;
            if (this.id === 0) {
              this.showToast('success', 'Added Successfully');
            } else {
              this.showToast('success', 'Updated Successfully');
            }
            this.roleForm.reset();
            this.submitted = false;
            this.getRole();
            this.clearForm();
            this.id = 0;
          } else {
            if (response.status === 400) {
              this.showToast('', response.statusMessage);
              this.isSaveDisabled = false;
            }
            this.isSaveDisabled = false;
            this.id = 0;
          }
        });
    }
  }
  validation() {
    this.submitted = true;
  }
  pageChanged(event) {
    const startItem = (event.page - 1) * event.itemsPerPage;
    const endItem = event.page * event.itemsPerPage;

    this.roleList = this.copyroleList.slice(startItem, endItem);

    this.currentPage = event.page;
  }

  deleteRole(role) {
    const url = `Role/DeleteRoles?Id=${role.id}`;
    this.apiservice.getData(url).subscribe(
      (response: ResponseModel<[]>) => {
        if (response.status === HttpStatusCode.OK) {
          this.showToast('Role Deleted', '');
          this.getRole();
        } else {
          this.showToast(`${response.statusMessage}`, '');
        }
      },
      (err) => {
        throw new Error(`${err.error.statusMessage}`);
      }
    );
  }
  Clearformhide() {
    this.showEditForm = !this.showEditForm;
    this.clearForm();
  }
}

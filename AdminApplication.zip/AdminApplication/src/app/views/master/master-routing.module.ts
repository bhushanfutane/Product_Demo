import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BannerComponent } from './banner/banner.component';
import { CategoryComponent } from './category/category.component';
import { CityComponent } from './city/city.component';
import { CousreDetailsComponent } from './cousre-details/cousre-details.component';
import { DeliveryComponent } from './delivery/delivery.component';
import { OrderStatusComponent } from './order-status/order-status.component';
import { ProductComponent } from './product/product.component';
import { SocialComponent } from './social/social.component';
import { SubCategoryComponent } from './sub-category/sub-category.component';
import { UsersComponent } from './users/users.component';
import { VediocourseComponent } from './vediocourse/vediocourse.component';
import { VideosComponent } from './videos/videos.component';

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Master'
    },
    children: [
      {
        path: '',
        redirectTo: 'city',
      },
      {
        path: 'city',
        component: CityComponent,
        data: {
          title: 'City'
        },
      },
      {
        path: 'category',
        component: CategoryComponent,
        data: {
          title: 'Category'
        },
      },
      {
        path: 'users',
        component: UsersComponent,
        data: {
          title: 'Users'
        },
      },
      {
        path: 'videos/:id',
        component: VideosComponent,
        data: {
          title: 'Videos'
        },
      },
      {
        path: 'videos',
        component: VideosComponent,
        data: {
          title: 'Videos'
        },
      },
      {
        path: 'videocourse',
        component: VediocourseComponent,
        data: {
          title: 'VideoCourse'
        },
      },
      {
        path: 'videocourse',
        component: VediocourseComponent,
        data: {
          title: 'VideoCourse'
        },
      }, 
      {
        path: 'order_status',
        component: OrderStatusComponent,
        data: {
          title: 'Order_status'
        },
      },
      {
        path: 'course',
        component: CousreDetailsComponent,
        data: {
          title: 'Course'
        },
      },
      {
        path: 'delivery',
        component: DeliveryComponent,
        data: {
          title: 'Delivery'
        },
      },
      {
        path: 'banner',
        component: BannerComponent,
        data: {
          title: 'Banner'
        }
      },
      {
        path: 'product',
        component: ProductComponent,
        data: {
          title: 'Product'
        }
      },
      {
        path: 'social',
        component: SocialComponent,
        data: {
          title: 'Social'
        }
      },

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MasterRoutingModule { }

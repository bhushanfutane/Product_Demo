import { Component, OnInit } from '@angular/core';
import { HttpStatusCode, ResponseModel } from '../../../shared/responsemodel';
import { ApiDataService } from '../../../shared/services/apidata.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  userlist: any;
  copyuserlist: any;
  totalItems: number = 1;
  bigTotalItems: number = 675;
  bigCurrentPage: number = 1;
  numPages: number = 0;
  currentPager: number = 4;
  currentPage = 1;
  itemPerPage = 10;
  showEditForm =false;
  setPage(pageNo: number): void {
    this.currentPage = pageNo;
  }
  constructor(
    private apiservice: ApiDataService,
  ) { }

  ngOnInit(): void {
    this.getUserList();
  }

  


  getUserList() {
    const url = `User/GetUserList`;
    this.apiservice.getData(url).subscribe((response: ResponseModel<any>) => {
      if (response.status === HttpStatusCode.OK) {
        this.copyuserlist = response.data.users;
        this.userlist = response.data.users;
        this.userlist = (response.data.users as Array<any>).slice(
          0,
          this.itemPerPage
        );
        this.copyuserlist = response.data.users;
      }
    });
  }

  pageChanged(event) {
    const startItem = (event.page - 1) * event.itemsPerPage;
    const endItem = event.page * event.itemsPerPage;

    this.userlist = this.copyuserlist.slice(startItem, endItem);

    this.currentPage = event.page;
  }

  filter(str: string) {
    str = str.trim();
    if (str !== '') {
      this.userlist = this.copyuserlist.filter((item) => {
        const name = String(item.fullName).toLocaleLowerCase();
        const searchStr = String(str).toLowerCase();
        return name.startsWith(searchStr);
      });
    } else {
      this.userlist = (this.copyuserlist as Array<any>).slice(
        0,
        this.itemPerPage
      );
    }
  }
}

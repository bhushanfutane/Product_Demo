import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ICategory, ISubCategory } from '../../../shared/model';
import { ResponseModel, HttpStatusCode } from '../../../shared/responsemodel';
import { ApiDataService } from '../../../shared/services/apidata.service';

@Component({
  selector: 'app-sub-category',
  templateUrl: './sub-category.component.html',
  styleUrls: ['./sub-category.component.css']
})
export class SubCategoryComponent implements OnInit {

  subCategoryForm: FormGroup;
  submitted = false;
  categoryList = [];
  categoryListForDD = [];
  copySubCategoryList: any[] = [];
  isUpdate = false;
  pageSize = 100;
  pageNumber = 1;
  isSaveDisabled = false;
  pageRole: any;
  roleId: number;
  saveBtnHideForRole = true;
  // file: File;
  bannerfile: File;
  bannerfileSrc = '';
  bannerfileStr = '';
  Id = 0;
  imagePreview: string | ArrayBuffer;
  file: any;
  showEditForm = false;
  id = 0;
  totalItems: number = 1;
  bigTotalItems: number = 675;
  bigCurrentPage: number = 1;
  numPages: number = 0;
  currentPager: number = 4;
  currentPage = 1;
  itemPerPage = 10;
  fileInfo: string;
  imageIsempty = false;

  setPage(pageNo: number): void {
    this.currentPage = pageNo;
  }

  constructor(
    private apiservice: ApiDataService,
    private toastrService: ToastrService,
    private apidataservice: ApiDataService,
    private fb: FormBuilder,
    private toastr: ToastrService
  ) {
    this.subCategoryForm = this.fb.group({
      categoryId: ['', [Validators.required]],
      categoryNameEng: ['', [Validators.required]],
      categoryNameMar: ['', [Validators.required]],
      categoryNameHin: ['', [Validators.required]],
      isActive: [false],
      discription: ['', [Validators.required]],
    });
  }

  ngOnInit() {
    this.getSubCategoryList();
    this.getCategoryList();
  }

  async onselectBannerImages(event) {
    this.bannerfile = event.target.files[0];
    const file64 = await this.apidataservice.toBase64(this.bannerfile);
    this.bannerfileSrc = file64;
    this.bannerfileStr = file64.split(',')[1];
    this.imageIsempty = false;
  }
  clearForm() {
    this.id = 0;
    this.subCategoryForm.reset();
    this.showEditForm = false;
    this.bannerfileSrc = '';
    this.submitted = false;
  }
  get f() {
    return this.subCategoryForm.controls;
  }
  addCategory() {
    this.submitted = true;
  }
  Clearformhide() {
    this.showEditForm = !this.showEditForm;
    this.bannerfileSrc = '';
    this.clearForm();
  }

  getCategoryList() {
    const url = `Category/GetAll`;
    this.apiservice.getData(url).subscribe((response: ResponseModel<any[]>) => {
      if (response.status === HttpStatusCode.OK) {
        this.categoryListForDD = (response.data as Array<any>).slice(
          0,
          this.itemPerPage
        );
        console.log(this.categoryListForDD);
      }
    });
  }

  getSubCategoryList() {
    const url = `Category/GetSubAll`;
    this.apiservice.getData(url).subscribe((response: ResponseModel<any[]>) => {
      if (response.status === HttpStatusCode.OK) {
        this.copySubCategoryList = response.data;
        this.categoryList = (response.data as Array<any>).slice(
          0,
          this.itemPerPage
        );
        this.copySubCategoryList = response.data;
      }
    });
  }

  setValueToForm(category) {
    this.showEditForm = true;
    this.id = category.id;
    this.isUpdate = true;
    this.subCategoryForm.controls.categoryId.setValue(category.id);
    this.subCategoryForm.controls.categoryNameEng.setValue(category.nameEng);
    this.subCategoryForm.controls.categoryNameMar.setValue(category.nameMar);
    this.subCategoryForm.controls.categoryNameHin.setValue(category.nameHin);
    this.subCategoryForm.controls.isActive.setValue(category.active);
    this.subCategoryForm.controls.discription.setValue(category.nameHin);

    if (category.imagePath != null || category.imagePath !== undefined || category.imagePath !== '') {
      this.bannerfileSrc = category.imagePath;
    }
    if (
      category.imagePath != null ||
      category.imagePath !== undefined ||
      category.imagePath !== ''
    ) {
      this.bannerfileSrc = category.imagePath;
    }
  }
  pageChanged(event) {
    const startItem = (event.page - 1) * event.itemsPerPage;
    const endItem = event.page * event.itemsPerPage;

    this.categoryList = this.copySubCategoryList.slice(startItem, endItem);

    this.currentPage = event.page;
  }

  addUpdateSubCategory() {
    const data: ISubCategory = {
      id: this.id,
      categoryId: +this.subCategoryForm.value.categoryId,
      nameEng: this.subCategoryForm.value.categoryNameEng,
      nameMar: this.subCategoryForm.value.categoryNameMar,
      nameHin: this.subCategoryForm.value.categoryNameHin,
      imagePath: '',
      imageBase64: this.bannerfileStr,
      active: this.subCategoryForm.value.isActive,
      discription: this.subCategoryForm.value.discription,
    };

    if (this.subCategoryForm.valid && this.bannerfileSrc !== '') {
      this.imageIsempty = false;
      this.isSaveDisabled = true;
      let apiurl = '';
      if (this.id === 0) {
        apiurl = `Category/AddSubAsync`;
      } else {
        apiurl = `Category/UpdateSubAsync`;
      }
      this.apiservice
        .postData(apiurl, data)
        .subscribe((response: ResponseModel<ICategory>) => {
          if (response.status === HttpStatusCode.OK) {
            this.imageIsempty = false;
            this.isSaveDisabled = false;
            if (this.id === 0) {
              this.showToast('success', 'Added Successfully');
            } else {
              this.showToast('success', 'Updated Successfully');
            }
            this.subCategoryForm.reset();
            this.submitted = false;
            this.getSubCategoryList();
            this.clearForm();
            this.bannerfileStr = '';
            this.id = 0;
            this.isUpdate = true;
          } else {
            if (response.status === 400) {
              this.showToast('', response.statusMessage);
              this.isSaveDisabled = false;
            }
            this.isSaveDisabled = false;
            this.id = 0;
            this.isUpdate = false;
          }
        });
    } else {
      if (this.bannerfileSrc === '') {
        this.imageIsempty = true;
      } else {
        this.imageIsempty = false;
      }
    }
  }
  showToast(status, message) {
    this.toastr.success(`${message}`, `${status}`);
  }

  validation() {
    this.submitted = true;
  }
  onFileSelect(input: HTMLInputElement): void {
    function formatBytes(bytes: number): string {
      const UNITS = ['Bytes', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
      const factor = 1024;
      let index = 0;
      while (bytes >= factor) {
        bytes /= factor;
        index++;
      }
      return `${parseFloat(bytes.toFixed(2))} ${UNITS[index]}`;
    }
    this.file = input.files[0];
    this.fileInfo = `${this.file['name']} (${formatBytes(this.file.size)})`;
  }

  filter(str: string) {
    str = str.trim();
    if (str !== '') {
      this.categoryList = this.copySubCategoryList.filter((item) => {
        const name = String(item.nameEng).toLocaleLowerCase();
        const searchStr = String(str).toLowerCase();
        return name.startsWith(searchStr);
      });
    } else {
      this.categoryList = (this.copySubCategoryList as Array<any>).slice(
        0,
        this.itemPerPage
      );
    }
  }
}

export const environment = {
  production: true, 
 apiurl:'http://agriapi.knackbe.in/api/'


};

﻿ 

USE [Product]
GO
/****** Object:  User [admin]    Script Date: 22-Sep-21 6:04:45 PM ******/
CREATE USER [admin] FOR LOGIN [admin] WITH DEFAULT_SCHEMA=[dbo]
GO
ALTER ROLE [db_owner] ADD MEMBER [admin]
GO
/****** Object:  Table [dbo].[tblAdminUser]    Script Date: 22-Sep-21 6:04:45 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblAdminUser](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [nvarchar](50) NULL,
	[LastName] [nvarchar](50) NULL,
	[UserName] [nvarchar](50) NULL,
	[Email] [nvarchar](50) NULL,
	[IsVerify] [bit] NULL,
	[MobileNo] [nvarchar](15) NULL,
	[Address] [nvarchar](500) NULL,
	[Password] [nvarchar](100) NULL,
	[Otp] [nchar](10) NULL,
	[OtpExpireTime] [datetime] NULL,
	[RegistrationDate] [date] NULL,
	[CreatedBy] [int] NULL,
	[CreatedDate] [datetime] NULL,
	[IsActive] [bit] NULL,
	[IsDelete] [bit] NULL,
	[ProfilePath] [nvarchar](50) NULL,
	[UpdatedBy] [int] NULL,
	[UpdatedDate] [datetime] NULL,
 CONSTRAINT [PK_AdminUser] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
  
/****** Object:  Table [dbo].[tblCategory]    Script Date: 22-Sep-21 6:04:50 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblCategory](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name_ENG] [nvarchar](50) NOT NULL,
	[Name_MAR] [nvarchar](50) NOT NULL,
	[Name_HIN] [nvarchar](50) NOT NULL,
	[ImagePath] [nvarchar](50) NULL,
	[Active] [bit] NOT NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [int] NULL,
	[UpdatedDate] [datetime] NULL,
	[UpdatedBy] [int] NULL,
 CONSTRAINT [PK_tblCategory] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tblCourse]    Script Date: 22-Sep-21 6:04:51 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblCourse](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CourseEN] [nvarchar](50) NULL,
	[CourseMR] [nvarchar](50) NULL,
	[CourseHI] [nvarchar](50) NULL,
	[Discription] [nvarchar](2050) NULL,
	[DiscriptionHn] [nvarchar](2050) NULL,
	[DiscriptionMr] [nvarchar](2050) NULL,
	[IsActive] [bit] NULL,
	[Price] [decimal](18, 2) NULL,
	[ValidityInDays] [int] NULL,
	[Language] [int] NULL,
	[CreatedBy] [int] NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedBy] [int] NULL,
	[UpdatedDate] [datetime] NULL,
	[ImagePath] [nvarchar](50) NULL,
	[VideoUrl] [nvarchar](50) NULL,
 CONSTRAINT [PK_tblCourse] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tblExceptionLogItems]    Script Date: 22-Sep-21 6:04:53 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblExceptionLogItems](
	[EventId] [int] IDENTITY(1,1) NOT NULL,
	[LogDateTime] [datetime] NULL,
	[Source] [nvarchar](max) NULL,
	[Message] [varchar](1000) NULL,
	[QueryString] [varchar](2000) NULL,
	[TargetSite] [varchar](300) NULL,
	[StackTrace] [varchar](4000) NULL,
	[ServerName] [varchar](250) NULL,
	[RequestURL] [varchar](300) NULL,
	[UserAgent] [varchar](300) NULL,
	[UserIP] [varchar](300) NULL,
	[UserAuthentication] [varchar](300) NULL,
	[UserName] [varchar](300) NULL,
 CONSTRAINT [PK_tblExceptionLogItems] PRIMARY KEY CLUSTERED 
(
	[EventId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
 
/****** Object:  Table [dbo].[tblProduct]    Script Date: 22-Sep-21 6:04:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblProduct](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name_ENG] [nvarchar](100) NOT NULL,
	[Name_MAR] [nvarchar](100) NOT NULL,
	[Name_HIN] [nvarchar](100) NOT NULL,
	[Price] [decimal](8, 2) NULL,
	[Active] [bit] NOT NULL,
	[CreatedBy] [int] NULL,
	[CreatedDate] [datetime] NULL,
	[ImageUrl] [nvarchar](100) NULL,
	[Discription] [nvarchar](2000) NULL,
	[Discription_Hn] [nvarchar](2000) NULL,
	[Discription_Mr] [nvarchar](2000) NULL,
	[MRP] [decimal](18, 2) NULL,
	[UpdatedDate] [datetime] NULL,
	[UpdatedBy] [int] NULL,
	[Weight] [decimal](5, 3) NULL,
	[CategoryId] [int] NULL,
 CONSTRAINT [PK_tblProduct] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tblProSet]    Script Date: 22-Sep-21 6:05:00 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblProSet](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](250) NOT NULL,
	[SettingKey] [nvarchar](250) NOT NULL,
	[SettingValue] [nvarchar](250) NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [int] NULL,
	[UpdatedDate] [datetime] NULL,
	[UpdatedBy] [int] NULL,
	[Description] [nvarchar](500) NULL,
 CONSTRAINT [PK_tblProSet] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
 
/****** Object:  Table [dbo].[tblSubCategory]    Script Date: 22-Sep-21 6:05:04 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblSubCategory](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CategoryId] [int] NULL,
	[Name_ENG] [nvarchar](50) NULL,
	[Name_MAR] [nvarchar](50) NULL,
	[Name_HIN] [nvarchar](50) NULL,
	[ImagePath] [nvarchar](100) NULL,
	[Active] [bit] NULL,
	[Discription] [nvarchar](500) NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [int] NULL,
	[UpdatedDate] [datetime] NULL,
	[UpdatedBy] [int] NULL,
 CONSTRAINT [PK_tblSubCategory] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
 
/****** Object:  Table [dbo].[TblUser]    Script Date: 22-Sep-21 6:05:09 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TblUser](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[FullName] [nvarchar](50) NULL,
	[Email] [nvarchar](50) NULL,
	[Mobile] [nvarchar](15) NULL,
	[IsMobileVerified] [bit] NULL,
	[Password] [nvarchar](50) NULL,
	[Otp] [nvarchar](10) NULL,
	[OtpExpiredTime] [datetime] NULL,
	[IsOtpVerified] [bit] NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[CreatedBy] [int] NULL,
	[UpdatedBy] [int] NULL,
	[IsActive] [bit] NULL,
	[ReferCode] [nvarchar](20) NULL,
	[ReferId] [int] NULL,
	[ProfilePath] [nvarchar](50) NULL,
 CONSTRAINT [PK_TblUser1] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tblUserAddress]    Script Date: 22-Sep-21 6:05:12 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblUserAddress](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[HouseNo] [nvarchar](100) NULL,
	[AppartmentName] [nvarchar](100) NULL,
	[StreetDetails] [nvarchar](200) NULL,
	[Landmark] [nvarchar](250) NULL,
	[AreaName] [nvarchar](50) NULL,
	[Pincode] [nvarchar](10) NULL,
	[Contact] [nvarchar](15) NULL,
	[AddressType] [int] NULL,
	[niknameAddress] [nvarchar](150) NULL,
	[Isdefault] [bit] NULL,
	[CreatedDate] [datetime] NULL,
	[CreatedBy] [int] NULL,
	[UpdatedDate] [datetime] NULL,
	[UpdatedBy] [int] NULL,
	[City] [nvarchar](50) NULL,
 CONSTRAINT [PK_tblUserAddress] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
 
SET IDENTITY_INSERT [dbo].[tblAdminUser] ON 
GO
 
INSERT [dbo].[tblAdminUser] ([Id], [FirstName], [LastName], [UserName], [Email], [IsVerify], [MobileNo], [Address], [Password], [Otp], [OtpExpireTime], [RegistrationDate], [CreatedBy], [CreatedDate], [IsActive], [IsDelete], [ProfilePath], [UpdatedBy], [UpdatedDate]) VALUES (3, N'Gauri', N'Patil', N'9922051232', N'string', 1, N'9922051232', N'Karad', N'BhVNviA0q7ERN5Un3AzIPg==', NULL, NULL, CAST(N'2021-08-11' AS Date), 1, CAST(N'2021-08-11T09:28:01.110' AS DateTime), 1, 0, NULL, NULL, NULL)
GO
INSERT [dbo].[tblAdminUser] ([Id], [FirstName], [LastName], [UserName], [Email], [IsVerify], [MobileNo], [Address], [Password], [Otp], [OtpExpireTime], [RegistrationDate], [CreatedBy], [CreatedDate], [IsActive], [IsDelete], [ProfilePath], [UpdatedBy], [UpdatedDate]) VALUES (4, N'Arjun', N'Patil', N'9096488670', N'arjun@gmail.com', 1, N'9096488670', N'Karad', N'BhVNviA0q7ERN5Un3AzIPg==', NULL, NULL, CAST(N'2021-09-03' AS Date), 0, CAST(N'2021-09-03T12:16:54.743' AS DateTime), 1, 0, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[tblAdminUser] OFF
GO

 
SET IDENTITY_INSERT [dbo].[tblCategory] ON 
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (1, N'crop-protection', N'पीक संरक्षण ', N'फसल सुरक्षा', N'/Category/crop_protection_2.jpeg', 1, CAST(N'2021-08-23T06:41:24.590' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (2, N'FORAGESs', N'चारा', N'पशुग्रास ', N'/Category/FORAGES_8.jpeg', 1, CAST(N'2021-08-23T08:51:15.407' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (3, N'ROUNDUP', N'खत ', N'बढ़ाना', N'/Category/ROUNDUP_3.jpeg', 1, CAST(N'2021-08-23T06:33:17.653' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (4, N'Farm Animal', N'शेत पशु', N'खेत के जानवर', N'/Category/Farm_Animal_8.jpeg', 1, CAST(N'2021-08-23T06:29:31.643' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (5, N'Machinary', N'यंत्रसामग्री', N'मशीनरी', N'/Category/Machinary_8.jpeg', 1, CAST(N'2021-08-23T06:28:26.223' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (6, N'Crop Nutrition', N'पीक पोषण', N'पादप पोषण', N'/Category/Crop_Nutrition_6.jpeg', 1, CAST(N'2021-08-23T06:44:58.973' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (7, N'Crop Protection', N'पीक संरक्षण', N'फसल सुरक्षा', N'/Category/Crop_Protection_5.jpeg', 1, CAST(N'2021-08-23T06:25:30.127' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (8, N'Seeds', N'बियाणे', N'बीज', N'/Category/Seeds_2.jpeg', 1, CAST(N'2021-08-23T06:20:59.837' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (9, N'Commercial Plantation', N'व्यावसायिक वृक्षारोपण', N'व्यावसायिक खेती', N'/Category/Commercial_Plantation_4.jpeg', 1, CAST(N'2021-09-15T09:41:02.437' AS DateTime), 4, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (10, N'Crop plant', N'पीक वनस्पती', N'फसल का पौधा', N'/Category/Crop_plant_0.jpeg', 1, CAST(N'2021-09-15T09:39:51.940' AS DateTime), 4, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (11, N'Mango Trees', N'आंब्याची झाडे', N'आम के पेड़', N'/Category/Mango_Trees_5.jpeg', 1, CAST(N'2021-09-15T09:39:16.700' AS DateTime), 2, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (12, N'Sugar kane', N'ऊस', N'गन्ना', N'/Category/Sugar_kane_2.jpeg', 1, CAST(N'2021-08-23T05:57:15.807' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (13, N'hgfh', N'gfgfgh', N'fghhgf', N'/Category/hgfh_2.jpeg', 1, CAST(N'2021-08-13T09:07:22.210' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (14, N'Soyabean', N'सोयाबीन बिया', N'सोयाबीन', N'/Category/Soyabean_5.jpeg', 1, CAST(N'2021-09-03T06:48:24.457' AS DateTime), 2, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (15, N'Tomato seed', N' टोमॅटो बी', N'टमाटर बीज', N'/Category/Tomato_seed_3.jpeg', 1, CAST(N'2021-08-23T05:49:34.207' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (16, N'Capsicum', N'शिमला मिर्ची', N'शिमला मिर्च', N'/Category/Capsicum_5.jpeg', 1, CAST(N'2021-08-23T06:12:55.330' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (17, N'Peas', N'वाटाणा', N' मटर', N'/Category/Peas_2.jpeg', 1, CAST(N'2021-09-03T07:01:49.140' AS DateTime), 2, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (18, N'Bitter gourd seed', N'कारले बी', N'करेले के बीज', N'/Category/Bitter_gourd_seed_6.jpeg', 1, CAST(N'2021-08-23T06:09:37.583' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (19, N'Tomato', N'टोमॅटो', N'टमाटर', N'/Category/Tomato_1.jpeg', 1, CAST(N'2021-08-23T06:04:04.987' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (20, N'Onion 🧅', N'कांदा', N'प्याज', N'/Category/Onion__7.jpeg', 1, CAST(N'2021-08-23T06:02:20.207' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (21, N'pumpkin', N'भोपळा', N'कद्दू', N'/Category/pumpkin_6.jpeg', 1, CAST(N'2021-09-03T07:00:53.440' AS DateTime), 2, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (22, N'Bhopala', N'भोपळा', N'कद्दू', N'/Category/bopala_2.jpeg', 1, CAST(N'2021-08-23T06:01:16.990' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (23, N'Sugarcane ', N'ऊस', N'गन्ना', N'/Category/Sugarcane__6.jpeg', 1, CAST(N'2021-08-23T05:58:28.820' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (24, N'Industrialized Agriculture', N'औद्योगिक शेती', N'औद्योगीकृत कृषि', N'/Category/Industrialized_Agriculture_3.jpeg', 1, CAST(N'2021-09-03T06:59:39.380' AS DateTime), 2, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (25, N'Drumstick', N'शेवग्याची शेंग', N'शेवग्याची शेंग', N'/Category/Drumstick_5.jpeg', 1, CAST(N'2021-09-13T07:39:26.597' AS DateTime), 2, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (26, N'Mashroom', N'मशरूम', N'मशरूम', N'/Category/Mashroom_8.jpeg', 1, CAST(N'2021-09-13T07:31:02.250' AS DateTime), 2, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (27, N'Capsicum', N'शिमला मिर्ची', N'शिमला मिर्च', N'/Category/hghj_4.jpeg', 1, CAST(N'2021-09-15T04:57:30.413' AS DateTime), 2, NULL, NULL)
GO
INSERT [dbo].[tblCategory] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (28, N'Bitroot', N'बीट', N'चुकंदर', N'/Category/Bitroot_0.jpeg', 1, CAST(N'2021-09-15T05:27:04.900' AS DateTime), 2, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[tblCategory] OFF
GO
SET IDENTITY_INSERT [dbo].[tblCourse] ON 
GO
INSERT [dbo].[tblCourse] ([Id], [CourseEN], [CourseMR], [CourseHI], [Discription], [DiscriptionHn], [DiscriptionMr], [IsActive], [Price], [ValidityInDays], [Language], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate], [ImagePath], [VideoUrl]) VALUES (16, N'Sugar Cane', N'Sugar Cane', N'Sugar Cane', N'UG course ', N'UG course in Agriculture', N'UG course in Agriculture', 1, CAST(500.00 AS Decimal(18, 2)), 50, 1, 1, CAST(N'2021-06-15T11:20:59.793' AS DateTime), 4, CAST(N'2021-09-15T12:56:37.340' AS DateTime), N'/Course/UG_course_in_Agriculture_2.jpeg', N'https://www.youtube.com/watch?v=OzkX2qX82xw')
GO
INSERT [dbo].[tblCourse] ([Id], [CourseEN], [CourseMR], [CourseHI], [Discription], [DiscriptionHn], [DiscriptionMr], [IsActive], [Price], [ValidityInDays], [Language], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate], [ImagePath], [VideoUrl]) VALUES (17, N'Tomato', N'टोमॅटो', N'टमाटर', N'The tomato is the edible, often red, berry of the plant Solanum lycopersicum, commonly known as a tomato plant. The species originated in western South America and Central America. The Nahuatl (Aztec language) word tomatl gave rise to the Spanish word tomate, from which the English word tomato derived. ', N'यह आर्टिकल Tomato Information In Hindi टमाटर खाने के फायदे (Benefits Of Tomato In Hindi), नुकसान और जानकारी (About Tomato In Hindi) पर आधारित है। टमाटर एक सब्जी और फल दोनों ही है। टमाटर खाने के ढेरों फायदे है। कई प्रकार के रोगों में डॉक्टर टमाटर खाने की सलाह देते है। वैसे टमाटर खाने के कुछ नुकसान भी होते है। टमाटर खाने के फायदे (Tamatar Khane Ke Fayde) और नुकसान पर इस पोस्ट में बताने का प्रयास है।', N'टोमॅटो ही एक फळभाजी आहे हे खूप छान आहेत पण मग. पण काय करणार आहेत पण गोड म्हणुन . मराठीत या फळाला टोमॅटो, भेदरे किंवा बेलवांगे म्हणतात. ब्रिटीशकाळात टोमॅटोला ''तांबेटे'' असेही म्हटले जात. संस्कृतमध्ये याला हिण्डीरः, रक्तमाचे व रक्तवृत्नाक असे शब्द वापरले जातात. टोमॅटोत भरपूर मात्रा मध्ये कैल्शियम, फास्फोरस व विटामिन सी असते. एसिडिटी ची तक्रार असल्यास टोमॅटो ची खुराक वाढविल्याने ही तक्रार दूर होते.[कृपया उद्धरण जोड़ें] टोमॅटो चा स्वाद अम्लीय (खट्टा) असतो पण हे शरीरात क्षारीय (खारी) प्रतिक्रियांना जन्म देते. लाल-लाल टोमॅटो पाहायला सुन्दर आणि खाण्यात स्वादिष्ट तसेच पौष्टिक पण असते. याच्या आंबट स्वाद चे कारण है आहे की यात साइट्रिक एसिड आणि मैलिक एसिड असते ज्या मुळे हे प्रत्यम्ल (एंटासिड) च्या रूपात काम करते. टोमॅटो मध्ये विटामिन ''ए'' मोठ्या प्रमाणात उपलब्ध असते. हे डोळ्यांसाठी खूप लाभकारी आहे तसेच टोमॅटो या फळातील रंगद्रव्य लाल रंगांच्या टोमॅटो च्या तुलनेत नारंगी रंगाच्या टोमॅटो मध्ये लायकोपिन हे रंगद्रव्य शरीरात सहजरुपात शोषित होते. लाल रंगाच्या टोमॅटो मध्ये लायकोपिन हे रंगद्रव्य टेत्रा-सिस्(?) मध्ये उपलब्ध होते हे शरीरात सहजरुपाने अवशोषित होत नाही.', 1, CAST(440.00 AS Decimal(18, 2)), 44, 1, 1, CAST(N'2021-08-17T07:19:58.857' AS DateTime), 2, CAST(N'2021-09-15T05:59:22.720' AS DateTime), N'/Course/Tomato_0.jpeg', N'https://www.youtube.com/watch?v=OzkX2qX82xw')
GO
INSERT [dbo].[tblCourse] ([Id], [CourseEN], [CourseMR], [CourseHI], [Discription], [DiscriptionHn], [DiscriptionMr], [IsActive], [Price], [ValidityInDays], [Language], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate], [ImagePath], [VideoUrl]) VALUES (18, N'Soyabin', N'सोयाबीन', N'सोयाबीन', N'The soybean, soy bean, or soya bean (Glycine max)[3] is a species of legume native to East Asia, widely grown for its edible bean, which has numerous uses.  Traditional unfermented food uses of soybeans include soy milk, from which tofu and tofu skin are made. Fermented soy foods include soy sauce, fermented bean paste, nattō, and tempeh. Fat-free (defatted) soybean meal is a significant and cheap source of protein for animal feeds and many packaged meals. For example, soybean products, such as textured vegetable protein (TVP), are ingredients in many meat and dairy substitutes.', N'सोयाबीन-[वैज्ञानिक नाम="ग्लाईसीन मैक्स"] सोयाबीन फसल है। सोयाबीन भारतवर्ष में महत्वपूर्ण फसल है। यह दलहन के बजाय तिलहन की फसल मानी जाती है। सोयाबीन का उत्पादन 1985 से लगातार बढ़ता जा रहा है और सोयाबीन के तेल की खपत मूँगफली एवं सरसों के तेल के पश्चात सबसे अधिक होने लगा है। सोयाबीन एक महत्वपूर्ण खाद्य स्रोत है। इसके मुख्य घटक प्रोटीन, कार्बोहाइडेंट और वसा होते है। सोयाबीन में 38-40 प्रतिशत प्रोटीन, 22 प्रतिशत तेल, 21 प्रतिशत कार्बोहाइडेंट, 12 प्रतिशत नमी तथा 5 प्रतिशत भस्म होती है। विश्व का 60% सोयाबीन अमेरिका में पैदा होता है। भारत मे सबसे अधिक सोयाबीन का उत्पादन मध्यप्रदेश करता है। मध्यप्रदेश में इंदौर में सोयाबीन रिसर्च सेंटर है।', N'महाराष्ट्रात सोयाबीन पिकास पाने खाणा-या अळ्या, खोडमाशी या किंडीचा व तांबेरा या रोगाचा प्रादुर्भाव दिसून येतो. खोडमाशीच्या प्रादुर्भाव झाल्यास बाल्यावस्थेत रोपाचे एखादे पान कडेने वाळू लागते आणि त्याची एखादी फांदी सुकलेली आढळते. ब-याचदा ग्रासित रोपांवर जमिनी पासून काही अंतरावर छिद्रेही आढळतात आणि त्यामुळे उत्पादनात १५ टक्केपर्यंत नुकसान संभवते.', 1, CAST(55.00 AS Decimal(18, 2)), 55, 1, 1, CAST(N'2021-08-17T07:26:50.320' AS DateTime), 2, CAST(N'2021-09-15T08:18:26.103' AS DateTime), N'/Course/Soyabin_0.jpeg', N'https://www.youtube.com/watch?v=OzkX2qX82xw')
GO
INSERT [dbo].[tblCourse] ([Id], [CourseEN], [CourseMR], [CourseHI], [Discription], [DiscriptionHn], [DiscriptionMr], [IsActive], [Price], [ValidityInDays], [Language], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate], [ImagePath], [VideoUrl]) VALUES (19, N'Wheat', N'गहू ', N'गेहूं', N'Wheat ( species of Triticum) is a cereal grain. People eat it most often in the form of bread. It is a kind of grass whose fruit is a "head of wheat" with edible seeds. It was first grown in the Levant, a region of the Near East. Now it is cultivated worldwide. World trade in wheat is greater than for all other crops combined.', N'गेहूं के जवारे के बारे में लगभग हर कोई जानता है। अगर नहीं, तो हम बता देते हैं। आपने अक्सर देखा होगा कि गेहूं की फसल शुरुआत में हरी घास की तरह होती है। बस इस हरी घास को ही गेहूं के जवारे और इंग्लिश में वीटग्रास कहते हैं। अब आप सोच रहे होंगे कि स्टाइलक्रेज के इस आर्टिकल में हम गेहूं के जवारे की बात क्यों कर रहे हैं, तो हम बता दें कि यह हरी घास स्वास्थ्य के लिहाज से फायदेमंद होती है। इस पौधे को ट्रिटाकुमेस्टिवम लिनन (Tritcumaestivum Linn) परिवार का सदस्य माना जाता है। यह हरी घास देखने में छोटी जरूर है, लेकिन फायदे कई हैं। यह क्लोरोफिल, फ्लेवोनोइड्स, विटामिन-सी और विटामिन-ए से समृद्ध होती है। साथ ही इसमें कैंसर रोधी, मधुमेह, मोटापा और ऑक्सीडेटिव स्ट्रेस से बचाने के गुण मौजूद होते हैं (1)। कुछ ऐसे ही फायदों के बारे में हम इस आर्टिकल में पढ़ेंगे। चलिए, इस आर्टिकल के जरिए जानते हैं गेहूं के जवारे के फायदे, उपयोग और नुकसान के बारे में।', N'गहू हे झुबकेदार वर्षायू गवत आहे. कोवळेपणी ही वनस्पती हिरवीगार असते आणि गवतासारखी दिसते. पूर्ण वाढ झालेल्या गव्हाच्या रोपांची उंची ६०-१५० सेंमी. असते. पिकल्यावर ती सोनेरी पिवळीधमक दिसू लागते. मूळ, खोड, पाने आणि स्तबक (कणिश) हे पिकलेल्या वनस्पतीचे मुख्य भाग असतात. तिच्यामध्ये दोन प्रकारची मुळे दिसून येतात; प्राथमिक आणि द्वितीयक. गव्हाच्या बियांपासून ३-५ सेंमी. लांबीची मुळे येतात आणि ती जमिनीखाली असतात. ही मुळे ६-८ आठवडे टिकतात.', 1, CAST(44.00 AS Decimal(18, 2)), 44, 1, 1, CAST(N'2021-08-17T07:28:59.353' AS DateTime), 2, CAST(N'2021-09-13T07:42:00.857' AS DateTime), N'/Course/Wheat_5.jpeg', N'https://www.youtube.com/watch?v=OzkX2qX82xw')
GO
INSERT [dbo].[tblCourse] ([Id], [CourseEN], [CourseMR], [CourseHI], [Discription], [DiscriptionHn], [DiscriptionMr], [IsActive], [Price], [ValidityInDays], [Language], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate], [ImagePath], [VideoUrl]) VALUES (20, N'Cane', N'ऊस', N'गन्ना', N'a perennial tropical grass with tall stout jointed stems from which sugar is extracted. The fibrous residue can be used as fuel, in fiber board, and for a number of other purposes.', N'भारत में गन्ने (Ganne) की खेती आदिकाल से की जा रही है किन्तु 20वीं शताब्दी में गन्ने (Ganne) की पहचान एक प्रमुख नकदी फसल के रूप में की गई। भारतीय कृषि अर्थव्यवस्था में इसका विशेष योगदान है। इस समय देश के लगभग 18 प्रदेशों में 42 लाख हैक्टर कृषि भू-भाग पर औसतन 70 टन प्रति हैक्टर उपज के साथ गन्ने की खेती की जाती है। उत्तर भारत के लगभग 60-65 प्रतिशत भू-भाग पर गन्ने की बुआई बंसतकाल में आर्द्रता जमाव और बढ़वार के अनुकूल की जाती है। इस बुआई हेतु पूर्वी क्षेत्र जैसे पश्चिम बंगाल और बिहार राज्यों के लिए 15 जनवरी से 15 फरवरी, मध्यवर्ती ओर पश्चिमी क्षेत्र जैसे उत्तर प्रदेश, हरियाणा और पंजाब आदि राज्यों में 15 फरवरी से 15 मार्च तक बुआई का समय उपयुक्त होता है। इसके बाद बुआई करने से गन्ने (Ganne) की फसल को समय कम मिलने के कारण उपज में भारी कमी आ जाती है तथा क्षेत्रफल अधिक होने के कारण इसकी कम औसत उपज का राष्ट्रीय उत्पादकता पर प्रत्यक्ष प्रभाव पड़ता है।', N'ऊस हे वार्षिक पीक आहे. उसाच्या पेरापासून (खोडाच्या तुकड्यापासून) नवीन रोप लावतात. उसाला काळी कसदार जमीन लागते, कारण उसाला खूप पोषकद्रव्ये लागतात. लागण व खोडवा या ऊस पिकवण्याच्या २ पद्धती आहेत. उसापासून मोठया प्रमाणात साखर मिळते..', 1, CAST(3000.00 AS Decimal(18, 2)), 10, 3, 1, CAST(N'2021-08-17T07:35:46.960' AS DateTime), 2, CAST(N'2021-09-13T07:38:33.397' AS DateTime), N'/Course/Cane_6.jpeg', N'https://www.youtube.com/watch?v=OzkX2qX82xw')
GO
INSERT [dbo].[tblCourse] ([Id], [CourseEN], [CourseMR], [CourseHI], [Discription], [DiscriptionHn], [DiscriptionMr], [IsActive], [Price], [ValidityInDays], [Language], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate], [ImagePath], [VideoUrl]) VALUES (21, N'Cabbage', N'कोबी', N'पत्ता गोभी', N'Cabbage, comprising several cultivars of Brassica oleracea, is a leafy green, red (purple), or white (pale green) biennial plant grown as an annual vegetable crop for its dense-leaved heads. It is descended from the wild cabbage (B. oleracea var. oleracea), and belongs to the "cole crops" or brassicas, meaning it is closely related to broccoli and cauliflower (var. botrytis); Brussels sprouts (var. gammier); and Savoy cabbage (var. sabauda).', N'बंद गोभी (पात गोभी या करमकल्ला ; अंग्रेजी : कैबेज) एक प्रकार का शाक (सब्जी) है, जिसमें केवल कोमल पत्तों का बँधा हुआ संपुट होता है। इसे बंदगोभी और पातगोभी भी कहते हैं। यह जंगली करमकल्ले (ब्रेसिका ओलेरेसिया, Brassica oleracea) से विकसित किया गया है। शाक के लिए उगाया जानेवाला करमकल्ला मूल प्रारूप से बहुत भिन्न हो गया, यद्यपि फूल और बीज में विशेष अंतर नहीं पड़ा है।', N'कोबी ही औषधी वनस्पती ब्रॅसिकेसी कुलातील असून तिचे शास्त्रीय नाव ब्रॅसिका ओलेरॅसिया (प्रकार कॅपिटॅटा) आहे. ही मूलत: भूमध्यसामुद्रिक प्रदेशातील असून यूरोप खंडातील इतर प्रदेशांत तिचा प्रसार झाला आहे.', 1, CAST(77.00 AS Decimal(18, 2)), 7, 2, 1, CAST(N'2021-08-17T08:18:27.603' AS DateTime), 2, CAST(N'2021-09-15T05:58:08.033' AS DateTime), N'/Course/hhgh_5.jpeg', N'https://www.youtube.com/watch?v=OzkX2qX82xw')
GO
INSERT [dbo].[tblCourse] ([Id], [CourseEN], [CourseMR], [CourseHI], [Discription], [DiscriptionHn], [DiscriptionMr], [IsActive], [Price], [ValidityInDays], [Language], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate], [ImagePath], [VideoUrl]) VALUES (22, N'Onion', N'कांदा', N'Pyaj', N'The onion (Allium cepa L., from Latin cepa "onion"), also known as the bulb onion or common onion, is a vegetable that is the most widely cultivated species of the genus Allium. The shallot is a botanical variety of the onion. Until 2010, the shallot was classified as a separate species', N'प्याज', N'कांद्याची लागवड कमीतकमी ७,००० वर्षांपासून निवडक पद्धतीने केली जाते. कांदा ही द्वैवार्षिक वनस्पती आहे, परंतु सामान्यत: वार्षिक म्हणून घेतले जाते. कांद्याच्या आधुनिक जाती साधारणतः 15 ते 45 सेमी (6 ते 18 इंच) उंचीपर्यंत वाढतात. कांद्याची पाने पिवळसर- हिरव्या निळ्या रंगाची असतात आणि ती चपट्या, पंखाच्या आकाराच्या गुंडाळणीमध्ये एकट्याने वाढतात. ते चपटे, पोकळ आणि दंडगोलाकार असतात. कांदा परिपक्व होताना, त्याच्या पानांचा तळ आणि त्याच्या कंदामध्ये अन्न साठा जमा होण्यास सुरवात होते. कांदा भारतातून अनेक देशात निर्यात होतो,उदा. नेपाळ, पाकिस्तान, श्रीलंका, बांग्लादेश, इत्यादि. कांदयाचे पीक भारतात कर्नाटक, गुजरात, राजस्थान, उत्तर प्रदेश, बिहार, पश्चिम बंगाल, मध्य प्रदेश, तामिळनाडू, ओडिशा या राज्यांमध्ये घेतले जाते.', 1, CAST(100.00 AS Decimal(18, 2)), 10, 1, 1, CAST(N'2021-08-17T08:40:48.140' AS DateTime), 1, CAST(N'2021-09-13T07:39:19.940' AS DateTime), N'/Course/dddd_6.jpeg', N'https://www.youtube.com/watch?v=OzkX2qX82xw')
GO
INSERT [dbo].[tblCourse] ([Id], [CourseEN], [CourseMR], [CourseHI], [Discription], [DiscriptionHn], [DiscriptionMr], [IsActive], [Price], [ValidityInDays], [Language], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate], [ImagePath], [VideoUrl]) VALUES (23, N'Agri QA course', N'Agri QA course Marathi', N'Agri QA course Hindi', N'Agri QA course subscription, Video play ', N'Agri QA course subscription, Video play Hindi', N'Agri QA course subscription, Video play Marathi', 1, CAST(700.00 AS Decimal(18, 2)), 7, 1, 1, CAST(N'2021-08-23T12:47:18.980' AS DateTime), 2, CAST(N'2021-09-13T07:15:55.700' AS DateTime), N'/Course/Agri_QA_course_6.jpeg', N'https://www.youtube.com/watch?v=OzkX2qX82xw')
GO
INSERT [dbo].[tblCourse] ([Id], [CourseEN], [CourseMR], [CourseHI], [Discription], [DiscriptionHn], [DiscriptionMr], [IsActive], [Price], [ValidityInDays], [Language], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate], [ImagePath], [VideoUrl]) VALUES (24, N'Eco-Agri Tourism', N'Eco-Agri Tourism', N'Eco-Agri Tourism', N'Agritourism is the form of tourism that capitalises on rural culture as a tourist attraction.', N'Agritourism is the form of tourism that capitalises on rural culture as a tourist attraction.', N'Agritourism is the form of tourism that capitalises on rural culture as a tourist attraction.', 1, CAST(1000.00 AS Decimal(18, 2)), 30, 2, 1, CAST(N'2021-09-02T06:48:47.587' AS DateTime), 1, CAST(N'2021-09-03T13:30:27.730' AS DateTime), N'/Course/Eco_Agri_Tourism_3.jpeg', N'https://www.youtube.com/watch?v=OzkX2qX82xw')
GO
 
INSERT [dbo].[tblCourse] ([Id], [CourseEN], [CourseMR], [CourseHI], [Discription], [DiscriptionHn], [DiscriptionMr], [IsActive], [Price], [ValidityInDays], [Language], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate], [ImagePath], [VideoUrl]) VALUES (29, N'Nature', N'निसर्ग', N'प्रकृति', N'Nature, in the broadest sense, is the natural, physical, material world or universe. "Nature" can refer to the phenomena of the physical world, and also to life in general. ... Within the various uses of the word today, "nature" often refers to geology and wildlife.', N'प्रकृति एक प्राकृतिक पर्यावरण है जो हमारे आसपास है, हमारा ध्यान देती है और हर पल हमारा पालन-पोषण करती है। ये हमारे चारों तरफ एक सुरक्षात्मक कवच प्रदान करती है जो हमें नुकसान से बचाती है। ... प्रकृति हमारे आस-पास कई रुपों में है जैसे पेड़, जंगल, जमीन, हवा, नदी, बारिश, तालाब, मौसम, वातावरण, पहाड़, पठार, रेगिस्तान ', N'जे जे मानवनिर्मित नाही त्याला आपण निसर्ग म्हणू शकतो. पाणी, हवा, अग्नी, पृथ्वी आणि आकाश ही तत्त्वे निसर्गात आढळतात. त्यांचे स्त्रोत वेगवेगळे आहेत. जसे नद्या, समुद्र, डोंगर, जमीन, सूर्य, झाडे जे जे आपल्याला आसपास डोळ्यांनी दिसते आणि दिसत नाही त्या सर्वांचा मिळून निसर्ग तयार होतो. अशी एक व्याप्त व्याख्या निसर्गाची करता येईल.', 1, CAST(77.00 AS Decimal(18, 2)), 77, 2, 4, CAST(N'2021-09-14T11:00:59.987' AS DateTime), 2, CAST(N'2021-09-16T05:27:11.093' AS DateTime), N'/Course/jhkh_8.jpeg', N'https://youtu.be/hPzBb9ebp7g')
GO
SET IDENTITY_INSERT [dbo].[tblCourse] OFF
GO
SET IDENTITY_INSERT [dbo].[tblExceptionLogItems] ON 
GO
  
INSERT [dbo].[tblExceptionLogItems] ([EventId], [LogDateTime], [Source], [Message], [QueryString], [TargetSite], [StackTrace], [ServerName], [RequestURL], [UserAgent], [UserIP], [UserAuthentication], [UserName]) VALUES (811, CAST(N'2021-09-21T12:39:38.000' AS DateTime), N'SmartSheti.Application', N'Something Went Wrong..!', N'', N'Void MoveNext()', N'   at SmartSheti.Application.Bussiness.CourseApplication.UpdatePaymentStatus(TransactionModel model) in E:\Madhuri\SmartSheti-Adminpanel\smartsheti-api\SmartSheti-Api\SmartSheti.Application\Bussiness\CourseApplication.cs:line 421
   at SmartSheti.Controllers.CourseController.CourseSubscribe(TransactionModel course) in E:\Madhuri\SmartSheti-Adminpanel\smartsheti-api\SmartSheti-Api\SmartSheti\Controllers\CourseController.cs:line 140', N'', N'agriapi.knackbe.in', N'okhttp/4.3.1', N'162.158.129.122', N'True', N'Darshana chorage')
GO
SET IDENTITY_INSERT [dbo].[tblExceptionLogItems] OFF
GO
 
SET IDENTITY_INSERT [dbo].[tblProduct] ON 
GO  
INSERT [dbo].[tblProduct] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [Price], [Active], [CreatedBy], [CreatedDate], [ImageUrl], [Discription], [Discription_Hn], [Discription_Mr], [MRP], [UpdatedDate], [UpdatedBy], [Weight], [CategoryId]) VALUES (8, N'Capsicum Seed', N'शिमला मिर्च बियाणे', N'शिमला मिर्च के बीज', CAST(450.00 AS Decimal(8, 2)), 1, 1, CAST(N'2021-06-16T06:51:23.740' AS DateTime), N'/Product/Capsicum_Seed_1.jpeg', N'They are commonly called Chili pepper, red or green pepper, or just pepper in Britain and the US; the large mild form is called bell pepper in the US, capsicum in New Zealand English, Australian English and British English, and paprika in some other countries (although paprika can also refer to the powdered spice made ...', N'शिमला मिर्च, मिर्च की एक प्रजाति है जिसका प्रयोग भोजन में सब्जी की तरह किया जाता है। अंग्रेज़ी मे इसे कैप्सिकम (जो इसका वंश भी है) या पैपर भी कहा जाता है। ... बाजार में शिमला मिर्च लाल, हरी या पीले रंग की मिलती है। चाहे शिमला मिर्च किसी भी रंग की हो लेकिन उसमें विटामिन सी, विटामिन ए और बीटा कैरोटीन भरा होता है।', N'ढोबळी मिरची (शास्त्रीय नाव:Capsicum annuum) हा मिरचीचा एक प्रकार आहे. यास सिमला मिरची किंवा भोपळी मिरची असेही म्हणतात. ही तिखट नसल्याने हिला काहीजण गोडी मिरचीही म्हणतात. भारतात सहज मिळणारी भोपळी मिरची दाट हिरव्या रंगाची असते. गेल्या काही वर्षात या हिरव्या प्रकाराखेरीज लाल, पिवळी, शेंदरी, जांभळी आणि तपकिरी रंगाची सिमला मिरची बाजारात मिळू लागली आहे. हिरव्या रंगाच्या मिरचीच्या तुलनेत या रंगीत मिरच्या सहसा महाग असल्याने अजूनही त्यांचा वापर सर्वसामान्य भारतीयांत मर्यादित आहे.', CAST(500.00 AS Decimal(18, 2)), CAST(N'2021-09-03T08:23:40.993' AS DateTime), 2, CAST(5.000 AS Decimal(5, 3)), 23)
GO
INSERT [dbo].[tblProduct] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [Price], [Active], [CreatedBy], [CreatedDate], [ImageUrl], [Discription], [Discription_Hn], [Discription_Mr], [MRP], [UpdatedDate], [UpdatedBy], [Weight], [CategoryId]) VALUES (9, N'Brinjal', N'वांगे', N'बैंगन', CAST(300.00 AS Decimal(8, 2)), 1, 1, CAST(N'2021-06-17T06:26:38.690' AS DateTime), N'/Product/Brinjal_5.jpeg', N'Brinjal (Solanum melongena), also known as eggplant or aubergine, is an easily cultivated plant belonging to the family Solanaceae. Its fruit is high in nutrition and commonly consumed as a vegetable.', N'पांबन पूल (तमिळ: பாம்பன் பாலம்) हा भारताच्या तमिळनाडू राज्याच्या रामनाथपुरम जिल्ह्यामधील एक सागरी रेल्वे पूल आहे. मन्नारचे आखात व पाल्कची सामुद्रधुनी ह्या हिंदी महासागराच्या उपसमुद्रांवर बांधला गेलेला ६,७७६ फूट (२,०६५ मी) लांबीचा हा पूल रामेश्वरम द्वीपाला मुख्य भारतीय भूमीसोबत जोडतो. १२ ज्योतिर्लिंगांपैकी एक असलेले रामेश्वरम गावामध्ये फक्त ह्या पुलाद्वारेच प्रवेश शक्य आहे. वास्तविकपणे येथे रेल्वेवाहतूकीसाठी एक व मोटार वाहतूकीसाठी एक असे दोन वेगळे पूल अस्तित्वात असून दोन्ही पुलांना एकत्रितपणे पांबन पूल असेच म्हटले जाते.', N'वांगे (शास्त्रीय नाव: Solanum melongena, सोलानम मेलाँजेना ;) ही सोलानम प्रजातीतील एक वनस्पती आहे. त्याची फळे स्वयंपाकात खाद्यपदार्थ म्हणून वापरली जातात. मुळातील दक्षिण आशियातून उगम पावलेल्या या वनस्पतीची लागवड आता उष्णकटिबंधात व समशीतोष्ण कटिबंधातील अन्य भूप्रदेशांमध्येही केली जाते. चीन मध्ये सर्वप्रथम वांगी वापरात आल्याचा उल्लेख आढळतो. महाराष्ट्रात पीक आल्यावर खंडोबाला वांग्याचे भरीत अर्पण करण्याची प्राचीन परंपरा आहे.', CAST(400.00 AS Decimal(18, 2)), CAST(N'2021-09-03T08:21:09.863' AS DateTime), 2, CAST(6.000 AS Decimal(5, 3)), 19)
GO
 
INSERT [dbo].[tblProduct] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [Price], [Active], [CreatedBy], [CreatedDate], [ImageUrl], [Discription], [Discription_Hn], [Discription_Mr], [MRP], [UpdatedDate], [UpdatedBy], [Weight], [CategoryId]) VALUES (11, N'Methi', N'मेथी', N'मेथी', CAST(500.00 AS Decimal(8, 2)), 1, 1, CAST(N'2021-06-17T06:42:37.603' AS DateTime), N'/Product/Methi_7.jpeg', N'Fenugreek is used as a herb (dried or fresh leaves), spice (seeds), and vegetable (fresh leaves, sprouts, and microgreens). Sotolon is the chemical responsible ...', N'मेथी एक वनस्पति है जिसका पौधा १ फुट से छोटा होता है। इसकी पत्तियाँ साग बनाने के काम आतीं हैं तथा इसके दाने मसाले के रूप में प्रयुक्त होते हैं। ... मेथी का पौधा एक छोटा सा पौधा है जिसमें हरे पत्ते, छोटे सफेद फूल और फली होती है जिसमें छोटे, सुनहरे-भूरे रंग के बीज होते हैं। यह पौधा 2-3 फीट तक बढ़ सकता है।', N'मेथी(शास्त्रीय नाव: Trigonella foenum-graecum, ट्रिगोनेला फीनम-ग्रासम) ही लेग्युमिनोसी कुळातील वनस्पती आहे. ही पाने व बिया या दोन्ही रूपांत वापरली जाते. मेथीची पाने भाजी म्हणून वापरले जातात. तसेच, मेथीदाणे हे मसाल्याचा पदार्थ म्हणून वापरले जातात. कसुरी मेथी नावाने प्रचलित असलेली वाळवलेली मेथीपाने त्यांच्या सुगंधामुळे विविध पदार्थांत वापरली जातात.मेथीला कडवट चव असते.', CAST(600.00 AS Decimal(18, 2)), CAST(N'2021-09-03T08:17:36.120' AS DateTime), 2, CAST(2.000 AS Decimal(5, 3)), 19)
GO
INSERT [dbo].[tblProduct] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [Price], [Active], [CreatedBy], [CreatedDate], [ImageUrl], [Discription], [Discription_Hn], [Discription_Mr], [MRP], [UpdatedDate], [UpdatedBy], [Weight], [CategoryId]) VALUES (12, N'hhh', N'hhh', N'hhh', CAST(55.00 AS Decimal(8, 2)), 1, 1, CAST(N'2021-06-17T08:28:49.577' AS DateTime), N'/Product/hhh_7.jpeg', N'gfhfg', N'fggf', N'gfgfgf', CAST(777.00 AS Decimal(18, 2)), CAST(N'2021-09-08T06:20:53.237' AS DateTime), 2, CAST(3.000 AS Decimal(5, 3)), 23)
GO
 
INSERT [dbo].[tblProduct] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [Price], [Active], [CreatedBy], [CreatedDate], [ImageUrl], [Discription], [Discription_Hn], [Discription_Mr], [MRP], [UpdatedDate], [UpdatedBy], [Weight], [CategoryId]) VALUES (15, N'🌽 corn', N'मका', N'मक्का', CAST(400.00 AS Decimal(8, 2)), 1, 1, CAST(N'2021-06-24T07:56:44.100' AS DateTime), N'/Product/_corn_1.jpeg', N'Keep the away  from  children''s because it is very dejarous.', N'मक्का (वानस्पतिक नाम : Zea maize) एक प्रमुख खाद्य फसल हैं, जो मोटे अनाजो की श्रेणी में आता है। इसे भुट्टे की शक्ल में भी खाया जाता है। ... हाँ यह बात और है कि भारत मक्का के उपयोगो मे काफी पिछडा हुआ है। जबकि अमरीका में यह एक पूर्णतया औद्याोगिक फसल के रूप में उत्पादित की जाती है और इससे विविध औद्याोगिक पदार्थ बनाऐ जाते है।', N'मका : (हिं. मकई, मक्का, भुट्टा; गु. मक्काई; क. मेक्केजोळा; सं. महायावनाल; इं. मेझ, इंडियन कॉर्न; लॅ. झिया मेझ; कुल-ग्रॅमिनी). हे एक महत्त्वाचे तृणधान्य आहे. फुलझाडांपैकी [⟶ वनस्पति, आवृतबीज उपविभाग] एकदलित वर्गातील ⇨ग्रॅमिनी कुलातील (तृण कुलातील) एक लागवडीतील जाती. मक्याचे मूलस्थान अमेरिका (मेक्सिको किंवा मध्य अमेरिका) हे असावे याबद्दल मतभेद असले, तरी सध्याच्या मक्याचा विकास त्याच्याशी संबंधित असलेल्या टेओसिंटे (यूक्लीना मेक्सिकांना; हिंदी व पंजाबी नाव मक्चारी) या वन्य जातीपासून आदिमानवाने उपयुक्त उत्परिवर्तनांनी (आनुवंशिक लक्षणांत बदल घडवून आणण्याच्या क्रियांनी) व सतत निवड पद्धतीने केलेल्या अभिवृद्धीतून झालेला असावा, हे मत बरेचसे मान्यता पावलेले आहे. पेरू देशातील इंका लोकांच्या थडग्यांत आढळलेल्या मक्याच्या विविध प्रकारच्या दाण्यांवरून इंका संस्कृतीच्या कालापूर्वी अनेक शतके मका लागवडीत असावा असा निष्कर्ष निघतो (तथापि या प्रकारांचे स्वरूप सध्याच्या मक्यापेक्षा पुष्कळच निराळे होते असे आढळून आले आहे). त्यानंतर त्याचा प्रसार उत्तरेकडील प्रदेशात होऊन माया व ॲझटेक या संस्कृतींत मक्याने महत्त्वाचे स्थान मिळविल्याचे आढळते. यूरोपीय जलप्रवासी प्रथम अमेरिकेत गेले त्यावेळी उत्तरेकडील महासरोवरांपासून दक्षिणेकडे चिली आणि अर्जेंटिना पर्यंत सर्व प्रदेशांत मका लागवडीत होता. यूरोपियनांनी अमेरिकेत मक्याची लागवड सोळाव्या व सतराव्या शतकांत सुरू केली. यूरोपात मका प्रथम स्पॅनिश लोकांनी अमेरिकेतून १४९४ त्या सुमारास नेला. त्यानंतर काही वर्षांत त्याचा दक्षिण फ्रान्स, इटली आणि बाल्कन प्रदेशांत प्रसार झाला. आशियात या पिकाची सोळाव्या शतकाच्या आरंभी आयात झाली. भारतात त्याची आयात केव्हा झाली हे एक न सुटलेले काडे आहे. पोर्तुगीज लोकांनी सोळाव्या शतकाच्या आरंभी भारतात मक्याची आयात केली असे मानले जाते; परंतु त्याहीपूर्वी अरब-आफ्रिकनांच्या मार्फत त्याचा भारतात प्रवेश झाला असावा, असेही मानण्यात येते. निरनिराळ्या पुराव्यांवरून कोलंबसाने अमेरिकेचा शोध लावण्यापूर्वी भारत व अमेरिका (विशेषतः मेक्सिको) यांच्यामध्ये दळणवळण होते असे मानण्यात जागा आहे. मका हे तृणधान्य आहे.', CAST(600.00 AS Decimal(18, 2)), CAST(N'2021-09-03T08:51:53.873' AS DateTime), 2, CAST(5.000 AS Decimal(5, 3)), 23)
GO
INSERT [dbo].[tblProduct] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [Price], [Active], [CreatedBy], [CreatedDate], [ImageUrl], [Discription], [Discription_Hn], [Discription_Mr], [MRP], [UpdatedDate], [UpdatedBy], [Weight], [CategoryId]) VALUES (16, N'Bitter gourd', N'कारले', N'करेला', CAST(400.00 AS Decimal(8, 2)), 1, 1, CAST(N'2021-06-24T08:08:57.407' AS DateTime), N'/Product/Bitter_gourd_7.jpeg', N'We are renowned manufacture, distributors, traders and. Supplier of high quality bitter gourd powder.', N'Health Benefits Of Bitter Gourd: यह कड़वा फल कई तरह के पोषक तत्वों से भरपूर होता है। इसमें भारी मात्रा में आयरन, मैग्नीशियम, विटामिन सी और पोटैशियम पाया जाता है। करेला स्वाद में जितना कड़वा होता है, उसके फायदे उतने ही ज्यादा होते हैं। ... अधिकांश फल मीठे होते हैं, लेकिन यह कड़वा फल कई तरह के पोषक तत्वों से भरपूर होता है।', N'कारले (शास्त्रीय नाव: Momordica charantia, मोमॉर्डिका कॅरेंशिया ; इंग्लिश: Bitter Gourd, बिटर गूर्ड-मराठी उच्चार गोअर्ड ;) (हिंदी - करेला; गुजराती - करेलो; कानडी -हगलकई, हागलहण्णु, हागाला ; संस्कृत -कंदुरा, कारवल्ली, कारवेल्लकम्‌, कठिल्ल(क); बंगाली -बडकरेला उच्छे; तामिळ-पाकै, मितिपाकल) हा आशिया, आफ्रिका व कॅरिबियन बेटे या उष्ण कटिबंधीय प्रदेशांमध्ये आढळणारा वेल आहे. याला कडू चवीची, खडबडीत सालीची फळे येतात. याच्या कोवळ्या फळांचा भाजी म्हणून पाककृती बनवण्यासाठी वापर होतो. बाह्य आकार किंवा साल आणि कडवटपणा यांत वैविध्य असणारे कारल्याचे अनेक प्रकार आढळतात. कारले फार कडू वाटले तर भाजी करताना त्याच्यातून निघालेले पाणी कमी करून भाजी करतात.', CAST(420.00 AS Decimal(18, 2)), CAST(N'2021-09-15T13:17:39.763' AS DateTime), 4, CAST(5.000 AS Decimal(5, 3)), 21)
GO
INSERT [dbo].[tblProduct] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [Price], [Active], [CreatedBy], [CreatedDate], [ImageUrl], [Discription], [Discription_Hn], [Discription_Mr], [MRP], [UpdatedDate], [UpdatedBy], [Weight], [CategoryId]) VALUES (17, N'Cabbage 🥬', N'कोबी', N'गोभी', CAST(450.00 AS Decimal(8, 2)), 1, 1, CAST(N'2021-06-24T08:37:59.877' AS DateTime), N'/Product/Cabbage__5.jpeg', N'The Takii green coronet cabbage is a hybrid seed. The weight is 5gram and the maturity period is 75-80 days after transplanting.', N'बंद गोभी (पात गोभी या करमकल्ला ; अंग्रेजी : कैबेज) एक प्रकार का शाक (सब्जी) है, जिसमें केवल कोमल पत्तों का बँधा हुआ संपुट होता है। इसे बंदगोभी और पातगोभी भी कहते हैं। यह जंगली करमकल्ले (ब्रेसिका ओलेरेसिया, Brassica oleracea) से विकसित किया गया है। शाक के लिए उगाया जानेवाला करमकल्ला मूल प्रारूप से बहुत भिन्न हो गया, यद्यपि फूल और बीज में विशेष अंतर नहीं पड़ा है।', N'कोबी ही औषधी वनस्पती ब्रॅसिकेसी कुलातील असून तिचे शास्त्रीय नाव ब्रॅसिका ओलेरॅसिया (प्रकार कॅपिटॅटा) आहे. ही मूलत: भूमध्यसामुद्रिक प्रदेशातील असून यूरोप खंडातील इतर प्रदेशांत तिचा प्रसार झाला आहे.', CAST(500.00 AS Decimal(18, 2)), CAST(N'2021-09-08T06:23:38.960' AS DateTime), 2, CAST(1.000 AS Decimal(5, 3)), 16)
GO
INSERT [dbo].[tblProduct] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [Price], [Active], [CreatedBy], [CreatedDate], [ImageUrl], [Discription], [Discription_Hn], [Discription_Mr], [MRP], [UpdatedDate], [UpdatedBy], [Weight], [CategoryId]) VALUES (19, N'Soyabean', N'सोयाबीन वडी', N'सोयाबीन वडी', CAST(20.00 AS Decimal(8, 2)), 1, 1, CAST(N'2021-07-20T09:14:58.120' AS DateTime), N'/Product/Soyabean_8.jpeg', N'The soybean, soy bean, or soya bean (Glycine max)[3] is a species of legume native to East Asia, widely grown for its edible bean, which has numerous uses.', N'The soybean, soy bean, or soya bean (Glycine max)[3] is a species of legume native to East Asia, widely grown for its edible bean, which has numerous uses.', N'The soybean, soy bean, or soya bean (Glycine max)[3] is a species of legume native to East Asia, widely grown for its edible bean, which has numerous uses.', CAST(50.00 AS Decimal(18, 2)), CAST(N'2021-09-07T07:37:25.557' AS DateTime), 2, CAST(10.000 AS Decimal(5, 3)), 20)
GO
INSERT [dbo].[tblProduct] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [Price], [Active], [CreatedBy], [CreatedDate], [ImageUrl], [Discription], [Discription_Hn], [Discription_Mr], [MRP], [UpdatedDate], [UpdatedBy], [Weight], [CategoryId]) VALUES (20, N'Soyabean1', N'सोयाबीन ', N'सोयाबीन वडी', CAST(20.00 AS Decimal(8, 2)), 1, 1, CAST(N'2021-07-20T09:17:29.917' AS DateTime), N'/Product/Soyabean1_6.jpeg', N'The soybean, soy bean, or soya bean (Glycine max)[3] is a species of legume native to East Asia, widely grown for its edible bean, which has numerous uses.', N'सोयाबीन दलहन की फसल है शाकाहारी मनुष्यों के लिए इसको मांस भी कहा जाता है क्योंकि इसमें बहुत अधिक प्रोटीन होता है। इसका वानस्पतिक नाम ग्लाईसीन मैक्स है। स्वास्थ्य के लिए एक बहुउपयोगी खाद्य पदार्थ है। सोयाबीन एक महत्वपूर्ण खाद्य स्रोत है।', N'सोयाबीन (शास्त्रीय नाव: Glycine max, ग्लिसाइन मॅक्स; इंग्रजी: soya bean"Miracle bean";) ही मुळातील पूर्व आशियातील कडधान्य गटातील वनस्पती आहे. सोयाबीनमध्ये ग्लासीन हे आमिनो आम्ल मोठया प्रमाणात असते म्हणूनच शास्त्रीय नाव ग्लासीन मॅक्स असे आहे. कडधान्य असले तरी सोयाबीनपासून मिळणाऱ्या तेलामुळे त्यांना ढोबळ अर्थाने तेलबियांमध्येही गणले जाते.', CAST(50.00 AS Decimal(18, 2)), CAST(N'2021-09-07T07:36:59.097' AS DateTime), 2, CAST(20.000 AS Decimal(5, 3)), 21)
GO
INSERT [dbo].[tblProduct] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [Price], [Active], [CreatedBy], [CreatedDate], [ImageUrl], [Discription], [Discription_Hn], [Discription_Mr], [MRP], [UpdatedDate], [UpdatedBy], [Weight], [CategoryId]) VALUES (21, N'Tomato1', N'gfff', N'hhhhhh', CAST(4.00 AS Decimal(8, 2)), 1, 1, CAST(N'2021-07-20T10:11:37.597' AS DateTime), N'/Product/hhhh_0.jpeg', N'fghgfhgfh', N'टमाटर विश्व में सबसे ज्यादा प्रयोग होने वाली सब्जी है। इसका पुराना वानस्पतिक नाम लाइकोपोर्सिकान एस्कुलेंटम मिल है। वर्तमान समय में इसे सोलेनम लाइको पोर्सिकान कहते हैं। बहुत से लोग तो ऐसे हैं जो बिना टमाटर के खाना बनाने की कल्पना भी नहीं कर सकते। इसकी उत्पति दक्षिण अमेरिकी ऐन्डीज़ में हुआ। मेक्सिको में इसका भोजन के रूप में प्रयोग आरम्भ हुआ और अमेरि…', N'लालबुंद, रसरसीत टोमॅटो हे मूळचं अमेरिकेतलं फळं. आपल्याकडे खाण्यात त्याचा सर्रास वापर केला जातो. टोमॅटोशिवाय भाजीच्या रस्स्याला चव नाही, त्यामुळे या फळाचा मोठ्या प्रमाणात वापर आपल्याकडे होतो. भाजी, सूप, कोशिंबीर, केचअप अशा वेगवेगळ्या पदार्थांमध्ये टॉमेटोचा वापर केला जातो.', CAST(55.00 AS Decimal(18, 2)), CAST(N'2021-09-08T06:18:24.500' AS DateTime), 2, CAST(4.000 AS Decimal(5, 3)), 23)
GO
INSERT [dbo].[tblProduct] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [Price], [Active], [CreatedBy], [CreatedDate], [ImageUrl], [Discription], [Discription_Hn], [Discription_Mr], [MRP], [UpdatedDate], [UpdatedBy], [Weight], [CategoryId]) VALUES (22, N'ssss', N'sssss', N'ssss', CAST(33.00 AS Decimal(8, 2)), 1, 1, CAST(N'2021-08-07T09:55:54.433' AS DateTime), N'/Product/ssss_4.jpeg', N'ccv', N'vcxvc', N'vcvc', CAST(22.00 AS Decimal(18, 2)), CAST(N'2021-08-09T07:04:08.360' AS DateTime), 1, CAST(4.000 AS Decimal(5, 3)), 23)
GO
INSERT [dbo].[tblProduct] ([Id], [Name_ENG], [Name_MAR], [Name_HIN], [Price], [Active], [CreatedBy], [CreatedDate], [ImageUrl], [Discription], [Discription_Hn], [Discription_Mr], [MRP], [UpdatedDate], [UpdatedBy], [Weight], [CategoryId]) VALUES (23, N'methi seed', N'मेथी चे बी', N'मेथी चे बी', CAST(10.00 AS Decimal(8, 2)), 1, 1, CAST(N'2021-08-10T07:00:52.633' AS DateTime), N'/Product/methi_seed_3.jpeg', N'Popularly known as methi, fenugreek seeds are an essential spice of an Indian kitchen. ''', N'Popularly known as methi, fenugreek seeds are an essential spice of an Indian kitchen. ''', N'Popularly known as methi, fenugreek seeds are an essential spice of an Indian kitchen. ''', CAST(20.00 AS Decimal(18, 2)), CAST(N'2021-09-07T07:13:29.043' AS DateTime), 2, CAST(10.000 AS Decimal(5, 3)), 1)
GO
 
SET IDENTITY_INSERT [dbo].[tblProduct] OFF
GO
SET IDENTITY_INSERT [dbo].[tblProSet] ON 
GO
INSERT [dbo].[tblProSet] ([Id], [Name], [SettingKey], [SettingValue], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [Description]) VALUES (1, N'RazorPay', N'KeyId', N'rzp_live_KAAfvKuXFeIOMp', NULL, NULL, CAST(N'2020-06-01T11:39:59.887' AS DateTime), 14, N'test')
GO
INSERT [dbo].[tblProSet] ([Id], [Name], [SettingKey], [SettingValue], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [Description]) VALUES (2, N'RazorPay', N'KeySecret', N'TKnk00Gwj9e5ynCY3u7OeTdR', NULL, NULL, CAST(N'2020-06-01T11:40:11.937' AS DateTime), 14, N'test')
GO
INSERT [dbo].[tblProSet] ([Id], [Name], [SettingKey], [SettingValue], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [Description]) VALUES (3, N'Otp', N'Length', N'4', NULL, NULL, CAST(N'2020-05-25T09:03:52.603' AS DateTime), 15, N'text')
GO
INSERT [dbo].[tblProSet] ([Id], [Name], [SettingKey], [SettingValue], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [Description]) VALUES (4, N'Otp', N'ExpireInMinute', N'10', NULL, NULL, CAST(N'2020-06-22T09:53:51.200' AS DateTime), 1, N'OTP will Expire In Minutes')
GO
 
GO
INSERT [dbo].[tblProSet] ([Id], [Name], [SettingKey], [SettingValue], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [Description]) VALUES (33, N'GoogleKey', N'DistanceMatrix', N'AIzaSyADjreRcR5aw7dCHCmul7kqyPFZcfeh_hs', NULL, NULL, NULL, NULL, N'This key use to calculate distnce')
GO
INSERT [dbo].[tblProSet] ([Id], [Name], [SettingKey], [SettingValue], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [Description]) VALUES (34, N'GoLive', N'Action ', N'true', NULL, NULL, CAST(N'2020-07-18T16:39:26.807' AS DateTime), 2, N'this is one time used for Go globally for project Release')
GO
INSERT [dbo].[tblProSet] ([Id], [Name], [SettingKey], [SettingValue], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [Description]) VALUES (35, N'GoLive', N'Message', N'Due to COVID-19 lockdown, we are closed from 14/7/2020 until 18/7/2020. You may please order once the lockdown is relaxed - Team FP', NULL, NULL, CAST(N'2020-07-13T14:14:31.453' AS DateTime), 2, N'this is one time used for Go globally for project Release')
GO
INSERT [dbo].[tblProSet] ([Id], [Name], [SettingKey], [SettingValue], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [Description]) VALUES (36, N'DeliverSlot', N'Count', N'18', NULL, NULL, CAST(N'2021-04-24T05:16:18.200' AS DateTime), 3, N'The number which defines the deliveries per time slot.')
GO
INSERT [dbo].[tblProSet] ([Id], [Name], [SettingKey], [SettingValue], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [Description]) VALUES (37, N'DeliveryCharges', N'Percentage', N'100', NULL, NULL, CAST(N'2021-04-10T08:14:17.557' AS DateTime), 3, N'delivery percentage')
GO
INSERT [dbo].[tblProSet] ([Id], [Name], [SettingKey], [SettingValue], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [Description]) VALUES (38, N'SMSSettings', N'ApiKey', N'7e1bb285-094c-4dce-b8e1-25dec9aa7180', NULL, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[tblProSet] OFF
GO
SET IDENTITY_INSERT [dbo].[tblSocial] ON 
GO
 
INSERT [dbo].[tblSocial] ([Id], [Title], [TitleHn], [TitleMr], [Discription], [DiscriptionHn], [DiscriptionMr], [ImageUrl], [VideoUrl], [IsActive], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (23, N'10 month old cane', N'10 महिन्यांचा ऊस', N'10 महीने का गन्ना', N'This 10 month old cane is 86032. About 20 to 25 sticks have come up so far. Each cane is one inch long. The thickness is also very good. The cane has grown very well since it was transplanted all the time. It is expected that 10 to 15 canes of sugarcane will grow in another 4 to 5 months. 120 tons of sugarcane is expected.', N'यह 10 महीने पुराना बेंत 86032 का है। अब तक करीब 20 से 25 डंडे आ चुके हैं। प्रत्येक गन्ना एक इंच लंबा होता है। मोटाई भी बहुत अच्छी है। हर समय प्रतिरोपण के बाद से गन्ना बहुत अच्छी तरह से विकसित हुआ है। उम्मीद है कि अगले 4-5 महीनों में गन्ने के 10 से 15 गन्ने बढ़ेंगे। 120 टन गन्ना आने की उम्मीद है।', N'10 महिन्यांचा हा 86032 या जातीचा ऊस आहे. जवळपास 20 ते 25 कांडी आता पर्यंत आली आहे . प्रत्येक कांडी ही एक वित लांब आहे . जाडीही खूप चांगल्या पद्धतीची आहे . ऊसाची लागण केल्यापासून ते आतापर्यंत सर्व वेळेवर्ती केल्यामुळे हा ऊस खूप उत्कृष्ठ रीत्या आला आहे . अजून 4 ते 5 महिन्यात 10 ते 15 कांडी ऊस वाढेल अशी आशा आहे . 120 टन ऊसाची अपेक्षा आहे .', N'/Social/10_month_old_cane_4.jpeg', NULL, 1, 1, CAST(N'2021-08-26T13:13:42.850' AS DateTime), NULL, NULL)
GO
INSERT [dbo].[tblSocial] ([Id], [Title], [TitleHn], [TitleMr], [Discription], [DiscriptionHn], [DiscriptionMr], [ImageUrl], [VideoUrl], [IsActive], [CreatedBy], [CreatedDate], [UpdatedBy], [UpdatedDate]) VALUES (24, N'komb / water shooter', N'कोंब / वॉटर शूटर', N'कोंब / वॉटर शूटर', N'Tsech Khup Pramanat Jadi Ani Kandyanchi Lambi Utkrust Pain Develop Jhaleli Aste. Magoon to komb usayevde mothe ho shaktit v tuyanche vajanhi 2 to 3 kgs would be settled.', N'तसेच खुप प्रमानत जाडी अनी कंड्यानची लांबी उत्क्रुस्ट पेन डेव्हलप झालेली अस्ते. मगून तो कोंब उसयेवडे मोठे हो शक्तीत v तुयांचे वाजंही 2 ते 3 किलो परियंत बसते.', N'तसेच खुप प्रमानत जाडी अनी कंड्यानची लांबी उत्क्रुस्ट पेन डेव्हलप झालेली अस्ते. मगून तो कोंब उसयेवडे मोठे तसेच खुप प्रमानत जाडी अनी कंड्यानची लांबी उत्क्रुस्ट पेन डेव्हलप झालेली अस्ते. मगून तो कोंब उसयेवडे मोठे हो शक्तीत v तुयांचे वाजंही 2 ते 3 किलो परियंत बसते.हो शक्तीत v तुयांचे वाजंही 2 ते 3 किलो परियंत बसते.', N'/Social/komb_water_shooter_8.jpeg', N'', 1, 1, CAST(N'2021-08-27T03:46:39.950' AS DateTime), NULL, NULL)
GO
 
SET IDENTITY_INSERT [dbo].[tblSocial] OFF
GO
SET IDENTITY_INSERT [dbo].[tblSubCategory] ON 
GO
INSERT [dbo].[tblSubCategory] ([Id], [CategoryId], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [Discription], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (1, NULL, N'Organic Seed', N'Organic Seed', N'Organic Seed', N'/SubCatgory/Organic_Seed_4.jpeg', 1, NULL, CAST(N'2021-07-26T11:29:28.983' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblSubCategory] ([Id], [CategoryId], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [Discription], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (2, NULL, N'Fruit Seed', N'Fruit Seed', N'Fruit Seed', N'/SubCatgory/Fruit_Seed_1.jpeg', 1, NULL, CAST(N'2021-07-26T11:27:44.657' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblSubCategory] ([Id], [CategoryId], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [Discription], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (3, NULL, N'Vegetable Seed', N'Vegetable Seed', N'Vegetable Seed', N'/SubCatgory/Vegetable_Seed_0.jpeg', 0, NULL, CAST(N'2021-07-26T11:25:27.247' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblSubCategory] ([Id], [CategoryId], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [Discription], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (4, NULL, N'Flower Seed', N'Flower Seed', N'Flower Seed', N'/SubCatgory/Flower_Seed_2.jpeg', 1, NULL, CAST(N'2021-07-26T11:23:49.670' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblSubCategory] ([Id], [CategoryId], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [Discription], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (5, NULL, N'vegetable', N'vegetable', N'vegetable', N'/SubCatgory/vegetable_8.jpeg', 1, NULL, CAST(N'2021-07-26T11:22:10.397' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblSubCategory] ([Id], [CategoryId], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [Discription], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (6, NULL, N'Sugar Kane', N'Oos', N'Gannaa', N'/SubCatgory/Sugar_Kane_0.jpeg', 1, NULL, CAST(N'2021-07-26T15:13:09.940' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblSubCategory] ([Id], [CategoryId], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [Discription], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (7, NULL, N'Onion', N'Kanda', N'Pyaj', N'/SubCatgory/Onion_3.jpeg', 1, NULL, CAST(N'2021-07-26T11:15:53.600' AS DateTime), 1, NULL, NULL)
GO
INSERT [dbo].[tblSubCategory] ([Id], [CategoryId], [Name_ENG], [Name_MAR], [Name_HIN], [ImagePath], [Active], [Discription], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy]) VALUES (8, NULL, N'beet root', N'Beet root', N'Beet root', N'/SubCatgory/beet_root_5.jpeg', 1, NULL, CAST(N'2021-07-26T11:15:23.910' AS DateTime), 1, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[tblSubCategory] OFF
GO
 
SET IDENTITY_INSERT [dbo].[TblUser] ON 
GO
INSERT [dbo].[TblUser] ([Id], [FullName], [Email], [Mobile], [IsMobileVerified], [Password], [Otp], [OtpExpiredTime], [IsOtpVerified], [CreatedDate], [UpdatedDate], [CreatedBy], [UpdatedBy], [IsActive], [ReferCode], [ReferId], [ProfilePath]) VALUES (1, N'Pradip Warambhe', NULL, N'9404822001', 0, N'BhVNviA0q7ERN5Un3AzIPg==', N'1111', CAST(N'2021-06-15T08:01:40.317' AS DateTime), 1, CAST(N'2021-06-15T07:01:44.680' AS DateTime), CAST(N'2021-08-16T09:15:25.380' AS DateTime), NULL, 16, 1, N'FC3JR7', 0, N'/ProfilePhoto/User_ProfilePhoto_7853_jpeg')
GO
INSERT [dbo].[TblUser] ([Id], [FullName], [Email], [Mobile], [IsMobileVerified], [Password], [Otp], [OtpExpiredTime], [IsOtpVerified], [CreatedDate], [UpdatedDate], [CreatedBy], [UpdatedBy], [IsActive], [ReferCode], [ReferId], [ProfilePath]) VALUES (2, N'A D', NULL, N'1324567890', 0, N'fc0iUkg331qk3V8HY6MWvQ==', N'1111', CAST(N'2021-06-15T10:44:39.740' AS DateTime), 1, CAST(N'2021-06-15T09:51:19.117' AS DateTime), NULL, NULL, NULL, 1, N'APJZ1Z', 0, NULL)
GO
INSERT [dbo].[TblUser] ([Id], [FullName], [Email], [Mobile], [IsMobileVerified], [Password], [Otp], [OtpExpiredTime], [IsOtpVerified], [CreatedDate], [UpdatedDate], [CreatedBy], [UpdatedBy], [IsActive], [ReferCode], [ReferId], [ProfilePath]) VALUES (3, N'string', NULL, N'8888888888', 0, N'BhVNviA0q7ERN5Un3AzIPg==', N'1111', CAST(N'2021-06-15T12:28:18.110' AS DateTime), 1, CAST(N'2021-06-15T11:28:26.290' AS DateTime), NULL, NULL, NULL, 1, N'2BGYQ3', 0, NULL)
GO
INSERT [dbo].[TblUser] ([Id], [FullName], [Email], [Mobile], [IsMobileVerified], [Password], [Otp], [OtpExpiredTime], [IsOtpVerified], [CreatedDate], [UpdatedDate], [CreatedBy], [UpdatedBy], [IsActive], [ReferCode], [ReferId], [ProfilePath]) VALUES (4, N'raj', NULL, N'8999292302', 0, N'ybNQtnO9bkX0aXbS74K8aQ==', N'1111', CAST(N'2021-06-15T12:50:07.007' AS DateTime), 1, CAST(N'2021-06-15T11:50:10.617' AS DateTime), NULL, NULL, NULL, 1, N'8HIQGO', 0, NULL)
GO
INSERT [dbo].[TblUser] ([Id], [FullName], [Email], [Mobile], [IsMobileVerified], [Password], [Otp], [OtpExpiredTime], [IsOtpVerified], [CreatedDate], [UpdatedDate], [CreatedBy], [UpdatedBy], [IsActive], [ReferCode], [ReferId], [ProfilePath]) VALUES (5, N'Abhi D', NULL, N'9876543210', 0, N'fc0iUkg331qk3V8HY6MWvQ==', N'1111', CAST(N'2021-07-16T05:49:35.080' AS DateTime), 1, CAST(N'2021-06-15T13:15:27.737' AS DateTime), NULL, NULL, NULL, 1, N'719GBU', 0, NULL)
GO
INSERT [dbo].[TblUser] ([Id], [FullName], [Email], [Mobile], [IsMobileVerified], [Password], [Otp], [OtpExpiredTime], [IsOtpVerified], [CreatedDate], [UpdatedDate], [CreatedBy], [UpdatedBy], [IsActive], [ReferCode], [ReferId], [ProfilePath]) VALUES (6, N'Abhishek D', NULL, N'8857870272', 0, N'fc0iUkg331qk3V8HY6MWvQ==', N'1111', CAST(N'2021-08-25T06:18:40.757' AS DateTime), 1, CAST(N'2021-06-16T06:33:11.423' AS DateTime), CAST(N'2021-08-25T05:28:51.783' AS DateTime), NULL, 6, 1, N'36A2MC', 0, NULL)
GO
 
SET IDENTITY_INSERT [dbo].[TblUser] OFF
GO
SET IDENTITY_INSERT [dbo].[tblUserAddress] ON 
GO
INSERT [dbo].[tblUserAddress] ([Id], [UserId], [HouseNo], [AppartmentName], [StreetDetails], [Landmark], [AreaName], [Pincode], [Contact], [AddressType], [niknameAddress], [Isdefault], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [City]) VALUES (1, 26, N'23424', N'234214', N'32141', N'213414', N'12424', N'231412', N'2134412414', 2, N'', 1, CAST(N'2021-07-14T08:32:15.713' AS DateTime), 26, CAST(N'2021-08-21T16:29:23.147' AS DateTime), 26, N'12341234')
GO
INSERT [dbo].[tblUserAddress] ([Id], [UserId], [HouseNo], [AppartmentName], [StreetDetails], [Landmark], [AreaName], [Pincode], [Contact], [AddressType], [niknameAddress], [Isdefault], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [City]) VALUES (2, 6, N'22', N'gohel', N'camp road', N'ekatmata chauk', NULL, N'423203', N'8857870272', 1, N'', 0, CAST(N'2021-07-15T10:39:42.270' AS DateTime), 6, CAST(N'2021-08-24T12:33:47.403' AS DateTime), 6, N'pune')
GO
INSERT [dbo].[tblUserAddress] ([Id], [UserId], [HouseNo], [AppartmentName], [StreetDetails], [Landmark], [AreaName], [Pincode], [Contact], [AddressType], [niknameAddress], [Isdefault], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [City]) VALUES (7, 19, N'190', N'asdf', N'asdf', N'jdjdndn', N'fdgdf', N'411033', N'9876543210', 1, N'fdgdf', 1, CAST(N'2021-07-22T08:08:20.737' AS DateTime), 19, NULL, NULL, N'PUNE')
GO
INSERT [dbo].[tblUserAddress] ([Id], [UserId], [HouseNo], [AppartmentName], [StreetDetails], [Landmark], [AreaName], [Pincode], [Contact], [AddressType], [niknameAddress], [Isdefault], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [City]) VALUES (9, 7, N'1734', N'radha', N'rethare bk ', N'near hp petrol pump', N'fgdfg', N'415108', N'9876543210', 1, N'gdfgdfg', 1, CAST(N'2021-07-26T04:46:34.233' AS DateTime), 7, NULL, NULL, N'PUNE')
GO
INSERT [dbo].[tblUserAddress] ([Id], [UserId], [HouseNo], [AppartmentName], [StreetDetails], [Landmark], [AreaName], [Pincode], [Contact], [AddressType], [niknameAddress], [Isdefault], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [City]) VALUES (10, 18, N'411', N'narendra chaya', N'mamta sweet', N'Aadhar school', NULL, N'411033', N'9130823368', 2, N'', 0, CAST(N'2021-07-26T07:30:35.023' AS DateTime), 18, CAST(N'2021-09-18T08:41:23.033' AS DateTime), 18, N'chinchwad')
GO
INSERT [dbo].[tblUserAddress] ([Id], [UserId], [HouseNo], [AppartmentName], [StreetDetails], [Landmark], [AreaName], [Pincode], [Contact], [AddressType], [niknameAddress], [Isdefault], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [City]) VALUES (25, 1, N'12', N'shivsadan', N'sp road', N'near sai garden', N'santnagar', N'111222', N'9922636950', 1, N'ssssss', 1, CAST(N'2021-08-10T06:08:20.013' AS DateTime), 1, NULL, NULL, N'satara')
GO
INSERT [dbo].[tblUserAddress] ([Id], [UserId], [HouseNo], [AppartmentName], [StreetDetails], [Landmark], [AreaName], [Pincode], [Contact], [AddressType], [niknameAddress], [Isdefault], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [City]) VALUES (30, 12, N'283', N'Digvijay Plaza', N'ZP Colony', N'Jotiba Mandir', N'Agashiv', N'415112', N'9545238469', 1, N'', 1, CAST(N'2021-08-12T12:50:05.553' AS DateTime), 12, NULL, NULL, N'Karad')
GO
INSERT [dbo].[tblUserAddress] ([Id], [UserId], [HouseNo], [AppartmentName], [StreetDetails], [Landmark], [AreaName], [Pincode], [Contact], [AddressType], [niknameAddress], [Isdefault], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [City]) VALUES (32, 16, N'123', N'Sample', N'test', N'test', NULL, N'411033', N'8237869599', 1, N'', 0, CAST(N'2021-08-20T14:38:54.247' AS DateTime), 16, CAST(N'2021-09-17T07:09:55.290' AS DateTime), 16, N'Malegaon')
GO
INSERT [dbo].[tblUserAddress] ([Id], [UserId], [HouseNo], [AppartmentName], [StreetDetails], [Landmark], [AreaName], [Pincode], [Contact], [AddressType], [niknameAddress], [Isdefault], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [City]) VALUES (38, 16, N'22', N'Gohel Bunglow', N'Camp Road', N'Ekatmata Chouk', NULL, N'423203', N'8237869599', 1, NULL, 0, CAST(N'2021-08-21T15:25:36.673' AS DateTime), 16, NULL, NULL, N'Malegaon')
GO
INSERT [dbo].[tblUserAddress] ([Id], [UserId], [HouseNo], [AppartmentName], [StreetDetails], [Landmark], [AreaName], [Pincode], [Contact], [AddressType], [niknameAddress], [Isdefault], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [City]) VALUES (39, 26, N'qweeq', N'we', N'w', N'w', N'94048weqe', N'411061', N'2200323131', 1, N'', 0, CAST(N'2021-08-21T16:35:35.390' AS DateTime), 26, NULL, NULL, N'A')
GO
INSERT [dbo].[tblUserAddress] ([Id], [UserId], [HouseNo], [AppartmentName], [StreetDetails], [Landmark], [AreaName], [Pincode], [Contact], [AddressType], [niknameAddress], [Isdefault], [CreatedDate], [CreatedBy], [UpdatedDate], [UpdatedBy], [City]) VALUES (41, 52, N'1', N'digvijay plaza', N'zp colony', N'jotiba mandir', NULL, N'415112', N'9545238470', 1, NULL, 1, CAST(N'2021-08-23T07:47:20.560' AS DateTime), 52, NULL, NULL, N'karad')
GO 
SET IDENTITY_INSERT [dbo].[tblUserAddress] OFF
GO 



ALTER TABLE [dbo].[tblOrderDetail]  WITH CHECK ADD  CONSTRAINT [FK_tblOrderDetail_tblOrder] FOREIGN KEY([OrderId])
REFERENCES [dbo].[tblOrder] ([Id])
GO
ALTER TABLE [dbo].[tblOrderDetail] CHECK CONSTRAINT [FK_tblOrderDetail_tblOrder]
GO
ALTER TABLE [dbo].[tblProduct]  WITH CHECK ADD  CONSTRAINT [FK_tblProduct_tblCategory] FOREIGN KEY([CategoryId])
REFERENCES [dbo].[tblCategory] ([Id])
GO
ALTER TABLE [dbo].[tblProduct] CHECK CONSTRAINT [FK_tblProduct_tblCategory]
GO
ALTER TABLE [dbo].[tblSubCategory]  WITH CHECK ADD  CONSTRAINT [FK_tblSubCategory_tblCategory] FOREIGN KEY([CategoryId])
REFERENCES [dbo].[tblCategory] ([Id])
GO
ALTER TABLE [dbo].[tblSubCategory] CHECK CONSTRAINT [FK_tblSubCategory_tblCategory]
GO
ALTER TABLE [dbo].[tblUserAddress]  WITH CHECK ADD  CONSTRAINT [FK_tblUserAddress_tblUser] FOREIGN KEY([UserId])
REFERENCES [dbo].[TblUser] ([Id])
GO
ALTER TABLE [dbo].[tblUserAddress] CHECK CONSTRAINT [FK_tblUserAddress_tblUser]
GO

/****** Object:  StoredProcedure [dbo].[csp_LogExceptionToDB]    Script Date: 22-Sep-21 6:05:32 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC [dbo].[csp_LogExceptionToDB]
@source varchar(100),
@LogDateTime varchar(8000),
@Message varchar(1000),
@QueryString varchar(2000),
@TargetSite varchar(300),
@StackTrace varchar(4000),
@ServerName varchar(300),
@RequestURL varchar(300),
@UserAgent varchar(300),
@UserIP varchar(300),
@UserAuthentication varchar(300),
@UserName varchar(300)

AS

INSERT INTO tblExceptionLogItems
(Source, LogDateTime,Message,QueryString,TargetSite,StackTrace,ServerName,RequestURL,
UserAgent,UserIP,UserAuthentication,UserName)
Values ( 
@Source,
@LogDateTime,
@Message,
@QueryString,
@TargetSite,
@StackTrace,
@ServerName,
@RequestURL,
@UserAgent,
@UserIP,
@UserAuthentication,
@UserName
)
GO
USE [master]
GO
ALTER DATABASE [Product] SET  READ_WRITE 
GO

export const environment = {
  production: true,
  domainpath: 'https://product.knackbe.in/',
  apiurl: 'https://productapi.knackbe.in/api/'

};

export const environment = {
  production: false,
  domainpath: 'https://productapi.knackbe.in/',
  apiurl: 'https://productapi.knackbe.in/api/'

};

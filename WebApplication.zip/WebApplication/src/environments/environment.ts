export const environment = {
  production: false,
  domainpath: 'https://product.knackbe.in/',
  apiurl: 'https://productapi.knackbe.in/api/'
};
(function ($) {
  "use strict";


  // catagory-container swiper slider init
  // var catagoryContainer = new Swiper('.catagory-container', {
  //   slidesPerView: 6,
  //   loop: true,
  //   navigation: {
  //     nextEl: '.catagory-slider-next',
  //     prevEl: '.catagory-slider-prev',
  //   },
  //   spaceBetween: 30,
  //   breakpoints: {
  //     990: {
  //       slidesPerView: 4
  //     },
  //     768: {
  //       slidesPerView: 2
  //     },
  //     540: {
  //       slidesPerView: 2
  //     },
  //     400: {
  //       slidesPerView: 2
  //     }
  //   }
  // });


  $('.info-hover-effect-parent').on('mouseover', '.info-hover-effect-child', function () {
    $('.info-hover-effect-child.active').removeClass('active');
    $(this).addClass('active');
  });

  $('.product-slick').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    fade: true,
    asNavFor: '.slider-nav'
  });

  $('.slider-nav').slick({
    vertical: false,
    slidesToShow: 4,
    slidesToScroll: 1,
    centerMode: true,
    asNavFor: '.product-slick',
    arrows: true,
    dots: false,
    focusOnSelect: true
  });



  $('.add-product img').elevateZoom({
    zoomType: "inner",
    scrollZoom: true
  });


  $(".wish-link").on("click", function (e) {
    e.preventDefault();
    $(this).toggleClass("focus");
    // $("p").toggleClass("main");
  });

  $(".all-catagory-option > a").on("click", function (e) {
    $('.page-layout').toggleClass('open-side-menu')
    $('body').toggleClass('open-side-menu')
  });

  var contentwidth = jQuery(window).width();

  // if ((contentwidth) > '1200') {
  //   $('.home-layout').addClass('open-side-menu')
  // }

  // if ((contentwidth) > '1200') {
  //   $('.sticky-sidebar-home').addClass('open-side-menu')
  // }

  if ((contentwidth) < '991') {
    $('.widget .widget-wrapper').addClass('collapse')
  }

  if ((contentwidth) < '991') {
    $('.cart-btn-toggle').removeAttr('onclick');
  }


  // $('.cart-product-item>.close-item').on('click', function () {
  //   $(this).parent('.cart-product-item').remove();
  // })

  $('.wishlist-item>.close-item').on('click', function () {
    $(this).parent('.wishlist-item').remove();
  })


  // fixed menu app home page
  $(window).on("scroll", function () {
    var scroll = $(window).scrollTop();

    if (scroll >= 100) {
      $(".header-bottom,.mobile-header,.catagory-sidebar-area").addClass("fixed-totop animated slideInDown");
    } else {
      $(".header-bottom,.mobile-header,.catagory-sidebar-area").removeClass("fixed-totop  animated slideInDown");
    }
  });


  //popup
  $('.popup-close').on("click", function () {
    $('#popup').hide();
  });

   //popup
   $('.popup-close1').on("click", function () {
    $('#popup1').hide();
  });

  $(document).ready(function () {

    if (!localStorage.getItem('area')) {
      $("#popup").delay(2000).fadeIn();
    }else{
      // $("#popup1").delay(2000).fadeIn();
    }
  });


})(jQuery);



function openarea() {
  $("#popup").delay(500).fadeIn();
}


function selectme(option) {

  var optionList = option.parentNode.children;
  for (let i = 0; i < optionList.length; i++) {
    optionList[i].classList.remove('same-as-selected');
  }
  option.classList.add('same-as-selected');
  // let select = option.parentNode.parentNode.children[0];
  let showselect = option.parentNode.parentNode.children[1];
  showselect.innerHTML = option.innerText;

}

function cartopen() {
  document.getElementById("sitebar-cart").classList.add('open-cart');
  document.getElementById("sitebar-drawar").classList.add('hide-drawer');
}

function cartclose() {
  document.getElementById("sitebar-cart").classList.remove('open-cart');
  document.getElementById("sitebar-drawar").classList.remove('hide-drawer');
}
// open modal
function openModal() {
  document.getElementById("product-details-popup").classList.add('open-side');
}

function closeModal() {
  document.getElementById("product-details-popup").classList.remove('open-side');
}

// open signup form
function OpenSignUpForm() {
  document.getElementById("login-area").classList.add('open-form');
}

function CloseSignUpForm() {
  document.getElementById("login-area").classList.remove('open-form');
}

// function openCancelOrderForm() {
//   document.getElementById("cancel-order").classList.add('open-form');
// }

// function closeCancelOrderForm() {
//   document.getElementById("cancel-order").classList.remove('open-form');
// }

// function OpenComplaintForm() {
//   document.getElementById("complaint").classList.add('open-form');
// }

// function closeComplaintForm() {
//   document.getElementById("complaint").classList.remove('open-form');
// }


function OpenDonationdiscriptionForm() {
  document.getElementById("discription").classList.add('open-form');
}

function closeDonationdiscriptionForm() {
  document.getElementById("discription").classList.remove('open-form');
}


function OpenDonationhomepopupForm() {
  document.getElementById("donationhome").classList.add('open-form');
}

function closeDonationhomepopupForm() {
  document.getElementById("donationhome").classList.remove('open-form');
}

function topsellingsiwpperApply() {
  // trending-product-container swiper slider init ---top selling
  var trendingContainer = new Swiper('.trending-product-container', {
    slidesPerView: 4,
    loop: true,
    navigation: {
      nextEl: '.trending-slider-next',
      prevEl: '.trending-slider-prev',
    },
    spaceBetween: 30,
    breakpoints: {
      1200: {
        slidesPerView: 3
      },
      990: {
        slidesPerView: 3
      },
      768: {
        slidesPerView: 2
      },
      540: {
        slidesPerView: 1
      },
      400: {
        slidesPerView: 1
      }
    }
  });
}



function offerswipperApply() {

  // trending-product-container swiper slider init  --- offers
  var recommendContainer = new Swiper('.recommend-product-container', {
    slidesPerView: 4,
    loop: false,
    navigation: {
      nextEl: '.recomended-slider-next',
      prevEl: '.recomended-slider-prev',
    },
    spaceBetween: 30,
    breakpoints: {
      1200: {
        slidesPerView: 3
      },
      990: {
        slidesPerView: 3
      },
      768: {
        slidesPerView: 2
      },
      540: {
        slidesPerView: 1
      },
      400: {
        slidesPerView: 1
      }
    }
  });
}




function bannerswipperApply() {

  // trending-product-container swiper slider init  --- offers
  var recommendContainer = new Swiper('.banner-container', {
    slidesPerView: 1,
    loop: true,
    navigation: {
      nextEl: '.trending-slider-next',
      prevEl: '.trending-slider-prev',
    },
    spaceBetween: 0,
    breakpoints: {
      1200: {
        slidesPerView: 1
      },
      990: {
        slidesPerView: 1
      },
      768: {
        slidesPerView: 1
      },
      540: {
        slidesPerView: 1
      },
      400: {
        slidesPerView: 1
      }
    }
  });
}


function categoryswipperApply() {

  // trending-product-container swiper slider init  --- offers
  var recommendContainer1 = new Swiper('.catagory-container', {
    slidesPerView: 6,
    loop: true,
    navigation: {
      nextEl: '.catagory-slider-next',
      prevEl: '.catagory-slider-prev',
    },
    spaceBetween: 30,
    breakpoints: {
      990: {
        slidesPerView: 4
      },
      768: {
        slidesPerView: 2
      },
      540: {
        slidesPerView: 2
      },
      400: {
        slidesPerView: 2
      }
    }
  });
}


function memberswipperApply() {

  var infoBoxContainer = new Swiper('.info-box-container', {
    slidesPerView: 3,
    loop: true,
    centeredSlides: true,
    initialSlide: 2,
    spaceBetween: 30,
    autoplay: {
      delay: 3500,
      disableOnInteraction: false,
    },
    breakpoints: {
      990: {
        slidesPerView: 2
      },
      767: {
        slidesPerView: 1
      }
    }
  });
}

function swipperApplyforProd(input) {

  var nextElClass = '.product-slider-next_' + input.value;
  var prevElClass = '.product-slider-prev_' + input.value;
  var scrollclass = '.scoller-product-container_' + input.value;

  var recommendContainer13 = new Swiper(scrollclass, {
    slidesPerView: 4,
    loop: true,
    navigation: {
      nextEl: nextElClass,
      prevEl: prevElClass,
    },
    spaceBetween: 30,
    // autoplay: {
    //   delay: 3500,
    //   disableOnInteraction: false,
    // },
    breakpoints: {
      1200: {
        slidesPerView: 3
      },
      990: {
        slidesPerView: 3
      },
      768: {
        slidesPerView: 2
      },
      540: {
        slidesPerView: 1
      },
      400: {
        slidesPerView: 1
      }
    }
  });
}


function relatedswipperApply() {

  // trending-product-container swiper slider init  --- offers
  var recommendContainer12 = new Swiper('.recommend-product-container', {
    slidesPerView: 4,
    loop: true,
    navigation: {
      nextEl: '.recomended-slider-next',
      prevEl: '.recomended-slider-prev',
    },
    spaceBetween: 30,
    breakpoints: {
      1200: {
        slidesPerView: 3
      },
      990: {
        slidesPerView: 3
      },
      768: {
        slidesPerView: 2
      },
      540: {
        slidesPerView: 1
      },
      400: {
        slidesPerView: 1
      }
    }
  });
}

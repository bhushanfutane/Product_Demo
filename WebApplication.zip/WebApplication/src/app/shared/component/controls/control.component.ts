import { Component, Input, OnInit } from '@angular/core';
import { ICartList } from '../../model/cart.model';
import { Messagetype } from '../../model/enum';
import { IProduct, } from '../../model/product.model';
import { HttpStatusCode, ResponseModel } from '../../model/response.model';
import { IUserInfo } from '../../model/userinfo.model';
import { ApiDataService } from '../../services/apidata.service';
import { AppService } from '../../services/app.service';
import { GetSetService } from '../../services/getset.serverce';
import { ProductService } from '../../services/product.service';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-control',
  templateUrl: 'control.component.html'
})
export class ControlComponent implements OnInit {

  userInfo?: IUserInfo;
  @Input() product!: IProduct;
  @Input() fromCart = false;

  public isUserLoggedIn = this.getsetService.isloggedInUser();
  selected = '0';
  constructor(
    private getsetService: GetSetService,
    private appservice: AppService,
    private apidata: ApiDataService,
    private toast: ToastService
  ) {

  }


  ngOnInit(): void {
  }


  addtocart(isUpdate: boolean = false): void {
    let cartItem: any;
    const isUserLogin = this.getsetService.isloggedInUser();
    if (!isUpdate) {
      cartItem = {
       productId: this.product?.id,
        quantity: this.product?.quantity === 0 ? 1 : +this.product?.quantity,
      };
    } else {
      cartItem = {
        productId: this.product?.id,
        quantity: this.product?.quantity === 0 ? 1 : +this.product?.quantity,
      };
    }

    if (isUserLogin) {
      const user = this.getsetService.getCurrentUserInfo();

      if (user) {
        this.userInfo = user;
      }

      const url = `Cart/AddToCart`;
      this.apidata
        .postData(url, cartItem)
        .subscribe((response: ResponseModel<any>) => {

          if (response.status === HttpStatusCode.OK) {
            if (this.product.quantity === 1) {
              this.toast.showToast(Messagetype.sucess, 'info', 'Item successfully added to cart.');
            }
            this.appservice.setCart(true);
            if (this.product) {
              this.product.isInCart = true;
            }
            this.appservice.setSelectedArea(true);
          } else if (
            response.status === HttpStatusCode.INTERNAL_SERVER_ERROR
          ) {

            this.toast.showToast(Messagetype.fail, 'info', `${response.statusMessage}`);

          } else {
            this.toast.showToast(Messagetype.fail, 'info', `${response.statusMessage}`);
          }
        });



    } else {
      if (!isUpdate) {
        if (this.getsetService.getArea() == null) {
          // this.openAreaDialog();
        } else {

            this.toast.showToast(
              Messagetype.fail,
              'Info',
              `Service not available in this area.`
            );

          }
        }

    }




  }



  // tslint:disable-next-line:typedef
  increment() {
    if (this.product) {
      this.product.quantity = (this.product) ? this.product?.quantity + 1 : 1;
      this.addtocart(true);
    }
  }


  decrement() {
    if (this.product.quantity > 1) {
      this.product.quantity = this.product?.quantity - 1;
      if (this.product.quantity === 0) {
        // this.removetocart();

      } else if (this.product.quantity !== 1) {
        this.addtocart(true);
      }
    } else {
      this.toast.showToast(
        Messagetype.fail,
        'Info',
        `Product Quantity Should be one`
      );
    }
  }


  removetocart(): void {

    const isUserLogin = this.getsetService.isloggedInUser();



    if (isUserLogin) {
      // add to database
      if (this.getsetService.getArea()?.isServiceAvailable) {
        const user = this.getsetService.getCurrentUserInfo();
        if (user) {
          this.userInfo = user;
        }

        const url = `Cart/RemoveCart?ProductId=${this.product?.id}`;
        this.apidata
          .getData(url)
          .subscribe((response: ResponseModel<any>) => {
            if (response.status === HttpStatusCode.OK) {

              this.toast.showToast(Messagetype.sucess, 'info', 'Item successfully removed from cart.');

              this.appservice.setCart(true);
              if (this.product) {
                this.product.isInCart = false;
              }
              this.appservice.setSelectedArea(true);
            } else if (
              response.status === HttpStatusCode.INTERNAL_SERVER_ERROR
            ) {

              this.toast.showToast(Messagetype.fail, 'info', `${response.statusMessage} `);

            } else {
              this.toast.showToast(Messagetype.fail, 'info', `${response.statusMessage} `);
            }
            });
      } else {

        this.toast.showToast(Messagetype.fail, 'info', `Service not available in this area.`);
      }


    } else {

      // add to temp cart
    }




  }

}

import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { IAddress } from '../../model/address.model';
import { IArea, IAreabyCity } from '../../model/area.model';
import { ICity } from '../../model/city.model';
import { Messagetype } from '../../model/enum';
import { HttpStatusCode, ResponseModel } from '../../model/response.model';
import { ApiDataService } from '../../services/apidata.service';
import { AppService } from '../../services/app.service';
import { GetSetService } from '../../services/getset.serverce';
import { ToastService } from '../../services/toast.service';


@Component({
  selector: 'app-address',
  templateUrl: 'address.component.html',
  styleUrls: ['address.component.scss']
})
export class AddressComponent implements OnInit {

  @ViewChild('cancelmodel') cancelmodel?: ElementRef;

  @Input() selectedAddress: number = 0;
  @Input() fromAccont: boolean = false;



  @Output() onselected = new EventEmitter();

  showaddress = true;
  saveloader = false;

  addreshForm: FormGroup;
  submitted = false;
  adresess: IAddress[] = [];
  selectedadreses?: IAddress;
  addressId = 0;
  areaname = '';
  isDefaultChecked = false;
  isServicible = false;
  copyOfDefaulAddress: any;
  addressTypeId = 1;
  disableSaveBtn = false;
  areaListofSelectedPinCode: Array<any> = [];
  addressService: any;
  billingForm: any;
  snackBar: any;
  savedArea: any;
  areaId = 0;

  isShowMessage = false;


  constructor(
    private apidataservice: ApiDataService,
    private getSetService: GetSetService,
    private appservice: AppService,
    private apiservice: ApiDataService,
    private formBuilder: FormBuilder,
    private toastService: ToastService


  ) {
    this.addreshForm = this.formBuilder.group({
      houseNo: ['', Validators.required],
      appartment: ['', Validators.required],
      streetDetails: ['', Validators.required],
      landmark: ['', Validators.required],
      cityId: ['', Validators.required],
      zip: ['', Validators.required],
      area: ['', Validators.required],
      isDefault: [true],
      contact: ['', Validators.required]

    });
  }

  get f() { return this.addreshForm.controls; }

  ngOnInit(): void {
    // this.getCityList();
    this.getUserDefaultAddress(false);

    this.appservice.getSelectedArea().subscribe(() => {
      this.getSavedarea();
      this.getUserDefaultAddress(false);
    });

  }

  resetForm() {
    this.submitted = false;
    this.addreshForm.reset();
  }

  getSavedarea(): void {

    this.savedArea = this.getSetService.getArea();
    if (!this.savedArea) {
    } else {
      this.areaId = this.savedArea.areaId;
    }
  }

  public getUserDefaultAddress(makeselectedLatest: boolean) {
    const url = `UserAddress/GetUserAddress`;
    this.apidataservice
      .getData(url)
      .subscribe((response: ResponseModel<any>) => {
        if (response.status === HttpStatusCode.OK) {
          this.adresess = response.data;
          this.selectedadreses = this.adresess.find(m => m.isdefault);

          if (makeselectedLatest) {
            this.selectedadreses = this.adresess[0];
          }
          this.onselected.emit(this.selectedadreses);

          if (this.adresess.length > 1) {
            this.showaddress = false;
          }
        }
      });
  }
  onSelectDefaultAddress(event: any) {
    this.isDefaultChecked = event.target.checked;
  }

  public addNewAddress() {
    debugger;

    this.submitted = true;
    if (this.addreshForm.valid) {
      this.saveloader = true;
      const data: IAddress = {
        id: this.addressId,
        houseNo: this.addreshForm.value.houseNo,
        appartmentName: this.addreshForm.value.appartment,
        streetDetails: this.addreshForm.value.streetDetails,
        landmark: this.addreshForm.value.landmark,
        contact: this.addreshForm.value.contact,
        areaName: this.addreshForm.value.area,
        city: this.addreshForm.value.cityId,
        pincode: this.addreshForm.value.zip,
        addressType: this.addressTypeId,
        niknameAddress: '',
        isdefault:   this.isDefaultChecked,
        areaCode: '',
      };


      let url = '';
      if (this.addressId === 0) {
        url = `UserAddress/AddUserAddress`;
      } else {
        url = `UserAddress/UpdateUserAddress`;
      }
      this.apidataservice
        .postData(url, data)
        .subscribe((response: ResponseModel<any>) => {
          if (response.status === HttpStatusCode.OK) {
            if (this.addressId === 0) {
              this.toastService.showToast(Messagetype.sucess, 'Info', 'Address added');
            } else {
              this.toastService.showToast(Messagetype.sucess, 'Info', 'Updated address');
            }
            this.addressId = 0;
            this.getUserDefaultAddress(true);
            this.closepopup();
          } else {
            this.toastService.showToast(Messagetype.fail, 'Info', `${response.statusMessage}`);
            this.addressId = 0;
          }

          this.saveloader = false;
        });
    }
  }

  editAddress(address: IAddress) {
    this.copyOfDefaulAddress = address;
    this.addressId = address.id;

    this.addreshForm.controls.houseNo.setValue(address.houseNo);
    this.addreshForm.controls.appartment.setValue(address.appartmentName);
    this.addreshForm.controls.streetDetails.setValue(address.streetDetails);
    this.addreshForm.controls.landmark.setValue(address.landmark);
    this.addreshForm.controls.cityId.setValue(address.city);
    this.addreshForm.controls.zip.setValue(address.pincode);
    this.addreshForm.controls.area.setValue(address.areaName);

    this.addreshForm.controls.contact.setValue(address.contact);
    this.areaname = address.areaName;
    this.addressTypeId = address.addressType;
    this.isDefaultChecked = address.isdefault;
  }

  deleteAddresh(id: number) {
    const url = `UserAddress/DeleteUserAddress?Id=${id}`;
    this.apidataservice.postData(url, '').subscribe
      ((response: ResponseModel<any>) => {
        if (response.status === HttpStatusCode.OK) {
          this.toastService.showToast(Messagetype.sucess, 'Info', 'Deleted address');
          this.getUserDefaultAddress(false);
        }
      });
  }
  deliverAddressUpdate(id: number) {
    const url = `UserAddress/Deliverhere?addressId=${id}`;
    this.apidataservice.getData(url).subscribe
      ((response: ResponseModel<any>) => {
        if (response.status === HttpStatusCode.OK) {
          this.toastService.showToast(Messagetype.sucess, 'Info', 'address selected');
          this.getUserDefaultAddress(false);
        }
      });
  }

  selectType(id: number): void {
    this.addressTypeId = id;
  }


  selectAddress(address: IAddress) {
    this.selectedadreses = address;
    this.onselected.emit(address);
    this.deliverAddressUpdate(address.id);
  }

  closepopup() {
    document.getElementById('cancelmodel')?.click();
  }

  isNumber(evt: any) {
    evt = evt ? evt : window.event;
    const charCode = evt.which ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }


  markerDragEnd($event: MouseEvent | any) {
  }

  public checkServicible(evt: any) {
    if (evt.target.value.length === 6) {
      const url = `Shyplite/AreaServicible?Pincode=${evt}`;
      this.apidataservice.getData(url).subscribe
        ((response: ResponseModel<any>) => {
          if (response.status === HttpStatusCode.OK) {
            this.isServicible = response.data;
          }
        });
    }else{
      this.isServicible = false;
    }
  }
}

import { AfterViewInit, Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Messagetype } from '../../model/enum';
import { IProduct } from '../../model/product.model';
import { ResponseModel, HttpStatusCode } from '../../model/response.model';
import { ApiDataService } from '../../services/apidata.service';
import { AppService } from '../../services/app.service';
import { DropdownService } from '../../services/dropdown.service';
import { GetSetService } from '../../services/getset.serverce';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-product',
  templateUrl: 'product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit, AfterViewInit {

  @Input() product?: IProduct;
  currentLang = 'en';
  public subscriptions$: Subscription[] = [];
  quantity = 1;
  products = [];
  selected: string | undefined;
  constructor(
    private authService: ApiDataService,
    private getset: GetSetService,
    private toastService: ToastService,
    private appservice: AppService,
    public translate: TranslateService,
    private dropdownService: DropdownService

  ) {
  }
  ngAfterViewInit(): void {

  }

  ngOnInit(): void {
    this.subscriptions$.push(
      // languge Subscription
      this.appservice.getcurrentLanguage().subscribe((lng: any) => {
        this.currentLang = lng;
      })
    );
    this.currentLang = this.getset.getlanguge();
  }
  public changeSize(size: any, product: any) {

    product.size = +size.target.value;
  }
  showpopup() {
    if (this.product) {
      this.appservice.setProduct(this.product);
    }
  }

  public loadScript() {
    const dynamicScripts = [
      environment.domainpath + 'assets/js/custom-select.js',
    ];

    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < dynamicScripts.length; i++) {
      const node = document.createElement('script');
      node.src = dynamicScripts[i];
      node.type = 'text/javascript';
      node.async = false;
      node.charset = 'utf-8';
      document.getElementsByTagName('head')[0].appendChild(node);
    }
  }


  increment(product: any) {
    this.quantity = this.quantity + 1;
    if (this.quantity > 10) {
      this.quantity = 10;
    }
    product.quantity = this.quantity;
  }

  decrement(product: any) {
    if (this.quantity > 1) {
      this.quantity = this.quantity - 1;
      product.quantity = this.quantity;
    } else {
      this.toastService.showToast(
        Messagetype.fail,
        'Info',
        `Product Quantity Should be one`
      );
    }
  }


}

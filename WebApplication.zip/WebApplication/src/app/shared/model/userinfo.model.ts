export interface IUserInfo {
  areaId: number;
  areaNameENg: string;
  areaNameHin: string;
  areaNameMar: string;
  cityEng: string;
  cityHin: string;
  cityMar: string;
  email: string;
  firstName: string;
  isServiceAvailable: false
  languageId: number;
  lastName: string;
  mobileNumber: string;
  pincode: null
  profilePath: string;
  refercode: string;
  refreshToken: string;
  refresh_ValidTill: string;
  role: string;
  roleId: number;
  token: string;
  userId: number;
  validTill: string;
}

export interface IAddress {
  id: number;
  houseNo: string;
  appartmentName: string;
  streetDetails: string;
  landmark: string;
  city: string;
  areaName: string;
  pincode: string;
  addressType: number;
  niknameAddress: string;
  isdefault: boolean;
  areaCode: string;
  contact: string;
}


export interface ITCategory {
  id: number;
  englishName: string;
  marathiName: string;
  hindiName: string;
  imagePath: string;
  isActive: boolean;
  type: number;
}


export interface ICategory {
  id: number;
  nameEng: string;
  nameMar: string;
  nameHin: string;
  base64: string;
  imagePath: string;
  isActive: boolean;
  categories: ISubCategory[];
}


export interface ISubCategory {
  id: number;
  category: string;
  categoryId: number;
  engName: string;
  marathiName: string;
  hindiName: string;
  imageBase64: string;
  active: boolean;
}

export interface IHomeCategory {
  typeId: number;
  name: string;
  queryname?: string;
  nameMar: string;
  nameHin: string;
  data: any;
  imageUrl?: string;
  isActive?: boolean;
}

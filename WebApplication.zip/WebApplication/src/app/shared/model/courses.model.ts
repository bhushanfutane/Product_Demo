export interface IHomeCourses {
    typeId: number;
    name: string;
    queryname?: string;
    nameMar: string;
    nameHin: string;
    data: any;
    imageUrl?: string;
    isActive?: boolean;
  }
export interface IProduct {
   id: number;
  nameEng: string;
  nameMar: string;
  nameHin: string;
  price: number;
  active: boolean;
  imageUrl: string;
  discription: string;
  discriptionHn: string;
  discriptionMr: string;
  mrp: number;
  weight: number;
  categoryId: number;
  categoryEn: string;
  categoryHn: string;
  categoryMr: string;
  isInCart: boolean;
  quantity: number;
  productType:number;
  engName: string;
  
}

export interface IArea {
  areaId: number;
  areaNameENg: string;
  areaNameHin: string;
  areaNameMar: string;
  cityEng: string;
  cityHin: string;
  cityMar: string;
  isServiceAvailable: boolean;
  pincode: string;
}


export interface IAreabyCity {
  areaCode: string;
  areaNameEng: string;
  areaNameHin: string;
  areaNameMar: string;
  cityId: number;
  deliveryCharges: number;
  id: number;
  isAvailable: true
  pinCode: string;
}

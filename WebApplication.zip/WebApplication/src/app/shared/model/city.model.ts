export interface ICity {
	id: number;
	cityNameEng: string;
	cityNameMar: string;
	cityNameHin: string;
	isActive: boolean;
}

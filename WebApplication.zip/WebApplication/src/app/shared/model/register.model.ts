export interface IRegister {
	fullName?: string;
	mobile?: string;
	// userName?: string;
	password?: string;
	otp?: string;
	// registerfrom?: number;
	referCode?: string;
}

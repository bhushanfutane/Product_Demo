export interface ILogin {
	mobile: string;
	password: string;
	// loginfrom: number;
}

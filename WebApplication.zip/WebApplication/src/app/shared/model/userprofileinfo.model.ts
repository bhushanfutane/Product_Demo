export interface IUserProfileInfo {
  Id: number;
  firstName: string;
  lastName: string;
  email: string;
  isEmailVerified: false;
  mobile: string;
  isMobileVerified: false;
  pincode: null
  profileImage: string;
  refferCode: string;
  website: string;
  city: number;
  state: number;
  zip: number;
  country: number;
}

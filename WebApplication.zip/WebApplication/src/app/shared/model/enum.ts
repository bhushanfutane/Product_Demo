export enum Messagetype {
  sucess,
  fail
}

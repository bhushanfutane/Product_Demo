import { Injectable } from '@angular/core';
import { IArea } from '../model/area.model';
import { ICatandType } from '../model/cattype.model';
import { IUserinfo } from '../model/donation.model';
import { IUserInfo } from '../model/userinfo.model';
import { EncrService } from './encryption.service';

@Injectable({
  providedIn: 'root',
})
export class GetSetService {
  constructor(
    private encrDecrService: EncrService,
  ) { }


  setArea(area: IArea) {
    localStorage.setItem('area', this.encrDecrService.encrypt(area));
  }

  getArea(): IArea | null {
    const area = localStorage.getItem('area');
    if (area != null) {
      return this.encrDecrService.decrypt(area);
    } else {
      return null;
    }
  }

  setCategory(category: any) {
    sessionStorage.setItem('cate', this.encrDecrService.encrypt(category));
  }

  getCategory(): any[] | null {
    const cate = sessionStorage.getItem('cate');
    if (cate != null) {
      return this.encrDecrService.decrypt(cate);
    } else {
      return null;
    }
  }

  setTCategory(category: any) {
    sessionStorage.setItem('catet', this.encrDecrService.encrypt(category));
  }

  getTCategory(): ICatandType[] | null {
    const cate = sessionStorage.getItem('catet');
    if (cate != null) {
      return this.encrDecrService.decrypt(cate);
    } else {
      return null;
    }
  }



  SetUser(userInfo: IUserInfo) {
    localStorage.setItem('iiyer', this.encrDecrService.encrypt(userInfo));
    localStorage.setItem('info', userInfo.token);
    localStorage.setItem('infor', userInfo.refreshToken);
  }

  getCurrentUserInfo(): IUserInfo | null    {
    let currentUser: any;
    const user = localStorage.getItem('iiyer');
    if (user != null) {
      currentUser = this.encrDecrService.decrypt(user);
    } else {
      return null;
    }
    return currentUser;
  }

  isloggedInUser() {
    if (localStorage.getItem('iiyer') !== null) {
      return true;
    } else {
      return false;
    }
  }

  getCurrentLanguage() {
    return localStorage.getItem('locale');
  }




  getAreaId() {
    let currentUser: any;
    const user = localStorage.getItem('iiyer');
    if (user != null) {
      currentUser = this.encrDecrService.decrypt(user);
      return currentUser.areaId;
    } else {
      const area = localStorage.getItem('area');
      if (area != null) {
        const currentArea = this.encrDecrService.decrypt(area);
        return currentArea.areaId;
      } else {
        return 0;
      }
    }
  }

  getAreaServiceAvaibility() {
    let currentUser: any;
    const user = localStorage.getItem('iiyer');
    if (user != null) {
      currentUser = this.encrDecrService.decrypt(user);
      return currentUser.isServiceAvailable;
    } else {
      const area = localStorage.getItem('Area');
      if (area != null) {
        const currentArea = this.encrDecrService.decrypt(area);
        return currentArea.isServiceAvailable;
      } else {
        return false;
      }
    }
  }


  setTempCartList(cartlist: any[]) {
    localStorage.setItem('cartlist', this.encrDecrService.encrypt(cartlist));
  }

  getTempCartList(): any[] | null {
    const cartlist = localStorage.getItem('cartlist');
    if (cartlist != null) {
      return this.encrDecrService.decrypt(cartlist);
    } else {
      return null;
    }
  }

  resetTempCartList() {
    localStorage.removeItem('cartlist');
  }



  setformcheckout() {
    localStorage.setItem('formcheckout', this.encrDecrService.encrypt(true));
  }

  getformcheckout() {
    const formcheckout = localStorage.getItem('formcheckout');
    if (formcheckout != null) {
      return this.encrDecrService.decrypt(formcheckout);
    } else {
      return false;
    }
  }
  resetformcheckout() {
    localStorage.removeItem('formcheckout');
  }

  getlanguge(): string {
    let urrentLang = localStorage.getItem('locale');

    if (urrentLang) {
      return urrentLang;
    }
    return 'en';
  }

  BlogType = [
    'general', 'products', 'health'
  ];
}

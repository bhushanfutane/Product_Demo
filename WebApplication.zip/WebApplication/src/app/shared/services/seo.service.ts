import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SeoService {
  constructor(private titleService: Title, private metaService: Meta, private http: HttpClient) {}

  public setMetadata(title: string, desc: string, keyword: string) {
    this.titleService.setTitle(title);
    this.metaService.addTags([
      { name: 'keywords', content: keyword },
      { name: 'description', content: desc },
    ]);
  }


  public getStaticPageMetaData(): Observable<any>{
    return this.http.get('../../../assets/meta/meta.json');
  }

  public getSitemapPage(): Observable<any>{
    return this.http.get('../../../assets/sitemap/sitemaps.json');
  }
}

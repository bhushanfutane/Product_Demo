import { Injectable } from '@angular/core';

import { Subject } from 'rxjs';
import { ICartItem, ICItem } from '../model/cart.model';
import { IPopUp } from '../model/donation.model';
import { IProduct } from '../model/product.model';
import { HttpStatusCode, ResponseModel } from '../model/response.model';
import { IUserInfo } from '../model/userinfo.model';
import { ApiDataService } from './apidata.service';
import { GetSetService } from './getset.serverce';


@Injectable()
export class AppService {

  private updateAreaSubject = new Subject<boolean>();
  private userloginSubject = new Subject<boolean>();
  private updateCartSubject = new Subject<boolean>();
  private updateProductSubject = new Subject<IProduct>();
  private updateCartStatusSubject = new Subject<ICItem>();
  private updateUsersubject = new Subject<IUserInfo>();

  private updateLangugesubject = new Subject<string>();
  private updatePopUpDataSubject = new Subject<IPopUp>();

	private donationStickySubject = new Subject<boolean>();

  constructor(private getSetService: GetSetService,
              private authService: ApiDataService
  ) { }

  // tslint:disable-next-line:typedef
  getSelectedArea() {
    return this.updateAreaSubject.asObservable();
  }

  // tslint:disable-next-line:typedef
  setSelectedArea(status: boolean) {
    this.updateAreaSubject.next(status);
  }


  // tslint:disable-next-line:typedef
  getCurrentUserInfo() {
    return this.updateUsersubject.asObservable();
  }

  // tslint:disable-next-line:typedef
  setCurrentUserInfo(user: IUserInfo) {
    this.updateUsersubject.next(user);
  }

  // tslint:disable-next-line:typedef
  getCart() {
    return this.updateCartSubject.asObservable();
  }

  // tslint:disable-next-line:typedef
  setCart(status: boolean) {
    this.updateCartSubject.next(status);
  }



  // tslint:disable-next-line:typedef
  getProduct() {
    return this.updateProductSubject.asObservable();
  }

  // tslint:disable-next-line:typedef
  setProduct(product: IProduct) {
    this.updateProductSubject.next(product);
  }


  // tslint:disable-next-line:typedef
  getUserLogin() {
    return this.userloginSubject.asObservable();
  }

  // tslint:disable-next-line:typedef
  setUserLogin(status: boolean) {
    this.userloginSubject.next(status);
  }

  // tslint:disable-next-line:typedef
  getCartStatus() {
    return this.updateCartStatusSubject.asObservable();
  }

  // tslint:disable-next-line:typedef
  setCartStatus(status: ICItem) {
    this.updateCartStatusSubject.next(status);
  }

  // tslint:disable-next-line:typedef
  getcurrentLanguage() {
    return this.updateLangugesubject.asObservable();
  }

  // tslint:disable-next-line:typedef
  setcurrentLanguage(status: string) {
    this.updateLangugesubject.next(status);
  }

  // tslint:disable-next-line:typedef
  getpopupdata() {
    return this.updatePopUpDataSubject.asObservable();
  }

  // tslint:disable-next-line:typedef
  setpopupdata(status: IPopUp) {
    this.updatePopUpDataSubject.next(status);
  }

}

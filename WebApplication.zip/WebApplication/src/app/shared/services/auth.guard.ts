import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
} from '@angular/router';
import { Messagetype } from '../model/enum';
import { ToastService } from './toast.service';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {

  constructor(private toastService: ToastService){
  }
  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (localStorage.getItem('info')) {

      return true;
    } else {
      this.toastService.showToast(Messagetype.fail,'Please Login','Please login  for using this feature.')
      return false;
    }
  }
}

import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler
} from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class HeaderInterceptor implements HttpInterceptor {
  constructor() { }

  req!: HttpRequest<any>;

  intercept(request: HttpRequest<any>, next: HttpHandler) {
    if (localStorage.getItem('info')) {

      const info = localStorage.getItem('info');

      const token = info;

      if (request.headers.get('noContentType')) {
        this.req = request.clone({
          setHeaders: {
            'Access-Control-Allow-Origin': '*',
            'Authorization': `Bearer ${token}`
          }
        });
      } else {
        this.req = request.clone({
          setHeaders: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Authorization': `Bearer ${token}`
          }
        });
      }
    } else {
      this.req = request.clone({
        setHeaders: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
      });
    }
    return next.handle(this.req);
  }
}

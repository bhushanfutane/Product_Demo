import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
	providedIn: 'root'
})
export class ProductService {
	constructor(private http: HttpClient) {}

	private isProductUpdate = new BehaviorSubject(false);
	getProductUpdateStatus = this.isProductUpdate.asObservable();

	currentProductStatus(flag: any) {
		this.isProductUpdate.next(flag);
	}

	getProductList(url: string): Observable<any> {
		return this.http
			.get(url)
			.pipe(map((response) => response as any));
	}

	modifyProduct(url: string, productInfo: any): Observable<any> {
		return this.http
			.post(url, productInfo)
			.pipe(map((response) => response as any));
	}
}

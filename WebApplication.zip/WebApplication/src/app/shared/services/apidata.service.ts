import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


import { environment } from '../../../environments/environment';
import { ResponseModel } from '../model/response.model';
import { IHomeCategory } from '../model/category.model';

@Injectable({
  providedIn: 'root'
})
export class ApiDataService {


  baseUrl = '';

  constructor(private http: HttpClient) {
    this.baseUrl = environment.apiurl;
  }

  

  getData(url: string): Observable<any> {
    return this.http.get(this.baseUrl + url)
      .pipe(map((response: ResponseModel<any>) => {
        return response;
      }));
  }
  
    

  postData(url: string, data: any): Observable<any> {
    return this.http.post(this.baseUrl + url, data)
      .pipe(map((response: ResponseModel<any>) =>
        response as any));
  }

  postDataArray(url: string, data: any[]): Observable<any> {
    return this.http.post(this.baseUrl + url, data)
      .pipe(map((response: ResponseModel<any>) =>
        response as any));
  }

  public createSlugtxt(name: string) {
    const slug2 = name.toLocaleLowerCase();
    return slug2.split(' ').join('-');
  }


 public static categoryList: Array<IHomeCategory> = [
    // {
    //   typeId: 0,
    //   name: 'All Categories',
    //   nameMar: 'सर्व श्रेण्या',
    //   nameHin: 'सब वर्ग',
    //   data: [],
    //   imageUrl:'./assets/category/Below1kg.png'
    // },
    {
      typeId: 1,
      name: 'bopala',
      nameMar: 'bopala',
      nameHin: 'bopala',
      imageUrl:'./assets/category/tt.jpg',
      data: [],
    },
    {
      typeId: 2,
      name: 'Capsicum',
      nameMar: 'बहु धान्य',
      nameHin: 'मल्टीग्रेन',
      data: [],
      imageUrl:'./assets/category/tt.jpg'
    },
    {
      typeId: 3,
      name: 'Peas',
      nameMar: 'कृती',
      nameHin: 'विधि',
      data: [],
      imageUrl:'./assets/category/tt.jpg'
    },
    {
      typeId: 4,
      name: 'Tomato ',
      nameMar: 'भाजणी',
      nameHin: 'भुजाहुआ',
      data: [],
      imageUrl:'./assets/category/tt.jpg'
    },
    {
      typeId: 6,
      name: 'Soyabean',
      nameMar: 'मसाला',
      nameHin: 'मसाले',
      data: [],
      imageUrl:'./assets/category/tt.jpg'
    },
    {
      typeId: 7,
      name: 'Bitter gourd seed	',
      nameMar: 'बिलो वन किलो',
      nameHin: 'बिलो वन किलो',
      data: [],
      imageUrl:'./assets/category/tt.jpg'
    },
    // {
    //   typeId: 8,
    //   queryname: 'SeasonalItem',
    //   name: 'Vegitable',
    //   nameMar: 'भजीपाला',
    //   nameHin: 'सबजी',
    //   data: [],
    //   imageUrl:'./assets/category/Vegetables.png'
    // },
    // {
    //   typeId: 9,
    //   queryname: 'SeasonalItem',
    //   name: 'Grocery',
    //   nameMar: 'किराणा',
    //   nameHin: 'किराना',
    //   data: [],
    //   imageUrl:'./assets/category/Grocery.png'
    // },
    // {
    //   typeId: 10,
    //   queryname: 'SeasonalItem',
    //   name: 'Fruits',
    //   nameMar: 'फळे',
    //   nameHin: 'फल',
    //   data: [],
    //   imageUrl:'./assets/category/Fruits.png'
    // },
  ];

}

import { Injectable } from '@angular/core';

@Injectable()
export class DropdownService {


  public setSelectvalue(dowpdownname: string, optionList: any[], selectId: string, valuetext: string, showtext: string, showdefaultSelected: boolean) {
    let select = document.getElementById(selectId);

    let itemstr = ''
    let optionStr = '<option _ngcontent-bdf-c51="" value="0" ng-reflect-value="select">Select ' + dowpdownname + ' </option>';

    optionList.forEach(option => {
      let opt = '<option _ngcontent-bdf-c51="" value="' + option[valuetext] + '" ng-reflect-value="'
        + option[valuetext] + '">' + option[showtext] + '</option>'
      if (select) {
        itemstr = itemstr + '<div onclick="selectme(this)">' + option[showtext] + '</div>';
        optionStr = optionStr + opt;
      }
    });
    if (select?.parentNode?.children) {
      const ele = select?.parentNode?.children[2];
      ele.innerHTML = itemstr;
      select.innerHTML = optionStr;
    }
    //select first default

    if (showdefaultSelected) {
      if (select) {
        const ele = select?.parentNode?.children[2];
        if (ele) {
          const option = ele.children[0];
          if (option) {
            var options = option.parentNode?.children;
            if (options) {
              for (let i = 0; i < options.length; i++) {
                options[i].classList.remove('same-as-selected');
              }
              option.classList.add('same-as-selected');
              let showselect = option.parentNode?.parentNode?.children[1];
              if (showselect) {
                showselect.innerHTML = option?.innerHTML;
              }
            }
          }
        }
      }
    }
  }


  public getSelectedvalue(selectId: string): any {

    let select = document.getElementById(selectId);

    const selectedNode = select?.parentNode?.children[1];

    const selectStr = selectedNode?.innerHTML;

    const selectOptions = select?.parentNode?.children[0].children;
    if (selectOptions) {
      for (let i = 0; i < selectOptions?.length; i++) {

        const opt: any = selectOptions[i];
        if (opt?.innerHTML.trim() === selectStr?.trim()) {
          return opt?.value;
        }
      }
      return '0';
    }
  }
}

import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { FooterComponent } from "../container/footer/footer.component";
import { ControlComponent } from "./component/controls/control.component";
import { ProductComponent } from "./component/product/product.component";
import { ApiDataService } from "./services/apidata.service";
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import { TranslateModule } from "@ngx-translate/core";
import { ViewProductsComponent } from "../views/home/view-products/view-products.component";
import { TrackorderComponent } from "../views/trackorder/trackorder.component";
import { FreeDraggingDirective } from "./directive/free-dragging.directive";

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    MatSelectModule,
    MatInputModule,
    MatFormFieldModule,
    TranslateModule,
  ],
  declarations: [
    FooterComponent,
    ProductComponent,
    ControlComponent,
    ViewProductsComponent,
    TrackorderComponent,
    FreeDraggingDirective
  ],
  providers: [ApiDataService],
  exports: [
    FooterComponent,
    ProductComponent,
    ControlComponent,
    FormsModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    MatSelectModule,
    MatInputModule,
    MatFormFieldModule,
    ViewProductsComponent,
    TrackorderComponent,
    FreeDraggingDirective
  ],
})
export class SharedModule { }

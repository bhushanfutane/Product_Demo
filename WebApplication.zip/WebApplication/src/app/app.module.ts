import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DefaultLayoutComponent } from './container';
import { ProductPopComponent } from './container/productpopup/productpopup.component';
import { LoginComponent } from './container/login/login.component';
import { CartBtnComponent } from './container/cartbtn/cartbtn.component';
import { SitebarCartComponent } from './container/sitebar-cart/sitebar-cart.component';
import { TestimonialComponent } from './container/testimonial/testimonial.component';
import { HeaderInterceptor } from './shared/services/Intercepter/HeaderInterceptor';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { SharedModule } from './shared/shared.module';
import { HeaderComponent } from './container/header/header.component';
import { SideCategoryComponent } from './container/side-cat/side-cat.component';
import { AreaComponent } from './container/area/area.component';
import { ApiDataService } from './shared/services/apidata.service';
import { GetSetService } from './shared/services/getset.serverce';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppService } from './shared/services/app.service';
import { DropdownService } from './shared/services/dropdown.service';
import { ToastrModule } from 'ngx-toastr';
import { ToastService } from './shared/services/toast.service';
import { ToastrService } from 'ngx-toastr';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { TranslateModule, TranslateLoader, TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TermandconditionComponent } from './views/footerscomponent/termandcondition/termandcondition.component';
import { RefundpolicyComponent } from './views/footerscomponent/refundpolicy/refundpolicy.component';
import { PrivacypolicyComponent } from './views/footerscomponent/privacypolicy/privacypolicy.component';
import { SitemapComponent } from './views/footerscomponent/sitemap/sitemap.component';
import { DonationComponent } from './views/donation/donation.component';
import { DonatePopComponent } from './container/donate/donate.component';
import { CartModule } from './views/cart/cart.module';
import { SocialComponent } from './views/social/social.component';
import { CoursedetailComponent } from './views/coursedetail/coursedetail.component';
import { CoursedetailModule } from './views/coursedetail/coursedetail.module';
import { PaymentGateway } from './shared/services/paymentGateway';
// import { AddressComponent } from './shared/component/address/address.component';


export const createTranslateLoader = (http: HttpClient) => {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
};

@NgModule({
  declarations: [
    AppComponent,
    DefaultLayoutComponent,
    ProductPopComponent,
    LoginComponent,
    CartBtnComponent,
    SitebarCartComponent,
    TestimonialComponent,
    HeaderComponent,
    SideCategoryComponent,
    HeaderComponent,
    AreaComponent,
    TermandconditionComponent,
    RefundpolicyComponent,
    PrivacypolicyComponent,
    SitemapComponent,
    DonationComponent,
    DonatePopComponent,
    CoursedetailComponent,
    // SocialComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    SharedModule,
    CartModule,
    ReactiveFormsModule,
    FormsModule,
    CoursedetailModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: createTranslateLoader,
        deps: [HttpClient],
      },
    }),
  ],
  providers: [
    {
      provide: LocationStrategy,
      useClass: HashLocationStrategy
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HeaderInterceptor,
      multi: true
    },
    GetSetService,
    ApiDataService,
    AppService,
    DropdownService,
    ToastrService,
    ToastService,
    TranslateService,
    PaymentGateway
  ],
  bootstrap: [AppComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  // exports:[
  //   // AddressComponent
  // ]
})
export class AppModule { }

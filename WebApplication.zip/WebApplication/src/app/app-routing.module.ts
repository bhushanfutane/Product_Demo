import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DefaultLayoutComponent } from './container';
import { DonationComponent } from './views/donation/donation.component';
import { PrivacypolicyComponent } from './views/footerscomponent/privacypolicy/privacypolicy.component';
import { RefundpolicyComponent } from './views/footerscomponent/refundpolicy/refundpolicy.component';
import { SitemapComponent } from './views/footerscomponent/sitemap/sitemap.component';
import { TermandconditionComponent } from './views/footerscomponent/termandcondition/termandcondition.component';
import { AuthGuard } from '../../src/app/shared/services/auth.guard'
import { CoursesComponent } from './views/home/courses/courses.component';

const routes: Routes = [
  {
    path: '',
    component: DefaultLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () => import('./views/home/home.module').then(m => m.HomeModule)
      },
      {
        path: 'products',
        loadChildren: () => import('./views/product-list/product-list.module').then(m => m.ProductListModule)
      },
      {
        path: 'categories',
        loadChildren: () => import('./views/product-list/product-list.module').then(m => m.ProductListModule)
      },
      {
        path: 'category',
        loadChildren: () => import('./views/product-list-category/product-list-category.module').then(m => m.ProductListCategoryModule)
      },
      {
        path: 'search/:title',
        loadChildren: () => import('./views/search/search.module').then(m => m.SearchModule)
      },
      {
        path: 'checkout',
        loadChildren: () => import('./views/checkout/checkout.module').then(m => m.CheckoutModule)
      },
      {
        path: 'user',
        loadChildren: () => import('./views/checkout/checkout.module').then(m => m.CheckoutModule)
      },
      {
        path: 'help&support',
        loadChildren: () => import('./views/help&more/help&more.module').then(m => m.HelpMoreModule)
      },
      {
        path: 'about',
        loadChildren: () => import('./views/about/about.module').then(m => m.AboutModule)
      },
      {
        path: 'cart',
        loadChildren: () => import('./views/cart/cart.module').then(m => m.CartModule)
      },
      {
        path: 'contact',
        loadChildren: () => import('./views/contact/contact.module').then(m => m.ContactModule)
      },
      {
        path: 'faq',
        loadChildren: () => import('./views/faq/faq.module').then(m => m.FaqModule)
      },
      {
        path: 'blogs',
        loadChildren: () => import('./views/blogs/blogs.module').then(m => m.BlogsModule)
      },
      {
        path: 'account',
        loadChildren: () => import('./views/account/account.module').then(m => m.AccountModule)
      },
      {
        path: 'social',
        loadChildren: () => import('./views/social/social.module').then(m => m.SocialModule)
      },
      {
        path: 'trackorder',
        loadChildren: () => import('./views/trackorder/trackorder.module').then(m => m.TrackorderModule)
      },
      {
        path: 'orderdetail',
        loadChildren: () => import('./views/orderdetail/orderdetail.module').then(m => m.OrderdetailModule)
      },
      {
        path: 'productdetail',
        loadChildren: () => import('./views/productdetail/productdetail.module').then(m => m.ProductdetailModule)
      },
      {
        path: 'course_detail',
        loadChildren: () => import('./views/coursedetail/coursedetail.module').then(m => m.CoursedetailModule)
      },
      {
        path: 'privacypolicy',
        component: PrivacypolicyComponent
      },
      {
        path: 'refundpolicy',
        component: RefundpolicyComponent
      },
      {
        path: 'termandcondition',
        component: TermandconditionComponent
      },
      {
        path: 'sitemap',
        component: SitemapComponent
      },
      {
        path: 'donate',
        component: DonationComponent
      },
      {
        path: 'course',
        component: CoursesComponent
      }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Component, OnDestroy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { HttpStatusCode, ResponseModel } from 'src/app/shared/model/response.model';
import { ApiDataService } from 'src/app/shared/services/apidata.service';
import { AppService } from 'src/app/shared/services/app.service';
import { GetSetService } from 'src/app/shared/services/getset.serverce';
import { FormControl } from '@angular/forms';
import { FormBuilder, FormGroup } from '@angular/forms';
declare var $: any;

$(document).click(function (e: any) {
  var container = $('#searchList');
  if (!container.is(e.target) && container.has(e.target).length === 0) {
    container.hide();
  }
});


import { Router } from '@angular/router';
import { IUserInfo } from 'src/app/shared/model/userinfo.model';
@Component({
  selector: 'app-header',
  templateUrl: 'header.component.html',
  styleUrls: ['header.component.scss']
})
export class HeaderComponent implements OnInit, OnDestroy {
  myControl = new FormControl();
  searchForm?: FormGroup;
  savedArea: any = {};
  searchList: any = [];
  copySearchList: any = [];
  wishlistCount = 0;
  itemCount = 0;
  itemAmount = 0;
  public subscriptions$: Subscription[] = [];
  searchSelectname = '';
  userLogin = false;
  currentLang = 'en';
  userInfo?: IUserInfo;
  areaid = 0;

  constructor(
    private getset: GetSetService,
    private appservice: AppService,
    private apidataService: ApiDataService,
    public translate: TranslateService,
    private router: Router,
    public formBuilder: FormBuilder,

  ) {
    this.searchForm = this.formBuilder.group({

      searchProduct: ['',],

    });
  }

  ngOnInit(): void {
    this.subscriptions$.push(

      //languge Subscription

      this.appservice.getcurrentLanguage().subscribe((lng) => {
        this.currentLang = lng;
      }),

      // ------------area change Subscribe---------------------
      this.appservice.getSelectedArea().subscribe(() => {
        this.getSavedarea();
        this.getsearchList();
      }),

      // -------------user register and login----
      this.appservice.getUserLogin().subscribe((response) => {
        this.userLogin = response;
      }),

      this.appservice.getCartStatus().subscribe((result) => {
        this.itemCount = result.itemcount;
        this.itemAmount = result.amount;
      }),



      this.appservice.getCurrentUserInfo().subscribe((user) => {
        this.userInfo = user;
      })


    );
    this.getSavedarea();
    this.getsearchList();

    const user = this.getset.getCurrentUserInfo();

    if (user) {
      this.userInfo = user;
    }

    this.userLogin = this.getset.isloggedInUser();
    this.getCartList();

    this.appservice.setCart(true);
    this.currentLang = this.getset.getlanguge();
  }

  ngOnDestroy(): void {
    this.subscriptions$.forEach((subscription) => subscription.unsubscribe());
  }

  getSavedarea(): void {

    this.savedArea = this.getset.getArea();
    if (!this.savedArea) {
      this.areapopOpen();
    } else {
      this.areaid = this.savedArea.areaId;
    }
  }

  areapopOpen(): void {
    const popup = document.getElementById('popup');
    if (popup) {
      popup.style.display = 'block';
    }
  }

  logout(): void {
    this.appservice.setUserLogin(false);
    this.clearLocalStotage();
    this.appservice.setCartStatus({
      amount: 0,
      itemcount: 0,
    });
    this.appservice.setCart(true);
    this.appservice.setSelectedArea(true);
  }


  public clearLocalStotage(): void {
    localStorage.removeItem('info');
    localStorage.removeItem('iiyer');
    localStorage.removeItem('infor');
  }

  getsearchList() {
    const url = `Product/ProductNameListAreawise?AreaId=${this.areaid}`;
    this.apidataService
      .getData(url)
      .subscribe((response: ResponseModel<any>) => {
        if (response.status === HttpStatusCode.OK) {
          this.copySearchList = response.data;
        } else if (
          response.status === HttpStatusCode.BAD_REQUEST ||
          response.status === HttpStatusCode.INTERNAL_SERVER_ERROR
        ) {

        }
      });
  }

  filterSearch(str: string, event: any) {

    if (str !== '' && str.trim() !== '') {
      this.searchSelectname = event.target.value;
      this.searchList = this.copySearchList.filter((name: any) => {
        return String(name.product).trim()
          .toLowerCase()
          .startsWith(str.toLowerCase().trim());
      });

    } else {
      this.searchList = [];
    }
  }

  public search() {
    let inputValue = this.searchForm?.controls.searchProduct.value;
    this.router.navigateByUrl(`/search/${inputValue}`);
    this.searchList = [];
  }


  public changeLanguage(language: string) {
    localStorage.setItem('locale', language);
    this.currentLang = language;
    this.translate.use(language);
    this.appservice.setcurrentLanguage(language);
  }

  public getCartList() {



    if (this.getset.isloggedInUser()) {
      const url = `Cart/GetCarts`;
      this.apidataService
        .getData(url)
        .subscribe((response: ResponseModel<any>) => {
          if (response.status === HttpStatusCode.OK) {

            const cartList = response.data;
            this.itemCount = response.data.length;
            let total = 0;
            cartList.forEach((cart: any) => {

              total += (cart.productTypeId < 3) ? (
                (cart.size != 0 ? cart.size : 2) * (cart.offerPrice + ((cart.convCharge) ? cart.convCharge : 0))) :
                ((1) * (cart.offerPrice + ((cart.convCharge) ? cart.convCharge : 0)) * (cart.quantity));
            });
            this.itemAmount = total;
          }
        });
    } else {     
    }
  }  
}

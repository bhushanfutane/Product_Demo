import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { ICategory } from 'src/app/shared/model/category.model';
import { HttpStatusCode, ResponseModel } from 'src/app/shared/model/response.model';
import { ApiDataService } from 'src/app/shared/services/apidata.service';
import { AppService } from 'src/app/shared/services/app.service';
import { GetSetService } from 'src/app/shared/services/getset.serverce';

@Component({
  selector: 'app-footer',
  templateUrl: 'footer.component.html',
  styleUrls: ['footer.component.scss']
})
export class FooterComponent {

  categories?: ICategory[] = [];
  currentLang = 'en';
  public subscriptions$: Subscription[] = [];
  savedArea: any;
  areaid = 0;
  version: any;
  constructor(
    private apidataservice: ApiDataService,
    private getset: GetSetService,
    private appservice: AppService,
    public translate: TranslateService,
    public getsetservice: GetSetService
  ) { }

  ngOnInit(): void {

    this.subscriptions$.push(
      this.appservice.getcurrentLanguage().subscribe((lng: any) => {
        this.currentLang = lng;
      })
    );

    this.appservice.getSelectedArea().subscribe(() => {
      this.getSavedarea();
      this.getCatgoryList();
    });
    this.getCatgoryList();
this.getAppversion();
    this.currentLang = this.getset.getlanguge();
  }

  getSavedarea(): void {

    this.savedArea = this.getset.getArea();
    if (!this.savedArea) {
    } else {
      this.areaid = this.savedArea.areaId;
    }
  }
  getCatgoryList() {
    const url = `/api/Product/WholeGrainListAreawise?AreaId=${this.areaid}`;
    this.apidataservice.getData(url).subscribe
      ((response: ResponseModel<any[]>) => {
        if (response.status === HttpStatusCode.OK) {
          this.categories = response.data;
          if (this.categories) {
            this.categories[0].isActive = true;
          }
          this.getset.setCategory(this.categories);
        }
      });

  }
  public getAppversion(): void {
    const url = `/api/ProSet/AndroidUserVersion`;
    this.apidataservice.getData(url).subscribe((response: ResponseModel<any>) => {
      if (response.status === HttpStatusCode.OK) {
        this.version = response.data.settingValue;
      } else if (
        response.status === HttpStatusCode.BAD_REQUEST ||
        response.status === HttpStatusCode.INTERNAL_SERVER_ERROR
      ) {

      }
    });
  }
}

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Messagetype } from 'src/app/shared/model/enum';
import { IProduct } from 'src/app/shared/model/product.model';
import { HttpStatusCode, ResponseModel } from 'src/app/shared/model/response.model';
import { IUserInfo } from 'src/app/shared/model/userinfo.model';
import { ApiDataService } from 'src/app/shared/services/apidata.service';
import { AppService } from 'src/app/shared/services/app.service';
import { GetSetService } from 'src/app/shared/services/getset.serverce';
import { ToastService } from 'src/app/shared/services/toast.service';

@Component({
  selector: 'app-product-popup',
  templateUrl: 'productpopup.component.html',
  styleUrls: ['./productpopup.component.scss']
})
export class ProductPopComponent {


  product?: IProduct;


  // public subscriptions$: Subscription[] = [];

  quntity = 1;

  userInfo?: IUserInfo;

  constructor(
   
  ) {


  }
  ngOnInit(): void {
  }

  ngOnDestroy(): void {
  }


}

import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Messagetype } from 'src/app/shared/model/enum';
import { HttpStatusCode, ResponseModel } from 'src/app/shared/model/response.model';
import { ApiDataService } from 'src/app/shared/services/apidata.service';
import { AppService } from 'src/app/shared/services/app.service';
import { DropdownService } from 'src/app/shared/services/dropdown.service';
import { GetSetService } from 'src/app/shared/services/getset.serverce';
import { ToastService } from 'src/app/shared/services/toast.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-area',
  templateUrl: 'area.component.html',
  styleUrls: ['area.component.scss']
})
export class AreaComponent implements OnInit {

  areaList: any[] = [];
  areaForm = new FormGroup({
    pincode: new FormControl(''),
    area: new FormControl('')
  });

  pincodePattern = '^((\\+91-?)|0)?[0-9]{6}$';
  isAreaAvailable = false;


  btncheckdisable = true;
  btnselectdisable = true;

  checkloader = false;
  selectloader = false;

  constructor(
    private apiDataService: ApiDataService,
    private fb: FormBuilder,
    private appService: AppService,
    private getSetService: GetSetService,
    private dropdownService: DropdownService,
    private toastService: ToastService
  ) {

    this.areaForm = this.fb.group({
      pincode: ['', [Validators.required, Validators.pattern('[0-9]{6}')]],
      area: ['', [Validators.required]],
    });
  }

  ngOnInit(): void {
  }

  getAreaByPincode() {

    this.checkloader = true;

    const url = `/api/Auth/area?pincode=${this.areaForm.value.pincode}`;
    this.apiDataService
      .getData(url)
      .subscribe((response: any[]) => {
        this.checkloader = false;
        if (response[0].postOffice == null) {
          this.btnselectdisable = true;
          this.btncheckdisable = false;
          this.toastService.showToast(Messagetype.fail, 'Info', 'Area is not available or enter valid pincode');
        } else {
          this.btnselectdisable = false;
          this.btncheckdisable = true;
          this.areaList = response[0].postOffice;
          this.dropdownService.setSelectvalue('area', this.areaList, 'fluxselect', 'name', 'name', true);
        }
      });

  }

  saveArea() {

    const selectedarea = this.dropdownService.getSelectedvalue('fluxselect');
    const selectedpincode = this.areaForm.value.pincode;

    this.selectloader = true;
    const data = {
      areaName: selectedarea,
      pincode: selectedpincode,
      isServiceAvailable: true,
    };

    const url = `/api/User/SaveArea`;
    this.apiDataService
      .postData(url, data)
      .subscribe((response: ResponseModel<any>) => {
        this.selectloader = false;
        if (response.status === HttpStatusCode.OK) {

          if (response.data.isServiceAvailable) {
            this.getSetService.setArea(response.data);
            this.appService.setSelectedArea(true);
            this.toastService.showToast(Messagetype.sucess, 'Info', 'Service is available start shopping');
            this.popupClose();
            this.clearform();
          } else {

            // get city
            const city = this.areaList.find(m => m.name == selectedarea && m.pincode === selectedpincode);
            response.data.cityEng = city.region;
            this.getSetService.setArea(response.data);
            this.toastService.showToast(Messagetype.fail, 'Info', 'Service is not available, you can check with another area');
            this.popupClose();
            this.clearform();
          }

          this.appService.setSelectedArea(true);
        }
      });
  }


  isNumber(evt: any) {
    evt = evt ? evt : window.event;
    const charCode = evt.which ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  checkfor6digit(event: any) {
    const pin = event.target.value;
    this.btncheckdisable = !(pin.length == 6);
    if (this.btncheckdisable) {
      this.btnselectdisable = true;
    }
  }

  popupClose() {
    const popup = document.getElementById('popup');
    if (popup) {
      popup.style.display = 'none';
    }
  }

  clearform() {
    this.areaForm.controls.pincode.setValue('');
    this.dropdownService.setSelectvalue('area', this.areaList, 'fluxselect', 'name', 'name', false);
  }

}

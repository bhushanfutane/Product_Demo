import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { IProduct } from 'src/app/shared/model/product.model';
import { ResponseModel, HttpStatusCode,} from 'src/app/shared/model/response.model';
import { IUserInfo } from 'src/app/shared/model/userinfo.model';
import { ApiDataService } from 'src/app/shared/services/apidata.service';
import { AppService } from 'src/app/shared/services/app.service';
import { GetSetService } from 'src/app/shared/services/getset.serverce';
import { environment } from 'src/environments/environment';
declare var $: any;

@Component({
  selector: 'app-dashboard',
  templateUrl: './default-layout.component.html',
  styleUrls: ['./default-layout.component.scss'],
})
export class DefaultLayoutComponent implements OnInit {
  public sidebarMinimized = false;
  loadAPI: Promise<any>;

  showcartHandle = false;
  userInfo?: IUserInfo;
  showareaPopup = false;

  itemCount: number = 0;
  cartList: IProduct[] = [];

  public subscriptions$: Subscription[] = [];

  total: number = 0;
  mrptotal: number = 0;
  saving: number = 0;
  membershipSuggestions: any = null;
  currentLang = 'en';
  areaId: number = 0;
  searchList: any = [];
  copySearchList: any = [];
  searchForm: FormGroup;
  searchSelectname = '';
  userLogin = false;

  showsticky = true;

  constructor(
    private getset: GetSetService,
    private router: Router,
    private appservice: AppService,
    private apidata: ApiDataService,
    private formBuilder: FormBuilder,
    public translate: TranslateService,
  ) {
    this.loadAPI = new Promise((resolve) => {
      this.loadScript();
      resolve(true);
    });

    this.router.events.subscribe((e) => {
      if (e instanceof NavigationEnd) {
      }
    });

    this.searchForm = this.formBuilder.group({
      searchProduct: ['',],
    })
  }
  ngOnInit(): void {
    this.openAreaPopup();
    this.getCartList();
    this.getsearchList();
    this.appservice.getCart().subscribe((result) => {
      this.getCartList();
    });

    this.appservice.getUserLogin().subscribe((response) => {
      this.userLogin = response;
    });

    this.userLogin = this.getset.isloggedInUser();
    this.appservice.getCurrentUserInfo().subscribe((user) => {
      this.userInfo = user;
    });

    const user = this.getset.getCurrentUserInfo();

    if (user) {
      this.userInfo = user;
    }
  }

  public changeLanguage(language: string) {
    localStorage.setItem('locale', language);
    this.currentLang = language;
    this.translate.use(language);
    this.appservice.setcurrentLanguage(language);
  }

  public loadScript() {
    const dynamicScripts = [
      environment.domainpath + 'assets/js/jquery.min.js',
      environment.domainpath + 'assets/js/bootstrap.bundle.min.js',
      environment.domainpath + 'assets/js/swiper.min.js',
      environment.domainpath + 'assets/js/slick.js',
      environment.domainpath + 'assets/js/jquery.elevatezoom.js',
      environment.domainpath + 'assets/js/price-range.js',
      environment.domainpath + 'assets/js/custom-select.js',
      environment.domainpath + 'assets/js/functions.js',
    ];

    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < dynamicScripts.length; i++) {
      const node = document.createElement('script');
      node.src = dynamicScripts[i];
      node.type = 'text/javascript';
      node.async = false;
      node.charset = 'utf-8';
      document.getElementsByTagName('head')[0].appendChild(node);
    }
  }

  openAreaPopup() {
    const savedArea = this.getset.getArea();
    if (savedArea) {
      this.areaId = savedArea.areaId;
      this.popupClose();
    }
  }

  popupClose() {
    const popup = document.getElementById('popup');
    if (popup) {
      popup.style.display = 'none';
    }
  }

  public getCartList() {
    if (this.getset.isloggedInUser()) {
      const url = `Cart/GetCarts`;
      this.apidata.getData(url).subscribe((response: ResponseModel<any>) => {
        if (response.status === HttpStatusCode.OK) {
          this.cartList = response.data;
          this.total = 0;
          this.mrptotal = 0;
          this.saving = 0;
          this.itemCount = this.cartList.length;
          this.cartList.forEach((cart) => {
            if (cart) {
              cart.isInCart = true;
            }
            this.mrptotal += cart.mrp * cart.quantity;
            this.total += cart.price * cart.quantity;
          });

          this.saving = this.mrptotal - this.total;
        } else {
          this.appservice.setCartStatus({ amount: 0, itemcount: 0 });
          this.itemCount = 0;
          this.cartList = [];
        }
      });
    } else {
      const tempcartList = this.getset.getTempCartList();
      if (tempcartList != null) {
        this.cartList = tempcartList;
        this.total = 0;
        this.cartList.forEach((cart) => {
        });
      } else {
        this.cartList = [];
      }
    }
  }

  getsearchList() {
    const url = `Product/ProductNameList`;
    this.apidata
      .getData(url)
      .subscribe((response: ResponseModel<any>) => {
        if (response.status === HttpStatusCode.OK) {
          this.copySearchList = response.data;
        } else if (
          response.status === HttpStatusCode.BAD_REQUEST ||
          response.status === HttpStatusCode.INTERNAL_SERVER_ERROR
        ) {

        }
      });
  }

  filterSearch(str: string, event: any) {
    if (str !== '' && str.trim() !== '') {
      this.searchSelectname = event.target.value;
      this.searchList = this.copySearchList.filter((name: any) => {
        return String(name.product)
          .toLowerCase()
          .startsWith(str.toLowerCase().trim());
      });
    } else {
      this.searchList = [];
    }
  }
  public search() {
    let inputValue = this.searchForm?.controls.searchProduct.value;
    this.router.navigateByUrl(`/search/${inputValue}`);
    this.searchList = [];
  }
  onUserSearch(query: string) {
    this.router.navigateByUrl(`/search/${query}`);
    this.searchList = [];
  }
  public navigateToProduct(item: any) {
    this.router.navigateByUrl(`/productdetail/${item.product}/${+(item.id)}`);
  }
  logout(): void {
    this.appservice.setUserLogin(false);
    localStorage.clear();
    this.getset.resetTempCartList();
    this.getset.resetformcheckout();
    this.appservice.setCartStatus({
      amount: 0,
      itemcount: 0,
    });
    this.appservice.setCart(true);
  }
}

import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ICartItem } from 'src/app/shared/model/cart.model';
import { Messagetype } from 'src/app/shared/model/enum';
import { ILogin } from 'src/app/shared/model/login.model';
import { IRegister } from 'src/app/shared/model/register.model';
import {
  HttpStatusCode,
  ResponseModel,
} from 'src/app/shared/model/response.model';
import { ApiDataService } from 'src/app/shared/services/apidata.service';
import { AppService } from 'src/app/shared/services/app.service';
import { GetSetService } from 'src/app/shared/services/getset.serverce';
import { ToastService } from 'src/app/shared/services/toast.service';


@Component({
  selector: 'app-login',
  templateUrl: 'login.component.html',
  styleUrls: ['login.component.scss'],
})
export class LoginComponent {
  loginForm?: FormGroup;
  submitted = false;

  registerForm?: FormGroup;
  regsubmitted = false;
  regLoader = false;

  userdata?: IRegister;

  showverifyOtpForm = false;
  showverifyOtpFormLogin = false;

  OTPForm?: FormGroup;
  otpsubmitted = false;
  otpLoader = false;
  otp = '';

  forgetPasswordForm?: FormGroup;
  otpform?: FormGroup;

  isForgetFormShow = false;
  forgetUserName = '';
  hide = true;
  forgethide = true;
  registerhide = true;
  mobileNumberPattern = '^((\\+91-?)|0)?[0-9]{10}$';
  otpPattern = '^((\\+91-?)|0)?[0-9]{4}$';
  isShowLoginForm = true;

  forgetOTPForm: FormGroup;
  isForgetOtpSent = false;
  isShowNewPasswordField = false;
  CartItemlist: any;

  showPassword=false;
  type='';
  //hide = true;

  constructor(
    public formBuilder: FormBuilder,
    public router: Router,
    private authService: ApiDataService,
    private appService: AppService,
    private getSetService: GetSetService,
    private toastService: ToastService
  ) // public translate: TranslateService
  {
    this.loginForm = this.formBuilder.group({
      username: [
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern(
            /^(\d{10}|\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3}))$/
          ),
        ]),
      ], 
      password: ['', Validators.compose([Validators.required, Validators.minLength(6)])]
    });

    this.registerForm = this.formBuilder.group({
      fname: ['', Validators.compose([Validators.required])],
      username: ['', Validators.compose([Validators.required])],
      password: ['', Validators.compose([Validators.required, Validators.minLength(6)])],
      refcode: [''],
    });

    this.OTPForm = this.formBuilder.group({
      input1: ['', [Validators.required, Validators.pattern('[0-9]{1}')]],
      input2: ['', [Validators.required, Validators.pattern('[0-9]{1}')]],
      input3: ['', [Validators.required, Validators.pattern('[0-9]{1}')]],
      input4: ['', [Validators.required, Validators.pattern('[0-9]{1}')]],
    });

    this.forgetOTPForm = this.formBuilder.group({
      username: ['', [Validators.required]],
      newPassword: ['', [Validators.required]],
    });

    this.forgetPasswordForm = this.formBuilder.group({
      otp: ['', [Validators.required, Validators.pattern('[0-9]{4}')]],
      newpassword: ['', [Validators.required, , Validators.minLength(6)]],
    });

    this.otpform = this.formBuilder.group({
      otpinput: ['', Validators.required],
    });
  }

  ngOnInit() { }

  //--------------------------------------------------------------

  getOtp() {
    this.otp = `${this.OTPForm?.value.input1}${this.OTPForm?.value.input2}${this.OTPForm?.value.input3}${this.OTPForm?.value.input4}`;
    return this.otp.trim();
  }
  public resendOtp(): void {
    const url = `User/loginwithOtp?userName=${this.loginForm?.value.username}`;
    this.authService.getData(url).subscribe((response: ResponseModel<any>) => {
      if (response.status === HttpStatusCode.OK) {

        this.toastService.showToast(
          Messagetype.sucess,
          'Info',
          `${response.statusMessage}`
        );
      } else if (
        response.status === HttpStatusCode.BAD_REQUEST ||
        response.status === HttpStatusCode.INTERNAL_SERVER_ERROR
      ) {
        this.toastService.showToast(
          Messagetype.sucess,
          'danger',
          `${response.statusMessage}`
        );
      } else {
        this.toastService.showToast(
          Messagetype.sucess,
          'danger',
          `${response.statusMessage}`
        );
      }
    });
  }
  // --------------------------------------------------------------------------------

  public onLoginFormSubmit(): void {
    this.submitted = true;
    this.loginForm?.controls.password.setValidators([Validators.required]);
    this.loginForm?.controls.password.updateValueAndValidity();

    if (this.loginForm?.valid) {
      const loginInfo: ILogin = {
        mobile: this.loginForm.value.username,
        password: this.loginForm.value.password,
        // loginfrom: 1,
      };
      const url = `User/login`;
      this.authService
        .postData(url, loginInfo)
        .subscribe((response: ResponseModel<any>) => {
          if (response.status === HttpStatusCode.OK) {
            if (localStorage.getItem('area') != null) {
              response.data.areaId = this.getSetService.getArea()?.areaId;
              response.data.isServiceAvailable = this.getSetService.getArea()?.isServiceAvailable;
            }
            this.getSetService.SetUser(response.data);
            this.appService.setCurrentUserInfo(response.data);
            this.toastService.showToast(
              Messagetype.sucess,
              'Info',
              `Welcome ${response.data.firstName} ${response.data.lastName}`
            );
            this.appService.setUserLogin(true);

            document
              .getElementById('login-area')
              ?.classList.remove('open-form');
            this.saveArea();
            const templist = this.getSetService.getTempCartList();
            if (templist != null) {
              this.CartItemlist = [];
              /// call api
              templist.forEach((cart) => {
                const cartItem: ICartItem = {
                  id: 0,
                  userId: 0,
                  productTypeId: cart.productTypeId,
                  productId: cart.productId,
                  quantity: 1,
                  amount: cart.offerPrice,
                  size: cart.size,
                  grindingType: cart.grindingType,
                };

                this.CartItemlist.push(cartItem);
              });
              const url = `Cart/BulkAddToCart`;
              this.authService
                .postData(url, this.CartItemlist)
                .subscribe((response1: ResponseModel<any>) => {
                  if (response1.status === HttpStatusCode.OK) {
                    this.getSetService.resetTempCartList();
                    this.getSetService.resetformcheckout();
                    this.appService.setCart(true);
                    this.appService.setSelectedArea(true);
                  } else if (
                    response1.status === HttpStatusCode.BAD_REQUEST ||
                    response1.status === HttpStatusCode.INTERNAL_SERVER_ERROR
                  ) {

                    this.toastService.showToast(
                      Messagetype.fail,
                      'Info',
                      `${response1.statusMessage} `
                    );


                  } else {
                    this.toastService.showToast(
                      Messagetype.fail,
                      'Info',
                      `${response1.statusMessage} `
                    );
                  }
                });
            } else {

            }

            this.appService.setSelectedArea(true);
          } else if (response.status === HttpStatusCode.BAD_REQUEST) {
            this.toastService.showToast(
              Messagetype.fail,
              'Info',
              `${response.statusMessage}`
            );
          } else {
          }
        });
    }
  }


  toggleShow() {
    this.showPassword = !this.showPassword;
    this.type = this.showPassword ? 'text' : 'password';
  }
  //-----------------------------Registration---start------------------------------------------------

  public onRegisterFormSubmit(): void {
    this.regLoader = true;
    this.regsubmitted = true;

    if (this.registerForm?.valid) {
      const registerInfo: IRegister = {
            fullName: this.registerForm.value.fname,
        mobile: this.registerForm.value.username,
        password: this.registerForm.value.password,
        otp: '1111',
        referCode: this.registerForm.value.refcode,

      };

      this.userdata = registerInfo;

      const url = 'user/Registration';

      this.authService
        .postData(url, registerInfo)
        .subscribe((response: ResponseModel<any>) => {
          this.regLoader = false;
          if (response.status === HttpStatusCode.OK) {
            this.showverifyOtpForm = true;
          } else if (response.status === HttpStatusCode.INTERNAL_SERVER_ERROR) {
            this.toastService.showToast(
              Messagetype.fail,
              'Info',
              `${response.statusMessage}`
            );
          } else {
            this.toastService.showToast(
              Messagetype.fail,
              'Info',
              `${response.statusMessage}`
            );
          }
        });
    }
  }
  //------------------------------ Verify Registration OTP-----------------------------------
  public verifyOtp() {
    let data: IRegister = {
      fullName: this.userdata?.fullName,
      mobile: this.userdata?.mobile,
      password: this.userdata?.password,
      otp: this.getOtp(),
      referCode: this.userdata?.referCode,
    };

    const url = `User/Registration`;
    this.authService
      .postData(url, data)
      .subscribe((response: ResponseModel<any>) => {
        if (response.status === HttpStatusCode.OK) {
          if (localStorage.getItem('area') != null) {
            response.data.areaId = this.getSetService.getArea()?.areaId;
            response.data.isServiceAvailable = this.getSetService.getArea()?.isServiceAvailable;
          }

          this.getSetService.SetUser(response.data);

          this.appService.setCart(true);
          this.appService.setSelectedArea(true);
          this.toastService.showToast(
            Messagetype.sucess,
            'Info',
            `${response.statusMessage}`
          );

          document.getElementById('login-area')?.classList.remove('open-form');
        } else if (response.status === HttpStatusCode.INTERNAL_SERVER_ERROR) {
          this.toastService.showToast(
            Messagetype.fail,
            'Info',
            `${response.statusMessage}`
          );
        } else if (response.status === HttpStatusCode.BAD_REQUEST) {
          this.toastService.showToast(Messagetype.fail, 'Info', `Invalid OTP`);
        }
      });
  }

  // ---------------------------------verify Login OTP----------------------------------

  public verifyLoginOTP(): void {
    const data = {
      userName: this.loginForm?.value.username,
      otp: this.getOtp(),
      loginFrom: 1,
    };

    const url = `User/verifyLoginOtp`;
    this.authService
      .postData(url, data)
      .subscribe((response: ResponseModel<any>) => {
        if (response.status === HttpStatusCode.OK) {
          if (localStorage.getItem('area') != null) {
            response.data.areaId = this.getSetService.getArea()?.areaId;
            response.data.isServiceAvailable = this.getSetService.getArea()?.isServiceAvailable;
          }

          this.getSetService.SetUser(response.data);
          this.appService.setCurrentUserInfo(response.data);
          this.appService.setSelectedArea(true);
          this.toastService.showToast(
            Messagetype.sucess,
            'Info',
            `${response.statusMessage}`
          );

          document.getElementById('login-area')?.classList.remove('open-form');

          this.saveArea();

          this.appService.setUserLogin(true);

          this.appService.setCart(true);
          this.otpform?.reset();
        } else if (response.status === HttpStatusCode.BAD_REQUEST) {
          this.toastService.showToast(
            Messagetype.fail,
            'Info',
            `${response.statusMessage}`
          );
        } else {
        }
      });
  }

  //----------------- OTP form focus input for registration

  focusInputLogin(e: any, id: any) {
    if (
      (e.keyCode >= 48 && e.keyCode <= 57) ||
      (e.keyCode >= 96 && e.keyCode <= 105)
    ) {
      // 0-9 only

      if (+id < 4) {
        if (
          (<HTMLInputElement>document.getElementById(`logininput${+id + 1}`))
            .value !== null
        ) {
          document.getElementById(`logininput${+id + 1}`)?.focus();
        } else {
          document.getElementById(`logininput${id}`)?.focus();
        }
      }
    }

    if (e.keyCode === 8) {
      if (+id === 1) {
        document.getElementById(`logininput${id}`)?.focus();
      } else {
        document.getElementById(`logininput${+id - 1}`)?.focus();
      }
    }

    if (this.getOtp().length === 4) {
      this.verifyLoginOTP();
    }
  }

  ///------------------- OTP form focus for forget otp---------------

  focusForgetInputLogin(e: any, id: any) {
    if (
      (e.keyCode >= 48 && e.keyCode <= 57) ||
      (e.keyCode >= 96 && e.keyCode <= 105)
    ) {
      // 0-9 only

      if (+id < 4) {
        if (
          (<HTMLInputElement>document.getElementById(`forgetlogininput${+id + 1}`))
            .value !== null
        ) {
          document.getElementById(`forgetlogininput${+id + 1}`)?.focus();
        } else {
          document.getElementById(`forgetlogininput${id}`)?.focus();
        }
      }
    }

    if (e.keyCode === 8) {
      if (+id === 1) {
        document.getElementById(`logininput${id}`)?.focus();
      } else {
        document.getElementById(`logininput${+id - 1}`)?.focus();
      }
    }
  }

  //--------------- OTP form focus input for registration -------------------------------------
  focusInput(e: any, id: any) {
    if (
      (e.keyCode >= 48 && e.keyCode <= 57) ||
      (e.keyCode >= 96 && e.keyCode <= 105)
    ) {
      // 0-9 only

      if (+id < 4) {
        if (
          (<HTMLInputElement>document.getElementById(`input${+id + 1}`))
            .value !== null
        ) {
          document.getElementById(`input${+id + 1}`)?.focus();
        } else {
          document.getElementById(`input${id}`)?.focus();
        }
      }
    }

    if (e.keyCode === 8) {
      if (+id === 1) {
        document.getElementById(`input${id}`)?.focus();
      } else {
        document.getElementById(`input${+id - 1}`)?.focus();
      }
    }

    if (this.getOtp().length === 4) {
      this.verifyOtp();
    }
  }

  //-----------------------------Registration-----end----------------------------------------------

  //-----------------------------login with OTP -----Start----------------------------------------------

  public getOTPforLogin(): void {
    debugger;
    this.loginForm?.controls.password.setValidators(null);
    this.loginForm?.controls.password.setErrors(null);
    this.loginForm?.controls.password.disable();
    if (this.loginForm?.controls.username.valid) {
      const url = `User/loginwithOtp?userName=${this.loginForm.value.username}`;
      this.authService
        .getData(url)
        .subscribe((response: ResponseModel<any>) => {
          if (response.status === HttpStatusCode.OK) {
            this.toastService.showToast(
              Messagetype.sucess,
              'Info',
              `${response.statusMessage}`
            );
            this.showverifyOtpFormLogin = true;
            this.isShowLoginForm = false;

            //   this.openOTPdialogForLogin(this.loginForm.value.username);
          } else if (
            response.status === HttpStatusCode.BAD_REQUEST ||
            response.status === HttpStatusCode.INTERNAL_SERVER_ERROR
          ) {
          } else {
          }
        });
    }
  }

  //-----------------------------login with OTP -----end----------------------------------------------

  // ----------------------------------- otp for forget ----------------------

  public getOtpForForget() {
    debugger;
    const url = `User/forgetPassword?username=${this.forgetOTPForm?.value.username}`;
    this.authService.getData(url).subscribe((response: ResponseModel<any>) => {
      if (response.status === HttpStatusCode.OK) {
        this.isForgetOtpSent = true;
      } else {
        this.toastService.showToast(
          Messagetype.fail,
          'Info',
          `${response.statusMessage}`
        );
      }
    });
  }

  // ---------------------end-------------------

  setForgetPassword() {
    const data = {
      userName: this.forgetOTPForm.value.username,
      newPassword: this.forgetOTPForm.value.newPassword,
      otp: this.getOtp(),
      loginfrom: 1,
    };

    const url = `User/setpassLogin`;
    this.authService.postData(url, data).subscribe(
      (response: ResponseModel<any>) => {
        if (response.status === HttpStatusCode.OK) {
          if (localStorage.getItem('area') != null) {
            response.data.areaId = this.getSetService.getArea()?.areaId;
            response.data.isServiceAvailable = this.getSetService.getArea()?.isServiceAvailable;
          }
          this.getSetService.SetUser(response.data);
          this.appService.setCurrentUserInfo(response.data);
          this.appService.setSelectedArea(true);
          this.toastService.showToast(
            Messagetype.sucess,
            'Info',
            `${response.statusMessage}`
          );

          document
            .getElementById('login-area')
            ?.classList.remove('open-form');

          this.saveArea();

          this.appService.setUserLogin(true);
          this.OTPForm?.reset();
          this.appService.setCart(true);
          this.closeAllForm();
        } else if (response.status === HttpStatusCode.BAD_REQUEST) {
          this.toastService.showToast(
            Messagetype.fail,
            'Info',
            `${response.statusMessage}`
          );
        } else {
        }
      }
    )
  }

  //-----------------------------ForgetPassword -----Start----------------------------------------------

  getOtpForforgetPassword() {
    if (this.otpform?.valid) {
      const url = `User/forgetPassword?username=${this.otpform.value.otpinput}`;
      this.authService
        .getData(url)
        .subscribe((response: ResponseModel<any>) => {
          if (response.status === HttpStatusCode.OK) {
          } else if (
            response.status === HttpStatusCode.BAD_REQUEST ||
            response.status === HttpStatusCode.INTERNAL_SERVER_ERROR
          ) {
          } else {
          }
        });
    }
  }

  setNewPassword() {
    if (this.forgetPasswordForm?.valid) {
      const data = {
        userName: this.otpform?.value.otpinput,
        newPassword: this.forgetPasswordForm.value.newpassword,
        otp: this.forgetPasswordForm.value.otp,
        loginfrom: 1,
      };

      const url = `User/setpassLogin`;
      this.authService
        .postData(url, data)
        .subscribe((response: ResponseModel<any>) => {
          if (response.status === HttpStatusCode.OK) {
            this.forgetPasswordForm?.reset();
            this.forgetUserName = '';
            this.isForgetFormShow = false;

            if (localStorage.getItem('area') != null) {
              response.data.areaId = this.getSetService.getArea()?.areaId;
              response.data.isServiceAvailable = this.getSetService.getArea()?.isServiceAvailable;
            }
            this.OTPForm?.reset();
            this.getSetService.SetUser(response.data);
            this.saveArea();

            this.appService.setUserLogin(true);
            this.appService.setCurrentUserInfo(response.data);
            this.appService.setSelectedArea(true);
            this.appService.setCart(true);

            this.navigate();
          } else if (
            response.status === HttpStatusCode.BAD_REQUEST ||
            response.status === HttpStatusCode.INTERNAL_SERVER_ERROR
          ) {
          } else {
          }
        });
    }
  }

  //-----------------------------ForgetPassword -----End----------------------------------------------

  navigate() {
    if (this.getSetService.isloggedInUser()) {
      if (this.getSetService.getformcheckout()) {
        // add to cart
        const templist = this.getSetService.getTempCartList();
        if (templist != null) {
          /// call api
          const cartItemlist: any[] = [];
          templist.forEach((cart) => {
          });

          const url = `Cart/BulkAddToCart`;
          this.authService
            .postDataArray(url, cartItemlist)
            .subscribe((response: ResponseModel<any>) => {
              if (response.status === HttpStatusCode.OK) {
                this.getSetService.resetTempCartList();
                this.getSetService.resetformcheckout();
                this.router.navigate(['/checkout']);
              } else if (
                response.status === HttpStatusCode.BAD_REQUEST ||
                response.status === HttpStatusCode.INTERNAL_SERVER_ERROR
              ) {
              } else {
              }
            });
        }
      } else {
        const templist = this.getSetService.getTempCartList();
        if (templist != null) {
          /// call api
          const cartItemlist: any[] = [];
          templist.forEach((cart) => {
          });

          const url = `Cart/BulkAddToCart`;
          this.authService
            .postDataArray(url, cartItemlist)
            .subscribe((response: ResponseModel<any>) => {
              if (response.status === HttpStatusCode.OK) {
                this.getSetService.resetTempCartList();
                this.getSetService.resetformcheckout();

                // this.appService.currentMiniCart(true);
                this.router.navigate(['/']);
              } else if (
                response.status === HttpStatusCode.BAD_REQUEST ||
                response.status === HttpStatusCode.INTERNAL_SERVER_ERROR
              ) {
              } else {
              }
            });
        } else {
          this.router.navigate(['/']);
        }
      }
    }
  }

  public saveArea() {
    if (localStorage.getItem('area') != null) {
      const area = this.getSetService.getArea();
      const data = {
        areaName: area?.areaNameENg,
        pincode: area?.pincode,
        isServiceAvailable: area?.isServiceAvailable,
      };

      const url = `User/SaveArea`;
      this.authService
        .postData(url, data)
        .subscribe((response: ResponseModel<any>) => {
          if (response.status === HttpStatusCode.OK) {
            this.appService.setSelectedArea(true);
            this.getSetService.setArea(response.data);
          } else if (
            response.status === HttpStatusCode.BAD_REQUEST ||
            response.status === HttpStatusCode.INTERNAL_SERVER_ERROR
          ) {

          } else {

          }
        });
    }
  }



  AllowAlphabet(evt: any) {
    evt = evt ? evt : window.event;
    const charCode = evt.which ? evt.which : evt.keyCode;
    if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))
      return true;
    else return false;
  }

  chkMobileNo(evt: any) {
    const len = String(evt.target.value).length;
    const isNum = /^\d+$/.test(evt.target.value);
    if (len === 10 && isNum) {
      return false;
    } else {
      return true;
    }
  }

  public closeAllForm(): void {
    this.isShowLoginForm = true;
    this.showverifyOtpForm = false;
    this.showverifyOtpFormLogin = false;
    this.isForgetFormShow = false;
    this.loginForm?.reset();
    this.otpform?.reset();
    this.registerForm?.reset();
    this.forgetOTPForm.reset();
    this.isForgetOtpSent = false;

    this.submitted = false;
  }
  isNumber(evt: any) {
    evt = evt ? evt : window.event;
    const charCode = evt.which ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  omit_special_char(event: any) {
    var k;
    k = event.charCode;  //         k = event.keyCode;  (Both can be used)
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32);
  }
}

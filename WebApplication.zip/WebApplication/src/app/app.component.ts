import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { AppService } from './shared/services/app.service';
import { GetSetService } from './shared/services/getset.serverce';

@Component({
  selector: 'app-root',
  template: '<router-outlet></router-outlet>',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'product_agri-web';

  constructor(
    public translate: TranslateService,
    public getSetService: GetSetService,
    public appservice: AppService,
    private router: Router,
  ) {

    translate.addLangs(['en', 'mr', 'hi']);
    if (localStorage.getItem('locale')) {
      const browserLang = localStorage.getItem('locale');
      if (browserLang) {
        translate.use(browserLang.match(/en|mr|hi/) ? browserLang : 'en');
      }
    } else {
      localStorage.setItem('locale', 'en');
      translate.setDefaultLang('en');
    }
    //	this.settings = this.appSettings.settings;

    // this.goLive(true);

    if (localStorage.getItem('locale')) {
      const lng = localStorage.getItem('locale');
      if (lng) {
        appservice.setcurrentLanguage(lng);
      }
    }

  }

  ngAfterViewInit() {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        window.scrollTo(0, 0);
      }
    });
  }

}

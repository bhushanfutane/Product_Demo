import { Component, OnInit } from '@angular/core';
import { SeoService } from 'src/app/shared/services/seo.service';

@Component({
  selector: 'app-privacypolicy',
  templateUrl: './privacypolicy.component.html',
  styleUrls: ['./privacypolicy.component.scss']
})
export class PrivacypolicyComponent implements OnInit {

  constructor(
    private SEOService: SeoService
  ) { }

  ngOnInit(): void {
    let faqMetaData = null;
    this.SEOService.getStaticPageMetaData().subscribe(response => {
      faqMetaData = response;
      this.SEOService.setMetadata(faqMetaData.Privacypolicy.title, faqMetaData.Privacypolicy.description, faqMetaData.Privacypolicy.keywords);
    });
  }

}

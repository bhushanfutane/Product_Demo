// Angular
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { ProductListComponent } from './product-list.component';
import { ProductListRoutingModule } from './product-list.routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ProductListRoutingModule,
    SharedModule,
    TranslateModule
  ],
  declarations: [
   ProductListComponent
  ]
})
export class ProductListModule { }

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ICategory } from 'src/app/shared/model/category.model';
import { Messagetype } from 'src/app/shared/model/enum';
import { IProduct } from 'src/app/shared/model/product.model';
import {
  HttpStatusCode,
  ResponseModel,
} from 'src/app/shared/model/response.model';
import { ApiDataService } from 'src/app/shared/services/apidata.service';
import { AppService } from 'src/app/shared/services/app.service';
import { GetSetService } from 'src/app/shared/services/getset.serverce';
import { SeoService } from 'src/app/shared/services/seo.service';
import { ToastService } from 'src/app/shared/services/toast.service';

@Component({
  templateUrl: 'product-list.component.html',
})
export class ProductListComponent implements OnInit {
  showlist = false;

  productResponse?: any;
  products?: IProduct[] = [];
  copyProductList?: IProduct[] = [];

  typeid: number = 0;
  catid: number = 0;
  typename: string = '';
  subcatid = 0;
  areaid: number = 0;
  categories?: ICategory[] = [];
  currentLang = 'en';
  isServiceAvailibitity = false;
  public subscriptions$: Subscription[] = [];

  selectedCategories: number[] = [];
  savedArea: any;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private apiservice: ApiDataService,
    private activatedRoute: ActivatedRoute,
    private appservice: AppService,
    private getset: GetSetService,
    private SEOService: SeoService,
    private toastService: ToastService
  ) { }

  ngOnInit(): void {
    // this.getSavedarea();
    this.getCatgoryList();
    this.getproductList();

    this.appservice.getSelectedArea().subscribe(() => {
      // this.getSavedarea();
      this.getCatgoryList();
      this.getproductList();
    });
    this.appservice.getcurrentLanguage().subscribe((lng: any) => {
      this.currentLang = lng;
    });

    this.currentLang = this.getset.getlanguge();
    this.subscriptions$.push(

      this.activatedRoute.params.subscribe((params) => {
        // if (params['typeid']) {
        //   this.typeid = +params['typeid'];
        // }
        // if (window.location.href.includes('products')) {
        //   if (this.typeid == 3) {
        //     if (this.getset.isloggedInUser()) {
        //       this.router.navigateByUrl('/recipe/0/0');
        //       this.toastService.showToast(Messagetype.fail, 'Please Login', 'Please login  for using this feature.')
        //     } else {
        //       const user = this.getset.getCurrentUserInfo();
        //       this.router.navigateByUrl('/recipe/' + user?.userId + '/0');
        //     }
        //   }
        // }



        this.SEOService.setMetadata(this.typename, this.typename, '');

        this.checkForCategories();


        this.appservice.getCart().subscribe(() => {
          this.getproductList();
        });


      })
    );
  }

  checkForCategories() {
    // check for category page
    if (window.location.href.includes('categories')) {
      const grainid = this.typeid;
      const grainName = this.typename;
      this.selectedCategories = [];
      this.selectedCategories.push(grainid);
      const cat = this.categories?.find(m => m.id == grainid);
      this.categories?.forEach(element => {
        element.isActive = false;
      });
      if (cat) {
        cat.isActive = true;
        this.typeid = 0;
        // this.filterProduct();
      } else {
        const url = `/api/Grain/GetGrainwithCategoriesAreawise?AreaId=${this.areaid}`;
        this.apiservice.getData(url).subscribe((response: ResponseModel<any[]>) => {
          if (response.status === HttpStatusCode.OK) {
            this.categories = response.data;
            const cat = this.categories?.find(m => m.id == grainid);
            if (cat) {
              cat.isActive = true;
              this.typeid = 0;
              // this.filterProduct();
            }
          }
        });
      }
    } else {
      // this.filterProduct();
    }
  }



  getCatgoryList() {
    // const url = `/api/Grain/GetGrainwithCategoriesAreawise?AreaId=${this.areaid}`;
    const url =`/Category/GetActive`
    this.apiservice.getData(url).subscribe((response: ResponseModel<any[]>) => {
      if (response.status === HttpStatusCode.OK) {
        this.categories = response.data;
      }
    });
  }

  getproductList() {
    const url = `Product/Product`;
    this.apiservice.getData(url).subscribe((response: ResponseModel<any>) => {
      if (response.status === HttpStatusCode.OK) {
        this.copyProductList = response.data.product;
        this.products = response?.data.product;
        console.log(this.products);
        // this.filterProduct();
      }
    });
  }

  applySwipper() {
    var timesRun = 0;
    var interval = setInterval(function () {
      timesRun += 1;
      if (timesRun === 10) {
        clearInterval(interval);
      }
      if (document.getElementById('topsellingsview')) {
        document.getElementById('topsellingsview')?.click();
      }
    }, 1000);
  }

  onCategoryCheck(event: any, category: any) {
    if (event.target.checked) {
      this.selectedCategories.push(category.id);
    } else {
      this.selectedCategories.forEach((id, index) => {
        if (id === category.id) {
          this.selectedCategories.splice(index, 1);
        }
      });
    }
     this.filterProduct();

  }

  filterProduct() {
    const productType = this.typeid;

    this.products = [];
    if (productType === 0) {
      if (this.selectedCategories.length > 0) {
        this.copyProductList?.forEach(product => {
          if (this.selectedCategories.includes(product.categoryId)) {
                   if (!this.products?.includes(product)) {
                    this.products?.push(product);
                   }
                  }
      //   //   var subcategoriesIds = product.productDetailLists;
      //   //   subcategoriesIds.forEach((productdetail: any) => {
      //   //     if (this.selectedCategories.includes(productdetail.grainId)) {
      //   //       if (!this.products?.includes(product)) {
      //   //         this.products?.push(product);
      //   //       }
      //   //     }
      //   //   });
      });
      } else {
        this.products = this.copyProductList;
      }
    } 
    else {
      // this.copyProductList?.forEach(product => {
      //   var subcategoriesIds = product.productDetailLists;
      //   subcategoriesIds.forEach((productdetail: any) => {
      //     if ((product.productType === productType)) {
      //       if (!this.products?.includes(product)) {
      //         this.products?.push(product);
      //       }
      //     }
      //   });
      // });
    }

  }

  clearFilter() {
    this.categories?.forEach((category) => {
      (category.categories as Array<any>).forEach((subcategory) => {
        this.selectedCategories = [];
        subcategory['isChecked'] = false;
        this.router.navigateByUrl('/products');
        // this.filterProduct();
      });
    });

    this.getCatgoryList();
  }
}

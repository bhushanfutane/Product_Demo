// Angular
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { ProductdetailRoutingModule } from './productdetail.routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { ProductdetailComponent } from './productdetail.component';
import { TranslateModule } from '@ngx-translate/core';



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ProductdetailRoutingModule,
    SharedModule,
    TranslateModule
  ],
  declarations: [
    ProductdetailComponent,
  ]
})
export class ProductdetailModule { }

import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
  ActivatedRoute,
  NavigationEnd,
  NavigationStart,
  Router,
} from '@angular/router';
import { Subscription } from 'rxjs';
import { Messagetype } from 'src/app/shared/model/enum';
import { IProduct } from 'src/app/shared/model/product.model';
import {
  ResponseModel,
  HttpStatusCode,
} from 'src/app/shared/model/response.model';
import { IUserInfo } from 'src/app/shared/model/userinfo.model';
import { ApiDataService } from 'src/app/shared/services/apidata.service';
import { AppService } from 'src/app/shared/services/app.service';
import { GetSetService } from 'src/app/shared/services/getset.serverce';
import { SeoService } from 'src/app/shared/services/seo.service';

import { ToastService } from 'src/app/shared/services/toast.service';

@Component({
  templateUrl: 'productdetail.component.html',
  styleUrls: ['./productdetail.component.scss'],
})
export class ProductdetailComponent implements OnInit, OnDestroy {
  public subscriptions$: Subscription[] = [];
  productId = 0;
  product?: IProduct;
  productReview = '';
  quantity = 1;
  userInfo?: IUserInfo;
  productReviewList: any[] = [];
  oldProductId = 0;
  savedArea: any;
  isshowProduct = false;
  areaid = 0;
  reviewForm: FormGroup;
  currentLang: any;
  isrecipeUpdate = false;

  selected: string | undefined;
  constructor(
    private apidata: ApiDataService,
    private router: Router,
    private toast: ToastService,
    private appservice: AppService,
    private formBuilder: FormBuilder,
    private SEOService: SeoService,
    private getset: GetSetService
  ) {
    this.reviewForm = this.formBuilder.group({
      review: ['', [Validators.required]],
    });
  }

  ngOnInit(): void {
    this.subscriptions$.push(
      this.router.events.subscribe(() => {
        this.productId = this.getId();


        if (this.oldProductId != this.productId) {

          this.productId = this.getId();
          this.oldProductId = this.productId;
          this.getProductById(this.productId);
          // this.getProductReview(this.productId);
        }
      })
    );

    this.subscriptions$.push(

      // languge Subscription

      this.appservice.getcurrentLanguage().subscribe((lng: any) => {
        this.currentLang = lng;
      })
    );
    this.currentLang = this.getset.getlanguge();
    this.getSavedarea();
    this.oldProductId = this.getId();
    this.productId = this.getId();

    this.getProductById(this.productId);
    // this.getProductReview(this.productId);
    this.appservice.getSelectedArea().subscribe(() => {
      this.getSavedarea();
      this.getProductById(this.productId);
    });

  }

  getSavedarea(): void {

    this.savedArea = this.getset.getArea();
    if (!this.savedArea) {
    } else {
      this.areaid = this.savedArea.areaId;
    }
    const user = this.getset.getCurrentUserInfo();
    if (user) {
      this.userInfo = user;
    }
  }

  public getProductById(id: number) {
    this.isshowProduct = false;

    let tempcartList: any;
    if (!this.getset.isloggedInUser()) {
      tempcartList = this.getset.getTempCartList();
      if (!tempcartList) {
        tempcartList = [];
      }
    }

    // const url = `/api/Product/GetProductDetail?productId=${id}&AreaId=${this.areaid}`;
    const url = `Product/ProductDetail?Id=${id}&AreaId=${this.areaid}`;

    this.apidata.getData(url).subscribe((response: ResponseModel<any>) => {
      if (response.status === HttpStatusCode.OK) {
        this.product = response.data;
        this.isshowProduct = true;
        // this.SEOService.setMetadata(
        //   // this.product !== undefined ? this.product?.engName : '',
        //   // this.product !== undefined ? this.product?.metaDiscription : '',
        //   // this.product !== undefined ? this.product?.keyword : '',
        // );
        if (this.product) {
          if (!this.getset.isloggedInUser()) {
            const prod = tempcartList.find((i: { id: any; }) => i.id === this.product?.id);
            if (prod) {
              this.product.isInCart = true;
              this.product.quantity = prod?.quantity;
            }

          }
        }
        } else {
        this.toast.showToast(
          Messagetype.fail,
          'info',
          `${response.statusMessage}`
        );
      }
    });
  }

  // ngOnDestroy(): void {
  //   this.subscriptions$.forEach((subscription) => subscription.unsubscribe());
  // }

  // public getProductReview(id: number) {
  //   const url = `/api/RatingReview/ProductReview?ProductId=${id}`;
  //   this.apidata.getData(url).subscribe((response: ResponseModel<any>) => {
  //     if (response.status === HttpStatusCode.OK) {
  //       this.productReviewList = response.data;
  //     } else {
  //       this.productReviewList = [];
  //     }
  //   });
  // }

  // public addProductReview() {
  //   if (this.productReview.trim() !== '') {
  //     const data = {
  //       id: 0,
  //       productId: this.productId,
  //       review: this.productReview,
  //     };
  //     const url = `/api/RatingReview/AddReview`;
  //     this.apidata
  //       .postData(url, data)
  //       .subscribe((response: ResponseModel<any>) => {
  //         if (response.status === HttpStatusCode.OK) {
  //           this.toast.showToast(
  //             Messagetype.sucess,
  //             'info',
  //             `${response.statusMessage}`
  //           );
  //           this.productReview = '';
  //           this.getProductReview(this.productId);
  //         } else {
  //           this.toast.showToast(
  //             Messagetype.fail,
  //             'info',
  //             `${response.statusMessage}`
  //           );
  //         }
  //       });
  //   }
  // }

  getId(): number {
    const url = window.location.href;
    const splits = url.split('/');
    return +splits[splits.length - 1];
  }

  public addReview(): void {
    const data = {
      id: 0,
      productId: +this.productId,
      review: this.reviewForm.value.review,
    };
    const url = `/api/RatingReview/AddReview`;

    if (this.reviewForm.valid) {
      this.apidata
        .postData(url, data)
        .subscribe((response: ResponseModel<any>) => {
          if (response.status === HttpStatusCode.OK) {
            this.toast.showToast(
              Messagetype.fail,
              'info',
              `Thank you for submitting your review`
            );
            this.reviewForm.reset();
          } else {
            this.toast.showToast(
              Messagetype.fail,
              'info',
              `${response.statusMessage}`
            );
            this.reviewForm.reset();
          }
        });
    }
  }

  ngOnDestroy(): void {
    this.subscriptions$.forEach((subscription) => subscription.unsubscribe());
  }

  // tslint:disable-next-line:typedef
  increment(product: any) {
    this.quantity = this.quantity + 1;
    if (this.quantity > 10) {
      this.quantity = 10;
    }
    product.quantity = this.quantity;
    if (product.isInCart) {
      this.addtocartandcheckout();
    }
  }
  // public changeSize(size: any, product: any) {
  //   product.size = +size.target.value;
  //   if (product.isInCart) {
  //     this.addtocartandcheckout();
  //   }
  // }
  // tslint:disable-next-line:typedef
  decrement(product: any): void {
    if (this.quantity > 1) {
      this.quantity = this.quantity - 1;
      product.quantity = this.quantity;
      if (product.isInCart) {
        this.addtocartandcheckout();
      }
    } else {
      this.toast.showToast(
        Messagetype.fail,
        'Info',
        `Product Quantity Should be one`
      );
    }

  }
  isReadymadeProduct(product: any): boolean {
    if (product !== undefined) {
      return (product.typeId === 3 || product.typeId === 2);
    }
    return false;
  }


  addtocartandcheckout(ischeckout: boolean = false): void {

    const isUserLogin = this.getset.isloggedInUser();
    const cartItem = {
      productId: this.product?.id,
      quantity: this.quantity,
    };

    if (isUserLogin) {
      // add to database
      if (this.getset.getArea()?.isServiceAvailable) {

        const user = this.getset.getCurrentUserInfo();
        if (user) {
          this.userInfo = user;
        }
        const url = `Cart/AddtoCart`;
        this.apidata
          .postData(url, cartItem)
          .subscribe((response: ResponseModel<any>) => {
            if (response.status === HttpStatusCode.OK) {

              // this.toast.showToast(Messagetype.sucess, 'info', 'Item successfully added to cart.');
              this.appservice.setCart(true);
              if (this.product) {
                this.product.isInCart = true;
              }
              if (ischeckout) {
                this.router.navigateByUrl('/cartlist');
              }
              this.appservice.setSelectedArea(true);
            } else if (
              response.status === HttpStatusCode.INTERNAL_SERVER_ERROR
            ) {

              //  this.toast.showToast(Messagetype.fail, 'info', `${response.statusMessage}`);

            } else {
              //   this.toast.showToast(Messagetype.fail, 'info', `${response.statusMessage}`);
            }
          });
      } else {

        // this.toast.showToast(Messagetype.fail, 'info', `Service not available in this area.`);
      }


    } else {

      // add to temp cart

      // const localCartList = this.getset.getTempCartList();
      // // tslint:disable-next-line:prefer-for-of
      // if (localCartList) {
      //   // tslint:disable-next-line:prefer-for-of
      //   for (let i = 0; i < localCartList.length; i++) {
      //     if (localCartList[i].id === cartItem.productId) {
      //       localCartList[i].grindingType = cartItem.grindingType;
      //       localCartList[i].quantity = cartItem.quantity;
      //       localCartList[i].size = cartItem.size;
      //     }
      //   }

      //   this.getset.setTempCartList(localCartList);
      //   this.appservice.setCart(true);
      //   this.appservice.setSelectedArea(true);
      // }
    }
  }





  // public ManageQty(qty: number) {
  //   if (qty < 1) {
  //     qty = qty * 1000;
  //   }
  //   return qty;
  // }

}

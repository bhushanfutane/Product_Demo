// Angular
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { ProductListcategoryRoutingModule } from './product-list-category.routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { TranslateModule } from '@ngx-translate/core';
import { ProductListCategoryComponent } from './product-list-category.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ProductListcategoryRoutingModule,
    SharedModule,
    TranslateModule
  ],
  declarations: [
    ProductListCategoryComponent
  ]
})
export class ProductListCategoryModule { }

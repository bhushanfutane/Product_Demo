import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ICategory } from 'src/app/shared/model/category.model';
import { Messagetype } from 'src/app/shared/model/enum';
import { IProduct } from 'src/app/shared/model/product.model';
import {
  HttpStatusCode,
  ResponseModel,
} from 'src/app/shared/model/response.model';
import { ApiDataService } from 'src/app/shared/services/apidata.service';
import { AppService } from 'src/app/shared/services/app.service';
import { GetSetService } from 'src/app/shared/services/getset.serverce';
import { SeoService } from 'src/app/shared/services/seo.service';
import { ToastService } from 'src/app/shared/services/toast.service';

@Component({
  templateUrl: 'product-list-category.component.html',
})
export class ProductListCategoryComponent implements OnInit {
  showlist = false;

  productResponse?: any;
  products?: IProduct[] = [];
  copyProductList?: IProduct[] = [];

  typeno: number = 0;
  catid: number = 0;
  typename: string = '';
  subcatid = 0;
  areaid: number = 0;
  categories?: ICategory[] = [];
  currentLang = 'en';

  public subscriptions$: Subscription[] = [];

  selectedSubCategories: number[] = [];
  savedArea: any;
  constructor(
    private apiservice: ApiDataService,
    private activatedRoute: ActivatedRoute,
    private appservice: AppService,
    private getset: GetSetService,
    private toastService: ToastService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.getSavedarea();
    this.subscriptions$.push(
      this.activatedRoute.params.subscribe((params) => {
        if (params['typeno']) {
          this.typeno = +params['typeno'];
        }

        if (params['typename']) {
          this.typename = params['typename'];
        }

        this.GetProducts(this.typeno);
      })
    );


    this.appservice.getcurrentLanguage().subscribe((lng: any) => {
      this.currentLang = lng;
    });

    this.currentLang = this.getset.getlanguge();

    this.appservice.getSelectedArea().subscribe(() => {
      this.getSavedarea();
      this.GetProducts(this.typeno);
    });

  }

  getSavedarea(): void {

    this.savedArea = this.getset.getArea();
    if (!this.savedArea) {
    } else {
      this.areaid = this.savedArea.areaId;
    }
  }

  GetProducts(TypeId: number) {

    if (TypeId == 3) {
      if (!this.getset.isloggedInUser()) {
        this.toastService.showToast(Messagetype.fail, 'Please Login', 'Please login  for using this feature.')
        this.router.navigateByUrl('/');
      }
    }

    let url = `Product/TypeList?TypeId=${TypeId}&AreaId=${this.areaid}`;

    // My recipe
    if (TypeId === 3) {
      url = `Product/MyRecipes?&AreaId=${this.areaid}&PageSize=0&PageNumber=0`;;
    }

    // TRENDING
    if (TypeId === 11) {
      url = `Product/Trending?AreaId=${this.areaid}`;
    }
    // RECOMMENDED
    else if (TypeId === 12) {
      url = `Product/Recommended?AreaId=${this.areaid}`;
    }


    this.apiservice.getData(url).subscribe
      ((response: ResponseModel<any>) => {
        if (response.status === HttpStatusCode.OK) {
          this.products = response.data;
        }
      });
  }
}

import { Component, Input, OnInit } from '@angular/core';
import { IProduct } from 'src/app/shared/model/product.model';
import { HttpStatusCode, ResponseModel } from 'src/app/shared/model/response.model';
import { ApiDataService } from 'src/app/shared/services/apidata.service';
import { AppService } from 'src/app/shared/services/app.service';
import { GetSetService } from 'src/app/shared/services/getset.serverce';

@Component({
  selector: 'app-view-products',
  templateUrl: './view-products.component.html',
  styleUrls: ['./view-products.component.scss']
})
export class ViewProductsComponent implements OnInit {
  @Input() type: number = 0;

  title: string | undefined;
  Type: number = 0;
  areaid: number = 0;

  products: any;
  savedArea: any;
  constructor(
    private apiservice: ApiDataService,
    private getset: GetSetService,
    private appservice: AppService
  ) { }

  ngOnInit(): void {
    this.getSavedarea();
    this.Type = +this.type;
    this.GetProducts(this.Type);
    this.appservice.getSelectedArea().subscribe(() => {
      this.getSavedarea();
      this.GetProducts(this.Type);
    });
  }

  getSavedarea(): void {

    this.savedArea = this.getset.getArea();
    if (!this.savedArea) {
    } else {
      this.areaid = this.savedArea.areaId;
    }
  }

  GetProducts(TypeId: number) {

    let url = `/Product/TypeList?TypeId=${TypeId}&AreaId=${this.areaid}`;

    // My recipe
    if (TypeId === 3) {
      url = `/api/Product/MyRecipes?&AreaId=${this.areaid}&PageSize=0&PageNumber=0`;;
    }

    // TRENDING
    if (TypeId === 11) {
      url = `Product/Trending?AreaId=${this.areaid}`;
    }
    // RECOMMENDED
    else if (TypeId === 12) {
      url = `/api/Product/Recommended?AreaId=${this.areaid}`;
    }
    let tempcartList: any;
		  if (!this.getset.isloggedInUser()) {
			tempcartList = this.getset.getTempCartList();
			if (!tempcartList) {
				tempcartList = [];
			}
		}
    this.apiservice.getData(url).subscribe
      ((response: ResponseModel<any>) => {
        if (response.status === HttpStatusCode.OK) {
          this.products = response.data;
          (response.data as Array<any>).forEach((element) => {
          if (!this.getset.isloggedInUser()) {
            const prod = tempcartList.find((i: { id: any; }) => i.id === element.id);
            if (prod) {
              element.isInCart = true;
              element.size = prod.size;
              element.quantity = prod?.quantity;
            }

          }});

          this.applySwipper();
        }
      });
  }

  // tslint:disable-next-line:typedef
  applySwipper() {
    let timesRun = 0;
    let that = this;
    let interval = setInterval(function () {
      if (timesRun == 0) {
        if (document.getElementById('product_scroll_' + that.type)) {
          timesRun = 1;
          document.getElementById('product_scroll_' + that.type)?.click();
          clearInterval(interval);
        }
      }
    }, 1000);

  }
}


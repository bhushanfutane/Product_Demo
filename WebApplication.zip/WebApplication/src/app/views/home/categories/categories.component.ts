import { AfterViewInit, Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { IHomeCategory } from 'src/app/shared/model/category.model';
import { ICatandType } from 'src/app/shared/model/cattype.model';
import { HttpStatusCode, ResponseModel } from 'src/app/shared/model/response.model';
import { ApiDataService } from 'src/app/shared/services/apidata.service';
import { AppService } from 'src/app/shared/services/app.service';
import { GetSetService } from 'src/app/shared/services/getset.serverce';

@Component({
  selector: 'app-categories',
  templateUrl: 'categories.component.html',
  styleUrls: ['./categories.component.scss']
})
export class CategoriesComponent implements OnInit, AfterViewInit {

  categories?: IHomeCategory[] = [];
  currentLang = 'en';

  constructor(private apiservice: ApiDataService,
    private getset: GetSetService,
    public translate: TranslateService,
    private appservice: AppService
  ) { }

  ngAfterViewInit(): void {
  }

  ngOnInit(): void {
    this.appservice.getcurrentLanguage().subscribe((lng: any) => {
      this.currentLang = lng;
    });
    this.currentLang = this.getset.getlanguge();
    this.getCatetypeList();
  }

  getCatetypeList() {
      this.categories = ApiDataService.categoryList;
      console.log(this.categories)
  }

 
}

// Angular
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { HomeComponent } from './home.component';
import { HomeRoutingModule } from './home-routing.module';
import { CategoriesComponent } from './categories/categories.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { BannerComponent } from './banner/banner.component';
import { MemberplanComponent } from './memberplan/memberplan.component';
import { TranslateModule } from '@ngx-translate/core';
import { AboutFpComponent } from './about-fp/about-fp.component';
import { FpdetailComponent } from './fpdetail/fpdetail.component';
import { HomeblogComponent } from './homeblog/homeblog.component';
import { CoursesComponent } from './courses/courses.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HomeRoutingModule,
    SharedModule,
    TranslateModule

  ],
  declarations: [
    HomeComponent,
    CategoriesComponent,
    BannerComponent,
    MemberplanComponent,
    AboutFpComponent,
    FpdetailComponent,
    HomeblogComponent,
    CoursesComponent
    
  ]
})
export class HomeModule { }

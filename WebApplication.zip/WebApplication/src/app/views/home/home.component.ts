import { Component, OnInit } from '@angular/core';
import { IUserInfo } from 'src/app/shared/model/userinfo.model';
import { GetSetService } from 'src/app/shared/services/getset.serverce';
import { SeoService } from 'src/app/shared/services/seo.service';

@Component({
  templateUrl: 'home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  user?: IUserInfo;
  constructor(
    private SEOService: SeoService,
    private getset: GetSetService,
  ) {
    let homeMetaData = null;
    this.SEOService.getStaticPageMetaData().subscribe(response => {
      homeMetaData = response;
      this.SEOService.setMetadata(homeMetaData.Home.title, homeMetaData.Home.description, homeMetaData.Home.keywords);
    });
  }
  ngOnInit(): void {
    const user = this.getset.getCurrentUserInfo();
    if (user) {
      this.user = user;
    }
  }
}
